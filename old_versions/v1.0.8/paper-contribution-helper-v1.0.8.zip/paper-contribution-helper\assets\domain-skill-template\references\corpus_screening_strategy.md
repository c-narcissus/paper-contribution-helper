# Corpus Screening Strategy

Screen for `contribution-reframing-useful` papers, not merely papers that look weak, incremental, or component-compositional.

Use these roles:

- `positive_framing`: surface risk exists, but the paper frames it through a missing interface, failure-mode repair, assumption relaxation, evidence protocol, or deployment constraint.
- `contested_accepted`: reviews question novelty/contribution/baselines/mechanism/scope, but the available review trail shows a defensible acceptance path.
- `negative_risk`: weak framing is visible and no successful defense is available. Use only for attack taxonomy and risky wording.
- `domain_reference`: field-relevant background without a clear reframing lesson.
- `unclear`: insufficient evidence.

Evidence tiers:

- `abstract_only`: discovery and semantic pre-screening only.
- `pdf_available`: candidate can enter a project run, but is not reusable knowledge yet.
- `pdf_deep_read_complete`: eligible for anonymous synthesis.
- `review_evidence_available`: usable for real reviewer attack and defense patterns.

Rules:

- Use keywords only for broad recall.
- Require semantic screening before assigning a case role.
- Require full-PDF deep reading before packaging any reusable case.
- Keep abstract-only papers out of the final casebook.
- Use `negative_risk` papers as warnings, not as recommended contribution templates.
