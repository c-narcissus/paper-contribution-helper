# Release Notes

## v1.0.8

- Fixed a Windows/Markdown path rendering hazard where paths containing `\_`, such as `...\_skill_runtime\...`, could be displayed without the backslash before `_skill_runtime`.
- Updated path policy and generated-skill instructions: prefer workspace-relative paths in user-facing output; if an absolute Windows path is explicitly needed, show it in a fenced code block or normalize it to forward slashes rather than placing a raw drive-letter path in a Markdown link or inline sentence.
- Clarified that generated ZIP/package locations should be reported as relative paths when possible, with raw machine absolute paths treated as secondary diagnostic information only.

## v1.0.7

- Changed generated target-paper report delivery to use portable workspace-relative `reports/` paths instead of user-facing raw machine absolute paths.
- Updated `scripts/analyze_new_pdf.py` in the generated-skill template so persisted source ledgers omit machine-specific absolute directories for user PDFs, reviews, replies, and skill roots.
- Updated generated-skill instructions to prevent leaking internal drafting notes, placeholders, or raw Windows drive paths as final user-facing report links.

## v1.0.6

- Added a load-safe public report mirror for target-paper analysis. `scripts/analyze_new_pdf.py` now reports both the original `public_report` path and a `load_safe_public_report` path under the workspace `reports/` directory.
- The load-safe report scaffold is written as UTF-8 with BOM to avoid Windows/Markdown clients failing to load hidden overlay paths, paths with spaces/non-ASCII characters, or non-BOM UTF-8 Markdown.
- Updated generated-skill templates and usage instructions so final user-facing target-paper reports should be saved to and linked from `load_safe_public_report` when available.

## v1.0.5

- Changed target-paper analysis default output from an exhaustive matrix-style report to a plain advisor/teacher-style report: conclusion first, direct Chinese explanation, fewer tables, and concrete rewrite advice.
- Added `references/report_playbook/plain_teacher_reporting.md` and made generated child skills inherit it.
- Updated target-report contracts and workflows so six-route boards, full comparison matrices, and long anonymous appendices are detailed-mode outputs only when explicitly requested.
- Updated the target PDF pre-pass scaffold so newly generated skills create a readable plain-report scaffold by default.

## v1.0.4

- Added an explicit no-backend continuation rule: missing `OPENAI_API_KEY`, ACP/acpx, or a local LLM backend must move a project-internal corpus into current-assistant local deep reading instead of ending the task.
- Added `scripts/engine/continue_local_deep_read.py`, an idempotent coordinator that validates a run, creates extraction/rule-prepass artifacts, prepares assistant-readable packets, and imports assistant-written records when available.
- Clarified that `waiting_for_current_assistant_read` is an in-progress handoff state, not a final blocker.
- Updated generated-skill templates so child skills inherit the same no-backend local deep-read continuation behavior.

## v1.0.3

- Reframed corpus selection around `contribution-reframing-useful` papers instead of merely finding papers with visible incremental/A+B/C/engineering/transfer risk.
- Added `references/corpus_screening_strategy.md` with explicit `positive_framing`, `contested_accepted`, `negative_risk`, `domain_reference`, and `unclear` candidate roles.
- Added `web-abstract-pdf-mixed` source-mode documentation for web abstracts with partial PDF availability. Abstract-only records are discovery candidates only; reusable cases still require full-PDF deep reading.
- Added a web abstract/PDF manifest adapter script that preserves all abstract records in discovery artifacts and creates project material folders only for records with local or downloadable PDFs.
- Clarified that keyword matching is a broad recall mechanism, while semantic screening and full-paper evidence decide reference usefulness.

## v1.0.2

- Added a modular current-assistant local deep-read route for project-run corpora when `OPENAI_API_KEY`, local command backends, or ACP/acpx are unavailable.
- Added assistant packet preparation, assistant-written JSONL validation, and import scripts.
- Added JSON config-file support for build/synthesis stages so long domain/year inputs can move out of CLI arguments.
- Shortened generated domain-profile filenames with a stable hash to avoid Windows long-path failures while preserving full domain metadata in manifests and report content.

## v1.0.0

- Initial `paper-contribution-helper` package.
- Modularized the skill around a small router, on-demand workflow references, explicit module boundaries, context loading policy, and path hygiene validation.
- Added a mandatory first-response opening rule: on first invocation, the skill outputs the fixed opening message only and does not answer substantive questions until the user replies again.
- Added an ACP command-file bridge for environments without `OPENAI_API_KEY`; long full-paper prompts are passed through request/prompt/response files instead of command-line arguments.
- Added target-paper domain inference: users can provide `--target-paper` instead of manually supplying `--focus-domains`.
- The factory deep-reads the whole target PDF, infers 1-3 searchable domains or subfields, records the inference artifact, and uses those labels for corpus screening.
- Documented the more user-friendly startup path and the evidence boundary for inferred routing metadata.
- Made downloaded project corpus files the primary initialization path through `references/project_corpus_direct_workflow.md`, covering both `project-run` and `local-pdf`.
- Clarified that ACP/acpx is only an optional `command-file` fallback when no API key, local command backend, or precomputed JSONL backend is available.
- Added explicit context-limit policy: never paste full PDFs or a complete corpus into chat context; use project files, chunking, intermediate artifacts, manifests, and `--reuse-llm`.
- Split the PDF entrypoint into two explicit modes: direct target-paper analysis, or target-PDF/domain-field input for generating a specialized reusable skill.
- Added the rule that an unspecified PDF upload must trigger a two-choice clarification before any analysis or corpus build starts.
- Reworded the mandatory startup message around clear A/B entrypoints so users can distinguish direct paper analysis from specialized skill generation.
- Locked the mandatory startup message to the exact user-approved text as a highest-priority first-response rule.
- Added a project-internal corpus stage contract: downloaded/provided `project-run` or `local-pdf` materials must continue through validation, extraction, per-paper artifacts, manifests, and explicit LLM status even when final synthesis/packaging is blocked.
- Promoted local project-file processing to the highest operational priority after the first-response rule: downloaded/uploaded/standardized PDFs, reviews, replies, metadata, and corpus runs must be processed from disk first; API/acpx/local command backends are optional automation routes, not permission gates.
