# Source Modes

All source modes may be driven by explicit `--focus-domains` or by `--target-paper` domain inference. When `--target-paper` is used, the factory first deep-reads the target PDF, infers 1-3 searchable focus domains/subfields, and then applies those labels to the selected source mode.

Primary source preference: use downloaded project files directly whenever available. Load `references/project_corpus_direct_workflow.md` before using online discovery.

## `project-run`

Primary path for an already-downloaded, already-normalized corpus.

Consume an existing project corpus run with:

```text
materials/_by_paper/<paper_key>/paper.pdf
materials/_by_paper/<paper_key>/submission.json
materials/_by_paper/<paper_key>/source_status.json
```

Reviews and replies are optional but should be included when available.

The existing run must still pass the factory's analysis stage. If its `analysis/per_paper_analysis_manifest.jsonl` is old or rule-only, rebuild the analysis so every selected PDF receives a full-paper LLM deep-read before synthesis.

## `local-pdf`

Primary path for a downloaded PDF folder that has not yet been normalized.

Standardize one PDF or a PDF folder into a project corpus run using the embedded engine. If reviews/replies are absent, downstream review concerns must be labeled `simulated-review`.

Local PDFs are valid corpus sources only after text extraction and the required LLM deep-reading pass complete for every selected PDF.

## `web-abstract-pdf-mixed`

Use this when the user can gather related papers from web pages, arXiv, publisher pages, search APIs, or manual literature lists, but many records only have abstracts and only some have downloadable PDFs.

Input should be a JSONL or CSV manifest with fields such as:

```text
title, abstract, year, venue, authors, keywords, primary_area, source_url, pdf_url, pdf_path
```

This mode has two outputs:

- `discovery/abstract_candidates.jsonl`: every abstract/metadata record, including abstract-only candidates and semantic screening labels.
- `materials/_by_paper/<paper_key>/`: only candidates with a downloaded or local PDF.

Abstract-only records are discovery evidence, not reusable casebook evidence. They may guide PDF acquisition and candidate prioritization, but they must not be packaged into the generated helper's anonymous casebook.

Keyword matching in this mode is recall only. Use `references/corpus_screening_strategy.md` to semantically classify candidates as `positive_framing`, `contested_accepted`, `negative_risk`, `domain_reference`, or `unclear`. A `negative_risk` paper can inform reviewer attack taxonomy and risky wording, but it should not become a positive contribution template.

## `openreview-iclr`

Use the integrated OpenReview adapter to discover accepted ICLR papers by `venueid`, screen by focus-domain keywords, download selected PDFs and public review/reply materials, then produce the standard project corpus run.

Use this only when no suitable local corpus exists or when the user explicitly wants discovery/download.

When the focus domains came from `--target-paper`, treat them as screening labels only. They should affect candidate retrieval and balancing, but they must not be reused later as evidence about the target paper's contribution.

This source mode requires network access and the `openreview-py` and `requests` Python packages.

All source modes share the same completion rule: no initialized generated skill may be packaged from a real corpus unless every selected PDF-backed paper has `llm_deep_reading.status="complete"` and `deep_read_workflow_alignment="llm-full-paper-deep-read"` in the per-paper manifest. Abstract-only candidates never satisfy this gate by themselves.
