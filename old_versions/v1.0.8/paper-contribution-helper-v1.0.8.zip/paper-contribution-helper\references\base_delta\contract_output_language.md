# Contract: Output Language

- Main report language: Chinese.
- Use Chinese for diagnosis, reasoning, comparisons, rankings, risks, and methodology.
- Use English only for text that may be pasted into a paper or rebuttal.
- Save downloadable reports as UTF-8 Markdown. For target-paper public reports in generated skills, prefer the `load_safe_public_report` path emitted by `scripts/analyze_new_pdf.py`; write it as UTF-8 with BOM so Windows/Markdown clients can load it reliably.
