#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any


def engine_dir() -> Path:
    return Path(__file__).resolve().parent


def display_path(path: Path) -> str:
    try:
        return path.resolve().relative_to(Path.cwd().resolve()).as_posix()
    except ValueError:
        return path.name


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def manifest_complete(run_dir: Path) -> tuple[int, int]:
    manifest = run_dir / "analysis" / "per_paper_analysis_manifest.jsonl"
    records = load_jsonl(manifest)
    complete = sum(1 for record in records if isinstance(record.get("llm_deep_reading"), dict) and record["llm_deep_reading"].get("status") == "complete")
    return complete, len(records)


def ensure_project_analysis(run_dir: Path, state_dir: Path, chunk_chars: int, timeout: int) -> None:
    run([sys.executable, str(engine_dir() / "validate_project_corpus.py"), "--run-dir", str(run_dir)])
    manifest = run_dir / "analysis" / "per_paper_analysis_manifest.jsonl"
    if not manifest.exists():
        run(
            [
                sys.executable,
                str(engine_dir() / "analyze_extracted_papers.py"),
                "--out-dir",
                str(run_dir),
                "--state-dir",
                str(state_dir),
                "--llm-deep-read-mode",
                "optional",
                "--llm-provider",
                "off",
                "--llm-chunk-chars",
                str(chunk_chars),
                "--llm-timeout",
                str(timeout),
            ]
        )


def prepare_packets(run_dir: Path, chunk_chars: int, overlap_chars: int) -> Path:
    packet_dir = run_dir / "analysis" / "assistant_deep_read_packets"
    queue = packet_dir / "queue.jsonl"
    if not queue.exists():
        run(
            [
                sys.executable,
                str(engine_dir() / "prepare_assistant_deep_read_packets.py"),
                "--run-dir",
                str(run_dir),
                "--chunk-chars",
                str(chunk_chars),
                "--overlap-chars",
                str(overlap_chars),
            ]
        )
    return queue


def import_records_if_available(run_dir: Path, records_jsonl: Path, require_all: bool, chunk_chars: int, timeout: int) -> bool:
    if not records_jsonl.exists() or records_jsonl.stat().st_size == 0:
        return False
    cmd = [
        sys.executable,
        str(engine_dir() / "import_assistant_deep_read_records.py"),
        "--run-dir",
        str(run_dir),
        "--records-jsonl",
        str(records_jsonl),
        "--llm-chunk-chars",
        str(chunk_chars),
        "--llm-timeout",
        str(timeout),
    ]
    if require_all:
        cmd.append("--require-all")
    run(cmd)
    return True


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Continue a project run through current-assistant local deep reading when automated LLM backends are unavailable.")
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--state-dir", type=Path, default=None)
    parser.add_argument("--records-jsonl", type=Path, default=None)
    parser.add_argument("--chunk-chars", type=int, default=45000)
    parser.add_argument("--overlap-chars", type=int, default=1200)
    parser.add_argument("--llm-timeout", type=int, default=240)
    parser.add_argument("--require-all", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run_dir = args.run_dir.resolve()
    state_dir = (args.state_dir or run_dir / "analysis" / "assistant_local_state").resolve()
    records_jsonl = (args.records_jsonl or run_dir / "analysis" / "assistant_deep_read_records.jsonl").resolve()

    ensure_project_analysis(run_dir, state_dir, args.chunk_chars, args.llm_timeout)
    before_complete, before_total = manifest_complete(run_dir)
    queue = prepare_packets(run_dir, args.chunk_chars, args.overlap_chars)
    imported = import_records_if_available(run_dir, records_jsonl, args.require_all, args.chunk_chars, args.llm_timeout)
    after_complete, after_total = manifest_complete(run_dir)

    if after_total and after_complete == after_total:
        stage = "llm_deep_read_complete"
        next_action = "continue_to_synthesis_and_packaging"
    elif imported:
        stage = "assistant_records_imported_partial"
        next_action = "read_remaining_packets_and_append_missing_records"
    else:
        stage = "waiting_for_current_assistant_read"
        next_action = "current assistant must read queue packet/chunk files, write assistant_deep_read_records.jsonl, then rerun this script"

    print(
        json.dumps(
            {
                "schema_version": "1.0",
                "run_dir": display_path(run_dir),
                "stage": stage,
                "next_action": next_action,
                "queue": display_path(queue),
                "records_jsonl": display_path(records_jsonl),
                "before_complete": before_complete,
                "before_total": before_total,
                "after_complete": after_complete,
                "after_total": after_total,
                "imported_records": imported,
                "terminal_blocker": False,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
