#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import re
import shutil
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


INDEX_FIELDS = [
    "paper_key",
    "title",
    "year",
    "venue",
    "source_kind",
    "source_url",
    "categories",
    "risk_tier",
    "risk_score",
    "novelty_score",
    "combo_score",
    "candidate_flags",
    "incremental_types",
    "screening_reason",
    "evidence_snippets",
    "pdf_available",
    "review_available",
    "reply_available",
    "material_dir",
    "domain_score",
    "candidate_role",
    "evidence_level",
    "screening_confidence",
    "reference_potential_score",
    "surface_pattern",
    "positive_framing_signals",
    "risk_signals",
    "needs_pdf_before_casebook",
    "semantic_screening_status",
    "pdf_url",
]

RISK_PATTERNS: dict[str, list[tuple[str, int, str]]] = {
    "abc_combination": [
        (r"\b(combine|combines|combined|combining|integrate|integrates|integrated|integrating)\b", 2, "combine/integrate"),
        (r"\b(hybrid|unify|unifies|unified|fusion)\b", 2, "hybrid/unified"),
        (r"plug-and-play|modular", 1, "plug-and-play/modular"),
        (r"\b[A-Za-z0-9]+[+][A-Za-z0-9]+(?:[+][A-Za-z0-9]+)?", 3, "literal A+B"),
    ],
    "transfer_or_light_adaptation": [
        (r"\badapt(s|ed|ing)?\b.*\b(to|for)\b", 2, "adapted to setting"),
        (r"\bextend(s|ed|ing)?\b.*\b(to|for)\b|extension of", 2, "extension"),
        (r"based on|builds? on|variant of|transfer learning|new setting", 2, "prior-method adaptation"),
    ],
    "engineering_or_efficiency": [
        (r"efficien(t|cy)|scalab(le|ility)|runtime|memory|communication cost|computation cost", 2, "efficiency/system"),
        (r"deployment|practical implementation|system optimization|engineering", 2, "deployment/engineering"),
    ],
    "benchmark_or_dataset": [
        (r"benchmark|dataset|evaluation protocol|empirical study|leaderboard", 1, "benchmark/dataset"),
        (r"ablation|baseline|stress test", 1, "evaluation evidence"),
    ],
}

FRAMING_PATTERNS: list[tuple[str, int, str]] = [
    (r"failure mode|failure case|bottleneck|limitation|challenge", 3, "failure-mode framing"),
    (r"missing interface|interface|bridge|close[s]? the gap|gap between", 3, "interface/gap framing"),
    (r"assumption|relax(?:es|ing)?|underexplored setting|previous methods assume", 3, "assumption framing"),
    (r"principled|theoretical|formalize|formulation|objective", 2, "principled formulation"),
    (r"robust|heterogeneous|non[- ]iid|label scarcity|scarce labels|deployment constraint", 2, "regime pressure"),
    (r"evidence chain|diagnostic|protocol|controlled comparison|fair comparison", 2, "evidence protocol"),
]


def clean(text: Any) -> str:
    text = "" if text is None else str(text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def slugify(text: str, max_len: int = 80) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-").lower()
    return (text[:max_len].strip("-") or "paper")


def split_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [clean(item) for item in value if clean(item)]
    text = clean(value)
    if not text:
        return []
    return [part.strip() for part in re.split(r"[;,|]", text) if part.strip()]


def read_manifest(path: Path) -> list[dict[str, Any]]:
    suffix = path.suffix.lower()
    if suffix == ".jsonl":
        rows = []
        for line_no, line in enumerate(path.read_text(encoding="utf-8-sig", errors="replace").splitlines(), 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise SystemExit(f"Invalid JSONL at {path}:{line_no}: {exc}") from exc
        return rows
    if suffix == ".json":
        data = json.loads(path.read_text(encoding="utf-8-sig", errors="replace"))
        if isinstance(data, list):
            return [dict(item) for item in data]
        if isinstance(data, dict) and isinstance(data.get("papers"), list):
            return [dict(item) for item in data["papers"]]
        raise SystemExit("--abstract-manifest JSON must be a list or an object with a papers list")
    if suffix == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            return [dict(row) for row in csv.DictReader(handle)]
    raise SystemExit("--abstract-manifest must be .jsonl, .json, or .csv")


def match_patterns(text: str, patterns: list[tuple[str, int, str]]) -> tuple[int, list[str]]:
    score = 0
    hits: list[str] = []
    for pattern, weight, label in patterns:
        if re.search(pattern, text, flags=re.IGNORECASE):
            score += weight
            hits.append(label)
    return score, hits


def domain_score(record: dict[str, Any], focus_domains: list[str]) -> tuple[int, list[str]]:
    haystack = " ".join(
        [
            clean(record.get("title")),
            clean(record.get("abstract")),
            clean(record.get("primary_area")),
            " ".join(split_list(record.get("keywords"))),
        ]
    ).lower()
    if not focus_domains:
        return 1, ["no focus domain filter supplied"]
    score = 0
    reasons: list[str] = []
    for domain in focus_domains:
        parts = [part for part in re.split(r"[\s,;/_-]+", domain.lower()) if len(part) > 2]
        hits = [part for part in parts if part in haystack]
        if hits or domain.lower() in haystack:
            score += max(2, len(hits) * 2)
            reasons.append(f"{domain}: {', '.join(hits[:4]) or 'phrase match'}")
    return score, reasons


def classify_record(record: dict[str, Any], focus_domains: list[str]) -> dict[str, Any]:
    text = " ".join(
        [
            clean(record.get("title")),
            clean(record.get("abstract")),
            clean(record.get("tldr") or record.get("TLDR")),
            clean(record.get("primary_area")),
            " ".join(split_list(record.get("keywords"))),
        ]
    )
    d_score, d_reasons = domain_score(record, focus_domains)
    risk_score = 0
    risk_labels: list[str] = []
    surface: list[str] = []
    for group, patterns in RISK_PATTERNS.items():
        score, hits = match_patterns(text, patterns)
        if score:
            risk_score += score
            risk_labels.append(group)
            surface.extend(hits)
    framing_score, framing_hits = match_patterns(text, FRAMING_PATTERNS)

    explicit_role = clean(record.get("candidate_role") or record.get("reference_role"))
    allowed_roles = {"positive_framing", "contested_accepted", "negative_risk", "domain_reference", "unclear"}
    if explicit_role in allowed_roles:
        role = explicit_role
        confidence = clean(record.get("screening_confidence")) or "medium"
        semantic_status = clean(record.get("semantic_screening_status")) or "semantic_screened_from_manifest"
    elif d_score <= 0:
        role = "unclear"
        confidence = "low"
        semantic_status = "heuristic_pre_screen_only_requires_codex_semantic_review"
    elif framing_score >= 4 and risk_score >= 1:
        role = "positive_framing"
        confidence = "medium"
        semantic_status = "heuristic_pre_screen_only_requires_codex_semantic_review"
    elif framing_score >= 5:
        role = "positive_framing"
        confidence = "medium"
        semantic_status = "heuristic_pre_screen_only_requires_codex_semantic_review"
    elif risk_score >= 4 and not framing_hits:
        role = "negative_risk"
        confidence = "medium"
        semantic_status = "heuristic_pre_screen_only_requires_codex_semantic_review"
    elif risk_score >= 1:
        role = "domain_reference"
        confidence = "low"
        semantic_status = "heuristic_pre_screen_only_requires_codex_semantic_review"
    else:
        role = "domain_reference" if d_score else "unclear"
        confidence = "low"
        semantic_status = "heuristic_pre_screen_only_requires_codex_semantic_review"

    reference_score = d_score + framing_score * 2 + min(risk_score, 5)
    if role == "negative_risk":
        reference_score -= 2
    return {
        "domain_score": d_score,
        "domain_reasons": d_reasons,
        "candidate_role": role,
        "screening_confidence": confidence,
        "reference_potential_score": reference_score,
        "risk_score": float(risk_score),
        "risk_signals": risk_labels,
        "surface_pattern": surface,
        "positive_framing_signals": framing_hits,
        "semantic_screening_status": semantic_status,
    }


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=INDEX_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            normalized = dict(row)
            for key, value in list(normalized.items()):
                if isinstance(value, list):
                    normalized[key] = "; ".join(str(item) for item in value)
            writer.writerow(normalized)


def local_pdf_path(record: dict[str, Any], manifest_dir: Path) -> Path | None:
    raw = clean(record.get("pdf_path") or record.get("local_pdf") or record.get("pdf_file"))
    if not raw:
        return None
    path = Path(raw)
    if not path.is_absolute():
        path = manifest_dir / path
    return path.resolve() if path.exists() else None


def download_pdf(url: str, out_path: Path, timeout: int) -> tuple[bool, str]:
    if not url:
        return False, "no pdf_url"
    request = urllib.request.Request(url, headers={"User-Agent": "paper-contribution-helper/1.0"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = response.read()
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return False, str(exc)
    if not data.startswith(b"%PDF"):
        return False, "download did not look like a PDF"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(data)
    return True, url


def build_row(record: dict[str, Any], screening: dict[str, Any], key: str, material_dir: str = "") -> dict[str, Any]:
    pdf_available = bool(material_dir)
    role = screening["candidate_role"]
    risk_tier = "medium" if role in {"positive_framing", "negative_risk"} else "low"
    return {
        "paper_key": key,
        "title": clean(record.get("title")) or key,
        "year": clean(record.get("year")),
        "venue": clean(record.get("venue")),
        "source_kind": "web-abstract-pdf-mixed",
        "source_url": clean(record.get("source_url") or record.get("url")),
        "categories": "; ".join(screening["domain_reasons"]),
        "risk_tier": risk_tier,
        "risk_score": screening["risk_score"],
        "novelty_score": 0,
        "combo_score": screening["risk_score"] if "abc_combination" in screening["risk_signals"] else 0,
        "candidate_flags": [role, screening["semantic_screening_status"]],
        "incremental_types": screening["risk_signals"] or [role],
        "screening_reason": screening["domain_reasons"] + screening["positive_framing_signals"] + screening["risk_signals"],
        "evidence_snippets": [clean(record.get("abstract"))[:300]] if clean(record.get("abstract")) else [],
        "pdf_available": pdf_available,
        "review_available": False,
        "reply_available": False,
        "material_dir": material_dir,
        "domain_score": screening["domain_score"],
        "candidate_role": role,
        "evidence_level": "pdf_available" if pdf_available else "abstract_only",
        "screening_confidence": screening["screening_confidence"],
        "reference_potential_score": screening["reference_potential_score"],
        "surface_pattern": screening["surface_pattern"],
        "positive_framing_signals": screening["positive_framing_signals"],
        "risk_signals": screening["risk_signals"],
        "needs_pdf_before_casebook": not pdf_available,
        "semantic_screening_status": screening["semantic_screening_status"],
        "pdf_url": clean(record.get("pdf_url") or record.get("pdf")),
    }


def prepare_material(record: dict[str, Any], row: dict[str, Any], run_dir: Path, source_pdf: Path) -> None:
    material_dir = run_dir / row["material_dir"]
    material_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_pdf, material_dir / "paper.pdf")
    metadata = {
        "title": row["title"],
        "abstract": clean(record.get("abstract")),
        "year": row["year"],
        "venue": row["venue"],
        "authors": split_list(record.get("authors")),
        "keywords": split_list(record.get("keywords")),
        "primary_area": clean(record.get("primary_area")),
        "source_url": row["source_url"],
        "pdf_url": row["pdf_url"],
        "source_kind": "web-abstract-pdf-mixed",
        "candidate_role": row["candidate_role"],
        "screening_confidence": row["screening_confidence"],
    }
    write_json(material_dir / "submission.json", metadata)
    write_json(
        material_dir / "source_status.json",
        {
            "schema_version": "1.0",
            "source_kind": "web-abstract-pdf-mixed",
            "source_url": row["source_url"],
            "pdf_url": row["pdf_url"],
            "pdf_available": True,
            "metadata_available": True,
            "reviews_missing": True,
            "replies_missing": True,
            "review_attack_mode": "simulated-review-only",
            "candidate_role": row["candidate_role"],
            "evidence_level": "pdf_available",
            "semantic_screening_status": row["semantic_screening_status"],
            "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        },
    )
    write_json(material_dir / "candidate_screening.json", row)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create a project corpus run from web abstract records with partial PDF availability.")
    parser.add_argument("--abstract-manifest", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--focus-domains", nargs="*", default=[])
    parser.add_argument("--years", nargs="*", default=[])
    parser.add_argument("--cap", type=int, default=100)
    parser.add_argument("--download-timeout", type=int, default=60)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    manifest_path = args.abstract_manifest.resolve()
    run_dir = args.run_dir.resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    for rel in ["discovery", "index", "materials/_by_paper", "logs", "reports"]:
        (run_dir / rel).mkdir(parents=True, exist_ok=True)

    raw_records = read_manifest(manifest_path)
    discovery_rows: list[dict[str, Any]] = []
    pdf_rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    temp_pdf_dir = run_dir / "discovery" / "downloaded_pdfs"

    for idx, record in enumerate(raw_records, 1):
        title = clean(record.get("title")) or f"paper-{idx}"
        key = clean(record.get("paper_key")) or f"web_{idx:04d}_{slugify(title, 48)}"
        screening = classify_record(record, args.focus_domains)
        row = build_row(record, screening, key)
        discovery_rows.append(row)

    eligible = [
        (row, raw_records[idx])
        for idx, row in enumerate(discovery_rows)
        if row["candidate_role"] in {"positive_framing", "contested_accepted", "domain_reference", "negative_risk"}
        and row["domain_score"]
    ]
    eligible.sort(key=lambda item: float(item[0]["reference_potential_score"]), reverse=True)

    for row, record in eligible:
        if len(pdf_rows) >= args.cap:
            break
        source_pdf = local_pdf_path(record, manifest_path.parent)
        if source_pdf is None:
            pdf_url = clean(record.get("pdf_url") or record.get("pdf"))
            if pdf_url:
                downloaded = temp_pdf_dir / f"{row['paper_key']}.pdf"
                ok, message = download_pdf(pdf_url, downloaded, args.download_timeout)
                if ok:
                    source_pdf = downloaded
                else:
                    failures.append({"paper_key": row["paper_key"], "stage": "download_pdf", "pdf_url": pdf_url, "error": message})
        if source_pdf is None:
            continue
        material_rel = (Path("materials") / "_by_paper" / row["paper_key"]).as_posix()
        material_row = build_row(record, classify_record(record, args.focus_domains), row["paper_key"], material_rel)
        prepare_material(record, material_row, run_dir, source_pdf)
        pdf_rows.append(material_row)

    write_jsonl(run_dir / "discovery" / "abstract_candidates.jsonl", discovery_rows)
    write_csv(run_dir / "index" / "all_candidates.csv", discovery_rows)
    write_csv(run_dir / "index" / "abstract_only_candidates.csv", [row for row in discovery_rows if not any(row["paper_key"] == pdf_row["paper_key"] for pdf_row in pdf_rows)])
    write_csv(run_dir / "index" / "screened_incremental_candidates.csv", pdf_rows)
    write_jsonl(run_dir / "logs" / "failures.jsonl", failures)
    write_json(
        run_dir / "config.json",
        {
            "schema_version": "1.0",
            "source_kind": "web-abstract-pdf-mixed",
            "manifest": str(manifest_path),
            "focus_domains": args.focus_domains,
            "years": args.years,
            "abstract_record_count": len(discovery_rows),
            "pdf_material_count": len(pdf_rows),
            "screening_policy": "keyword_recall_plus_semantic_review_required",
            "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        },
    )
    print(
        json.dumps(
            {
                "run_dir": str(run_dir),
                "abstract_record_count": len(discovery_rows),
                "pdf_material_count": len(pdf_rows),
                "failures": len(failures),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
