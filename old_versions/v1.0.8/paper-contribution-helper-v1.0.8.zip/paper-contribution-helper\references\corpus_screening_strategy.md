# Corpus Screening Strategy

Use this module when selecting reference papers for a generated helper skill, especially when the available sources are web abstracts, search-result metadata, arXiv records, publisher pages, partial PDFs, or OpenReview-like records with reviews.

## Goal

Screen for `contribution-reframing-useful` papers, not merely papers that look weak, incremental, or component-compositional.

The generated helper should learn how to improve contribution framing. Therefore, prioritize papers that show how a surface-level weak contribution can be reframed, defended, scoped, or evidenced. Do not treat obviously weak papers as positive templates unless full-paper or review evidence shows a successful packaging move.

## Case Roles

Assign one role per candidate after semantic inspection:

- `positive_framing`: The paper has a surface risk such as A+B/C, transfer, engineering, or benchmark contribution, but its abstract/full paper frames the work through a stronger problem pressure, missing interface, assumption relaxation, failure-mode repair, evidence protocol, or deployment constraint.
- `contested_accepted`: Reviews or meta-review question novelty, contribution, baselines, mechanism, or scope, but the final decision/rebuttal/meta-review shows a defensible acceptance path.
- `negative_risk`: The paper visibly exposes weak contribution framing and does not show a successful defense in available evidence. Use only for reviewer attack taxonomy, risky wording, and failure-pattern examples.
- `domain_reference`: The paper is field-relevant but does not clearly inform contribution reframing. Keep it for background only unless full-paper reading reveals a usable story pattern.
- `unclear`: The abstract/metadata is insufficient. Do not package as reusable knowledge until PDF/review evidence resolves the role.

## Evidence Tiers

- `abstract_only`: Title, abstract, keywords, venue, source URL, and optional PDF URL are available, but no PDF was read. Use for discovery and semantic pre-screening only.
- `pdf_available`: A PDF is available or downloaded. The paper may enter a project run, but it is still not reusable knowledge.
- `pdf_deep_read_complete`: The selected PDF has complete full-paper deep-read artifacts and satisfies the generated skill contract. Only this tier may enter the final anonymous casebook.
- `review_evidence_available`: Public reviews, author replies, meta-review, or decision are available. Use this to identify `contested_accepted` and real reviewer attack patterns.

## Screening Pipeline

1. Recall broadly with source-specific metadata and lightweight keyword rules.
2. Preserve every recalled abstract/metadata record in `discovery/`, including source URL, PDF URL, and screening notes.
3. Run semantic screening over the abstract/metadata. Prefer Codex/current-assistant semantic analysis when the corpus is small or mixed-source. Keyword hits alone must not assign positive case roles.
4. Attempt to obtain PDFs for high-potential candidates. Downloaded PDFs become project files.
5. Create `materials/_by_paper/<paper_key>/` only for candidates with a real PDF and `submission.json`/`source_status.json`.
6. Run extraction, rule pre-pass, and full-paper deep-read for every selected PDF.
7. Synthesize reusable anonymous resources only after every selected case reports `llm_deep_reading.status="complete"`.

## Keyword Matching Boundary

Keyword matching is acceptable for recall:

- A+B/C/composition: `combine`, `integrate`, `hybrid`, `unify`, `plug-and-play`, literal `A+B`.
- Transfer/light adaptation: `adapt`, `extend`, `transfer`, `based on`, `variant of`, `new setting`.
- Engineering/efficiency: `efficient`, `scalable`, `runtime`, `memory`, `communication cost`, `deployment`.
- Benchmark/evidence: `benchmark`, `dataset`, `evaluation protocol`, `ablation`, `baseline`.

Keyword matching is not acceptable for final judgment. Strong papers often use these words. Weak papers often avoid them. Always ask what the paper is doing with the component:

- Does it close a missing interface?
- Does it repair a known failure mode?
- Does it relax an assumption?
- Does it define a new evaluation contract?
- Does it convert engineering constraints into a bounded scientific claim?
- Does it show a reviewer-facing evidence chain?

## Preferred Reference Mix

For a generated helper, prefer this balance when materials are available:

- 50-70% `positive_framing`;
- 20-40% `contested_accepted`;
- 10-20% `negative_risk`;
- optional `domain_reference` only when needed for coverage.

If only abstracts are available, stop at candidate-screening artifacts and report that final helper packaging requires PDFs. Do not fabricate casebook entries from abstracts.

## Output Labels

Use these labels in indexes, manifests, and status reports:

- `candidate_role`;
- `evidence_level`;
- `screening_confidence`;
- `reference_potential_score`;
- `surface_pattern`;
- `positive_framing_signals`;
- `risk_signals`;
- `needs_pdf_before_casebook`;
- `semantic_screening_status`.

## Reporting Rule

When explaining a selected reference paper, distinguish:

- surface pattern: what makes the paper look incremental, compositional, engineering-heavy, or transferred;
- useful reframing move: what makes it useful as a contribution-packaging reference;
- evidence boundary: abstract-only, full PDF, review/reply, or unread;
- reuse role: positive template, contested defense case, negative risk example, or background.
