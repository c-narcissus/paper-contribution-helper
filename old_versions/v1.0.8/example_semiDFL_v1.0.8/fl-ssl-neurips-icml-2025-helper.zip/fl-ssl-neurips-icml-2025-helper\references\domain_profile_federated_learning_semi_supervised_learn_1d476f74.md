# Initialized Delta Contribution Domain Profile

- Updated at: 2026-05-24T10:47:42
- Source kind: `project-corpus`
- Domain scope: `computer-science`
- Focus domains: `federated learning`, `semi-supervised learning`
- Years: `2025`
- Paper count: 20
- Evidence coverage: see `.delta-contribution-reframer/state/per_paper_analysis_state.json`; reusable knowledge is stored as anonymous project-local resources.

## Category Counts

| Category | Count |
|---|---:|
| `Other` | 20 |

## Incremental Modes

| Mode | Count |
|---|---:|
| `engineering_or_efficiency` | 20 |
| `evidence_or_benchmark` | 20 |
| `transfer_or_light_adaptation` | 20 |
| `abc_combination` | 19 |
| `low_novelty_or_incremental` | 9 |

## Review Attack Patterns

| Attack | Count |
|---|---:|
| `ablation_evidence` | 20 |
| `baseline_fairness` | 20 |
| `cost_efficiency` | 20 |
| `experiment_scope` | 20 |
| `novelty_incrementality` | 20 |
| `reproducibility` | 20 |
| `abc_or_mechanism` | 19 |

## Reply Move Patterns

| Reply move | Count |
|---|---:|
| `new_experiment_or_result` | 7 |
| `setting_boundary_defense` | 7 |
| `claim_softening_or_clarification` | 6 |
| `existing_evidence_resurfacing` | 6 |

## LLM Deep-Read Coverage

| LLM status | Count |
|---|---:|
| `complete` | 20 |

## Reusable Anonymous Case Labels

| Case label | Examples | Route use | Dominant domains | Common attacks |
|---|---:|---|---|---|
| `combination-method-needs-mechanism-claim` | 10 | surrogate / coupling / interface route | `Other` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `incremental-gain-with-ablation-pressure` | 9 | failure-mode / mechanism-evidence route | `Other` | `novelty_incrementality`, `baseline_fairness`, `ablation_evidence` |
| `light-transfer-with-scope-generalization-risk` | 1 | scope-boundary / transfer route | `Other` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `baseline-contract-fairness-defense` | 20 | baseline-contract route | `Other` | `novelty_incrementality`, `baseline_fairness`, `ablation_evidence` |
| `evidence-system-coverage-defense` | 20 | evidence-system route | `Other` | `novelty_incrementality`, `baseline_fairness`, `ablation_evidence` |
| `efficiency-system-claim-under-cost-scrutiny` | 20 | quality-cost / deployment-boundary route | `Other` | `novelty_incrementality`, `baseline_fairness`, `ablation_evidence` |
| `scope-generalization-boundary-defense` | 20 | scope-boundary route | `Other` | `novelty_incrementality`, `baseline_fairness`, `ablation_evidence` |

## Evidence Rules

All reusable cases are anonymous aggregates. Use `simulated-review` only when applying these patterns to a new target paper without real reviews.
