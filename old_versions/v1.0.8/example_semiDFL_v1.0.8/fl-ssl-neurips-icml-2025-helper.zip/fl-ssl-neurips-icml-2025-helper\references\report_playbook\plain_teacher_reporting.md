# Plain Teacher-Style Reporting Contract

Default target-paper reports must read like a careful advisor explaining the paper to the author, not like an audit checklist.

## Default Voice

- Write in direct, plain Chinese.
- Use short paragraphs and concrete examples before any table.
- Use the pattern: conclusion first -> why this happens -> how to fix it -> what to change first.
- English is only for manuscript-ready or rebuttal-ready snippets.
- Prefer "这篇文章现在容易被读成..." and "更好的讲法是..." style explanations over abstract labels.

## Default Shape

Unless the user explicitly asks for a detailed technical report, produce a readable main report with these sections:

1. 先说结论。
2. 这篇论文真正解决什么问题。
3. 为什么现在容易被认为是增量创新或 A+B+C 组合。
4. 更好的核心讲法是什么。
5. 摘要、引言、贡献 bullet、方法图和实验章节应该怎么改。
6. 最可能被审稿人攻击的点，以及怎么回应。
7. 优先修改清单，按无需新实验、复用现有材料、需要新实验三层写。
8. 可直接放进论文或 rebuttal 的英文片段。

## Complexity Budget

- Default report should use at most two compact tables.
- Do not force six story routes into the main text. Give one recommended main route, one backup route, and unsupported/risky routes only when they matter.
- Do not include a full route-comparison matrix unless the user asks for "详细版", "完整路线比较", or "审稿防御矩阵".
- Do not include long anonymous case appendices by default. Mention only the relevant analogy pattern and its boundary.
- Keep the main report easy to read first; preserve extra audit details in an optional appendix only when needed.

## Required Rigor

Plain language does not mean shallow. The report must still:

- Ground claims in the target PDF.
- Explain why the current framing creates reviewer risk.
- Separate supported contribution, latent-but-supported reframing, and future-boundary claims.
- Avoid treating packaged anonymous cases as evidence about the target paper.
- Turn every major weakness into a concrete manuscript change.
