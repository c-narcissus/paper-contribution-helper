# Workflow: Target Paper Reframing

Use after initialization, or for a single user-provided paper that should be analyzed without updating the reusable knowledge base. The quality bar is defined in `contract_target_report_quality.md`. The default style is the plain advisor style in `references/report_playbook/plain_teacher_reporting.md`.

## Pre-Pass

1. Build a source ledger for the PDF, supplied reviews/replies, metadata, and unread sources.
2. Extract and inspect the PDF text first. Save intermediate artifacts when a writable output directory is available.
3. Run `scripts/analyze_new_pdf.py` when available, but treat it as a pre-pass only. Its pattern hits and scaffold are inputs to the final report, not the final report itself.
4. Load `references/anonymous_casebook.jsonl` and `references/per_pdf_report_synthesis.md` only as anonymous analogy resources. Do not use them as evidence about the target paper.

## Default Final Report

Write like a careful advisor talking to the author. Do not make the author read a route matrix before they understand the main point.

1. Start with a direct conclusion: whether the current contribution framing is weak, why, and what the better main story is.
2. Explain the target regime in plain Chinese: what problem the paper is really trying to repair, what old assumptions are unavailable, and why naive methods fail.
3. Explain why the current manuscript may look incremental, A+B+C, engineering-only, or old-method migration.
4. Recover the stronger evidence-bounded contribution. Name the mechanism/failure/interface/constrained-regime repair that makes the method more than a module list.
5. Give concrete rewrite advice for the abstract, introduction, contribution bullets, related-work boundary, method overview/Figure, and experiment organization.
6. Simulate the main reviewer attacks with practical responses. Include novelty/incrementality, A+B/C, baseline fairness, mechanism evidence, cost/scalability, scope, privacy/safety, or reproducibility only when relevant.
7. Provide Tier 0 / Tier 1 / Tier 2 revision priorities. Tier 0 should be useful even with no new experiments.
8. Include English manuscript/rebuttal snippets only when they are evidence-bounded and directly usable.

## Detailed Mode

If the user asks for a detailed report, complete route comparison, or reviewer-defense matrix, extend the report with:

- six story-route slots by default, marking unsupported routes clearly;
- route comparison table;
- per-route expansion with examples, evidence anchors, rewrite targets, boundaries, and snippets;
- full manuscript-trigger localization;
- rebuttal pattern library with risky wording to avoid;
- anonymous case appendix with borrowing paths and boundaries.

Do not ship a generic target report that merely follows section names. The final report must make paper-specific packaging decisions and explain the tradeoffs in language the author can immediately act on.
