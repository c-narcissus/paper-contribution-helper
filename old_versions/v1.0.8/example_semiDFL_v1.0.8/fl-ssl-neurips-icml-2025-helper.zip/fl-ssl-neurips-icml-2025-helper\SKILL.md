---
name: fl-ssl-neurips-icml-2025-helper
description: Self-contained author-side skill for reframing delta-sized or incremental research contributions in federated learning, semi-supervised learning using packaged anonymous base knowledge from 2025. Use when Codex needs to help package a new paper, diagnose novelty risk, simulate reviewer attacks, draft rebuttal-safe defenses, or evolve the local anonymous casebook from new PDFs without access to the old corpus PDFs.
---

# FL/SSL NeurIPS ICML 2025 Helper

This skill is self-contained. It has two modes:

- Packaged mode: use package-local anonymous base knowledge in `references/`.
- Blank-initializer mode: if packaged base knowledge is missing or the user wants a fresh corpus, use the embedded blank delta engine under `scripts/engine/` and `references/base_delta/`.

It never needs an external `delta-contribution-reframer` skill. It does not require old PDFs or old OpenReview data after packaged mode succeeds.

## Startup

Run `python scripts/startup_check.py --skill-dir <this-skill-dir>` when status is needed. If base resources are non-empty, the skill is usable.

## Supreme Operational Rule: Project Files First

Once PDFs, reviews, replies, metadata, or a corpus run exist in the workspace, treat them as project-internal files and continue from disk. External API, local command, and ACP/acpx backends are automation conveniences, not permission gates. If the current assistant can read the local files, it must continue validation, extraction, chunked deep reading, manifest updates, anonymous synthesis, and packaging as far as the file evidence allows.

Script-level backend gates are not workflow gates. A `not_run` deep-read status caused by missing automation is a handoff to current-assistant local-file processing, not a final blocker.

## Load On Demand

- Package contents and provenance limits: `references/knowledge_manifest.json`
- Evidence labels and no-fabrication rules: `references/evidence_policy.md`
- Update behavior from new PDFs: `references/evolution_policy.md`
- Task workflows: `references/usage_workflows.md`
- Corpus/reference screening when only abstracts or partial PDFs are available: `references/corpus_screening_strategy.md`
- Direct analysis from downloaded project corpus files: `references/project_corpus_direct_workflow.md`
- Current-assistant local deep reading when no callback backend is available: `references/assistant_local_deep_read_workflow.md`
- LLM deep-reading workflow for new initialization: `references/llm_deep_reading_workflow.md`
- ACP command-file backend only when API keys/local command backends are unavailable and ACP/acpx exists: `references/acp_command_file_workflow.md`
- Target-paper-guided domain inference: `references/base_delta/workflow_target_domain_inference.md`
- Target-report quality bar: `references/base_delta/contract_target_report_quality.md`
- Default target-report style: `references/report_playbook/plain_teacher_reporting.md`
- Reader-friendly detailed-report style: `references/report_playbook/reader_friendly_reporting.md`
- Report methodology dependencies: `references/report_playbook/positive_reframing_patterns.md`, `references/report_playbook/latent_contribution_mining.md`, `references/report_playbook/reviewer_attack_taxonomy.md`, `references/report_playbook/rebuttal_pattern_library.md`, and `references/report_playbook/github_review_skill_digest.md`
- Reusable patterns: `references/per_pdf_report_synthesis.md`, `references/llm_deep_read_synthesis.md`, and `references/anonymous_casebook.jsonl`
- Blank initialization workflows/contracts: `references/base_delta/`

## Routing

| User task | Action |
|---|---|
| PDF supplied without purpose | Ask whether to directly analyze the paper or use it as a domain seed for initializing/generating specialized reusable knowledge; do not run tools yet. |
| Directly analyze or reframe a target PDF | Follow `references/base_delta/workflow_target_paper_reframing.md`; use package casebook patterns as analogies only. |
| Simulate reviewer attacks | Mark as `simulated-review` unless real reviews are supplied. |
| Write rebuttal strategy | Ground in user-supplied reviews/replies or label missing sources. |
| Run target-paper report workflow | Run `scripts/analyze_new_pdf.py` as an extraction/pattern pre-pass, then produce the full target-paper report required by `workflow_target_paper_reframing.md`; save the user-facing final report to the script's `load_safe_public_report` path when present, otherwise to `public_report`. |
| Evolve local casebook | Run `scripts/evolve_casebook.py`; write project-local overlay by default. |
| Initialize from a downloaded corpus or project run | Treat the corpus as project files and follow `references/project_corpus_direct_workflow.md`; if no automated callback backend is available and the current assistant can read files, continue through `references/assistant_local_deep_read_workflow.md`. |
| Initialize from web abstracts or partial PDFs | Follow `references/corpus_screening_strategy.md`; keep abstract-only papers in discovery/pending status and only synthesize cases from selected PDFs after full-paper deep reading. |
| Initialize from scratch or generate specialized reusable knowledge | If the user does not know focus domains, first follow `workflow_target_domain_inference.md` on their target PDF as a domain seed only; then prefer downloaded project files through `references/project_corpus_direct_workflow.md`; use `scripts/engine/standardize_local_pdf_intake.py`, `validate_project_corpus.py`, `analyze_extracted_papers.py`, and `synthesize_initialized_resources.py`; run full-paper LLM deep-reading for every selected reference PDF before synthesis; follow `references/llm_deep_reading_workflow.md` and `references/base_delta/workflow_*`. |

For target-paper analysis, do not stop at the script output. The default final report must satisfy `contract_target_report_quality.md` in the plain teacher-style mode defined by `references/report_playbook/plain_teacher_reporting.md`: write like an advisor explaining the paper to the author, start with the conclusion, use plain Chinese, minimize tables, and focus on what the paper is trying to repair, why the current framing looks incremental or A+B/C, what the stronger contribution story is, what to rewrite first, likely reviewer attacks, tiered revision priorities, and evidence-bounded English snippets. Produce the older full matrix/report style only if the user explicitly asks for a detailed report, complete route comparison, or reviewer-defense matrix.

For domain-seed initialization, the target PDF is used only to infer fields/subfields for corpus screening and reusable skill generation. Do not produce a contribution report, story routes, reviewer attacks, rebuttal text, or manuscript edits unless the user explicitly chooses direct target-paper analysis.

For corpus initialization, treat downloaded PDFs and corpus folders as project files. Do not paste full PDF text or a full corpus into chat context; scripts must extract, chunk, save intermediate artifacts, and synthesize from manifests.

In initialization mode, once reference PDFs/reviews/replies are downloaded, provided, or standardized as a `project-run`/`local-pdf`, they are current project-internal files. Missing API keys or LLM backends may block only automated batch execution; they must not block current-assistant local-file validation, extraction, rule pre-pass, per-paper analysis folders, manifests, full-paper deep-read records, and explicit pending/failed LLM status artifacts.

Do not tell the user that a project-internal corpus cannot be analyzed merely because API/acpx/local-command automation is missing. Continue locally or name a concrete non-backend blocker, such as unreadable PDFs, missing files, or exhausted context after saved partial artifacts.

When automated deep-read backends are unavailable, run `scripts/engine/continue_local_deep_read.py --run-dir <run-dir> --require-all`. If it reports `waiting_for_current_assistant_read`, continue in the current task by reading packets, writing `assistant_deep_read_records.jsonl`, rerunning the coordinator/import step, then synthesizing and packaging. Do not end the task at backend absence or `not_run` status.

For corpus initialization, do not package initialized knowledge unless every selected PDF has `llm_deep_reading.status=complete` and `deep_read_workflow_alignment="llm-full-paper-deep-read"` in `analysis/per_paper_analysis_manifest.jsonl`. Rule-only analysis is a debug pre-pass, not an acceptable initialized corpus. If the current assistant is doing the reading, use assistant packet preparation, assistant-written JSONL validation, and import rather than treating the rule pre-pass as complete.

Do not use obviously weak incremental/A+B/C/engineering/transfer papers as positive templates merely because they match risk keywords. Prefer `positive_framing` and `contested_accepted` cases for reusable guidance; use `negative_risk` cases only for reviewer attack taxonomy and risky wording.

Keep hidden `.fl-ssl-neurips-icml-2025-helper/` paths for evidence artifacts and state. Return user-facing report references using `load_safe_public_report` when the pre-pass reports it; treat that value as a workspace-relative, portable path under `reports/`, not as a hardcoded machine absolute path. This mirror is written as UTF-8 with BOM to avoid clients failing to load hidden overlay paths, paths with spaces/non-ASCII characters, or non-BOM Markdown. Use `public_report` only when no load-safe mirror exists. Never expose internal drafting notes, placeholder text, or raw Windows drive paths as the user-facing report link.

When reporting generated skill, report, or ZIP/package locations, prefer workspace-relative paths. If the user explicitly needs an absolute Windows path, show it in a fenced code block or normalize it to forward slashes; do not place raw drive-letter paths containing `\_` in Markdown links or inline prose, because Markdown can render `\_skill_runtime` as `_skill_runtime` and visually remove the path separator.

Use Chinese for diagnosis, reasoning, ranking, and risks. Use English only for manuscript-facing snippets.
