# Contract: Target Report Quality

Generated skills must not answer a target-paper PDF request with a generic extraction summary. The final report must help the author understand why the paper may look incremental, recover a stronger evidence-bounded contribution story, and decide what to revise first.

## Default Report Mode: Plain Advisor Report

By default, use `references/report_playbook/plain_teacher_reporting.md`. The report should feel like a careful advisor explaining the paper to the author:

1. Start with the conclusion in plain Chinese.
2. Explain what the paper is really trying to repair under its constrained regime.
3. Explain why the current framing may look incremental, A+B+C, engineering-only, or old-method-to-new-scenario.
4. Recover the stronger contribution story, but keep it bounded by target-PDF evidence.
5. Tell the author how to rewrite the abstract, introduction, contribution bullets, method overview/Figure, related-work boundary, and experiments.
6. Simulate the most likely reviewer attacks and give practical defenses.
7. Give a Tier 0 / Tier 1 / Tier 2 revision plan.
8. Provide only evidence-bounded English snippets for manuscript or rebuttal use.

## Complexity Budget

- Do not force six story routes into the main report unless the user asks for a detailed route board.
- Do not use large comparison matrices by default. Use at most two compact tables when they genuinely make the advice easier to scan.
- Do not include a long anonymous case appendix by default. Mention only the relevant borrowing pattern and the boundary.
- Keep detailed audit material in an optional appendix or separate detailed report only when the user asks for it.

## Required Rigor

- The report must be paper-specific. Name the target regime, broken assumptions, modules, evidence anchors, tables/figures/appendix items, and claim boundaries from the target PDF where available.
- Do not list modules as the contribution. Explain the interaction, failure mode, interface, or constrained-regime repair that makes the modules necessary together.
- Separate `paper-explicit`, `latent-but-supported`, `story-level reframing`, and `future-boundary hook` claims in plain language.
- Do not stop at "missing evidence". Convert each gap into a concrete revision action and a reviewer-defense purpose.
- Include manuscript-facing English snippets only where they can be directly used in the paper or rebuttal.
- Use Chinese for diagnosis, reasoning, ranking, risks, anonymous analogies, and revision planning. Use English only for manuscript-facing and rebuttal-ready snippets.
- If the PDF text extraction is weak, say so and degrade the report to a partial audit rather than inventing evidence.
- State the source ledger and evidence boundary clearly. Treat packaged anonymous cases as analogy only, never as target-paper evidence.

## Detailed Mode

If the user explicitly asks for a detailed report, complete route comparison, reviewer-defense matrix, or full audit, add the older exhaustive structure:

- six ranked story-route slots, marking unsupported routes when needed;
- route comparison over novelty defense, evidence fit, A+B/C resistance, baseline control, mechanism control, cost/reproducibility, rewrite cost, and new-experiment pressure;
- per-route expansion with evidence anchors, rewrite targets, boundaries, and snippets;
- full reviewer attack table with why-asked, trigger, defense posture, and no-new-experiment repair;
- rebuttal pattern library with risky wording to avoid;
- anonymous case appendix with borrowing paths and boundaries.

## Failure Modes To Avoid

- Generic reports that could fit any paper.
- Reports that are complete but exhausting to read.
- Reports that hide the main recommendation behind many tables.
- Story sections that only provide route names or slogans.
- Reviewer attacks without practical manuscript repairs.
- English snippets that overclaim beyond the evidence boundary.
