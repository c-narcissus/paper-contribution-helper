# GitHub Research Skill Benchmark: Adapt, Do Not Copy

This file records how to learn from popular research-assistant repositories without directly importing their prompts, code, review style, or product assumptions. The target user is usually revising an early manuscript whose work may look like A+B+C component combination, incremental improvement, engineering optimization, light transfer, or old-method-new-setting adaptation.

## Core Rule

Do not use any external GitHub skill as a drop-in reviewer or writer. Extract only the method pattern, then test whether it helps this package's target paper type: evidence-bounded contribution reframing for a real manuscript.

Every borrowed pattern must pass three gates:

1. **Target-fit gate**: Does it help a weak or incremental-looking draft become clearer, better bounded, and more defensible?
2. **Evidence gate**: Does it force claims back to target-paper evidence, or does it encourage unsupported breadth/hype?
3. **Revision-action gate**: Does it produce concrete manuscript edits, risk disclosures, or experiments, rather than just a generic review/report?

## Benchmark Summary

| External project family | Useful idea | Why useful for this skill's target drafts | Main weakness for our target drafts | Adapted rule |
|---|---|---|---|---|
| STORM-style research writing | Perspective-guided questioning, outline before writing, multi-role knowledge exploration | A+B+C drafts often fail because authors did not ask from novelty, mechanism, baseline, and AC perspectives before writing | It is oriented toward broad article generation and knowledge synthesis; it can over-expand background and make a paper sound survey-like rather than contribution-specific | Use only for **reviewer-perspective question generation** and story-outline stress testing, not for final contribution claims |
| GPT-Researcher-style agent workflow | Planner → evidence collection → publisher; source tracking | Incremental/engineering drafts need a source ledger and closest-prior awareness before they can claim novelty | More sources do not equal scholarly novelty; web popularity can bias toward hype instead of closest-prior boundaries | Use as a **source-ledger and task orchestration pattern**; require closest-prior and target-paper evidence before rewriting claims |
| AI-Scientist-style automated review | Multiple reviewer passes, self-reflection, ensemble review | Early drafts benefit from several simulated reviewers because one generic critique misses fatal novelty/baseline/mechanism risks | Score-first or decision-first reviews can mislead authors; autonomous paper generation is outside the scope and may overfit to templates | Use as a **simulated review panel** with actionability, evidence anchors, and claim downgrades; do not output final accept/reject as authority |
| PaperQA/PaperQA2-style scientific RAG | PDF-grounded retrieval, citations, contradiction and retraction checks | Strong packaging must be claim-evidence-bounded; it must know whether citations actually support the claim | QA can answer local questions without deciding how to frame a contribution or how to repair a weak claim | Use for **claim-evidence binding**, citation sanity, and contradiction checks; every answer must convert into safe claim / unsafe overclaim / repair |
| PaperDebugger-style in-editor assistant | Read-only project access, inline comments, critique → revision loop, citation verification | Authors need to know exactly which abstract sentence, contribution bullet, method figure, or experiment paragraph triggers reviewer suspicion | Editor/plugin UX and automatic comment insertion are not portable to this skill; writing polish can distract from contribution risk | Use as **manuscript-trigger localization** and suggested comments; never auto-edit the author's manuscript |
| PeerQA-style peer-review QA | Reviewer-question answerability, unanswerable classification, evidence retrieval | Rebuttals fail when authors only list attacks but do not know which questions are currently answerable from the paper | A dataset/benchmark does not by itself provide revision strategy or contribution framing | Use as **Reviewer Question → Answerability → Repair Tier**; distinguish writing gap from evidence gap |
| SkillOpt-style skill optimization | Validation-gated skill evolution and rejected edit memory | This package evolves across cases; edits should be accepted only if they improve target report quality | It assumes benchmark tasks and objective metrics; contribution quality is partly judgment-based | Use as **review-gated package evolution**: keep a change log, reject edits that increase hype/genericness, and validate with package tests |

## Direct-Reuse Anti-Patterns

Avoid these patterns even if they work in the source project:

- turning the paper into a broad Wikipedia-style article;
- collecting many web sources without checking closest prior work and target-paper evidence;
- reporting an authoritative accept/reject decision instead of actionable revision priorities;
- letting RAG answer isolated questions without claim-risk repair;
- optimizing the skill against convenience or verbosity rather than manuscript defense quality;
- using popular-trend terms to rename old work without an evidence-backed bridge.

## Required Adaptation Output

When this benchmark is used during skill maintenance or report design, the assistant should output:

1. **External pattern**: the method idea being borrowed.
2. **Target-paper benefit**: why it helps A+B+C/incremental/engineering/light-transfer drafts.
3. **Target-paper danger**: how it could mislead this kind of draft.
4. **Adapted implementation**: the bounded rule added to this package.
5. **Do-not-copy boundary**: what is explicitly not imported.

## Default Adapted Modules

The following local playbooks implement the adapted—not copied—lessons:

- `claim_evidence_risk_map.md`
- `reviewer_question_answerability.md`
- `paper_logic_completeness_audit.md`
- `risk_self_disclosure_playbook.md`
- `frontier_topic_alignment.md`
- `simulated_review_panel.md`

Use them as local package rules. External GitHub projects remain inspiration only.
