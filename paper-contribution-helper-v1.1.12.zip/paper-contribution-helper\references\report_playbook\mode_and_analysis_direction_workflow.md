# Mode and Analysis-Direction Workflow

This playbook replaces the former default comprehensive route selector.

## Core idea

The skill should not decide whether to directly analyze a paper, build a new child skill, or update an existing child skill. The user chooses the work mode explicitly. A/B/C/D are analysis directions for the paper/PDF and can be combined.

## Work modes

- **模式1 - Build new child skill**: use target papers, related work, reviews, local PDFs, or a project run to build a quality-gated reusable domain helper. Selected A-D directions define which kinds of patterns the child skill should emphasize.
- **模式2 - Use internal/package knowledge for target-paper analysis**: analyze the current paper directly without generating a child skill. Run related-work intake and submission-context gates before the final report.
- **模式3 - Update existing child skill**: inspect the existing child skill, verify inheritance, quality-gate new sources, merge or regenerate, then run child regression checks.

## Analysis directions

- **A Contribution/related-work direction**: closest prior, novelty boundary, A+B+C risk, baseline relationship, claim-evidence-risk map.
- **B Layered revision/scientific elevation direction**: L0-L4 edits, failure mode, broken assumption, scientific question, research program.
- **C Reviewer/execution direction**: reviewer/AC attack preplay, answerability, minimal decisive experiments, edit-ready patches, revision loop.
- **D Literature/frontier/KB direction**: dynamic meta-graph, multi-hop retrieval plan, verified literature ledger, quality gate, frontier positioning, reusable pattern capture.

## Mode 1/3 corpus intake

For 模式1 and 模式3, require a child-skill corpus spec before discovery or packaging: research field(s), years/year range, per-year paper quantity, source venues/journals/official sites/databases, local folders/uploaded PDFs/project-run, and existing child skill when updating. Load `child_skill_corpus_intake_gate.md` and `field_year_balanced_sampling.md`. If multiple fields are supplied, keep the field×year quota balanced where verified sources exist. If fields or quotas are missing, ask; do not auto-build from vague sources.

## Parsing user replies

Accept compact replies such as:

```text
模式2，方向A+B+C+D
模式1，方向A+B，研究领域=___，年份=___，来源=___，本地资料=___
模式3，方向D，已有子skill=___，研究领域=___，年份=___，新增来源=___
```

If the mode is absent, ask the user to choose 模式1/2/3. If directions are absent, ask for A-D directions unless the user clearly says `全面分析`, in which case use A+B+C+D and state that assumption.

## Execution

After parsing:

- For 模式2 with any paper direction, run related-work intake and submission-context gates, then load only playbooks needed by selected A-D directions.
- For 模式1, first confirm the child-skill corpus spec, then build the child skill while preserving the selected A-D directions in the child knowledge manifest and generated reporting defaults.
- For 模式3, first inspect the existing child skill and confirm the update corpus spec, then update sources and rerun inheritance/regression checks.

## Evidence hygiene

External literature still requires visible user-provided sources or verified retrieval. Candidate papers inferred from references, related work, or frontier descriptions are `search-plan-only` until verified.
