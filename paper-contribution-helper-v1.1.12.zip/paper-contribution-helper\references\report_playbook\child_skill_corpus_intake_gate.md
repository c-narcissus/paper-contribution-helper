# Child Skill Corpus Intake Gate

Use this gate before 模式1 (build new child skill) or 模式3 (update existing child skill). The point is simple: do not build a professional reusable helper from vague "related papers". First pin down the corpus scope and the sampling quantity.

## Required user fields

Ask for these fields in a plain teacher-like way:

1. **Research field(s)**: one or more fields/subfields, e.g. `federated learning + semi-supervised learning`. Multiple fields are allowed.
2. **Years / year range**: e.g. `2022-2026`, or explicit years like `2022, 2023, 2024, 2025`. Multiple years are allowed and preferred for reusable skills.
3. **Per-year paper quantity**: how many papers to read per year. Examples: `每年10篇`, `每年每领域5篇`, or a grid such as `FL: 2023=5, 2024=5; SSL: 2023=5, 2024=5`.
4. **Sources**: conferences, journals, official pages, OpenReview venue, publisher site, arXiv category, benchmark page, or trusted database.
5. **Local materials**: uploaded PDFs, local PDF folder, project-run directory, metadata/reviews/rebuttals folder, or existing corpus manifest.
6. **Update target** for 模式3: existing child skill zip/folder, current version, what should be preserved, and what should be replaced or added.

Do not ask for a generic "quality requirement" in the startup template. Source quality is handled later by `source_quality_gate.md`; this gate is mainly about scope and quantity.

## Default OR semantics for multiple values

Treat multiple values as **OR candidate sets** by default:

- 多个研究领域：覆盖这些领域，尽量按领域×年份均衡采样；不是要求每篇论文同时属于所有领域。
- 多个年份：覆盖这些年份或年份范围；不是要求同一论文同时属于多个年份。
- 多个来源：从这些会议/期刊/官网/数据库中选择候选；不是要求每篇论文同时出现在所有来源。
- 多个本地资料：把它们都作为可用输入池；不是要求每篇论文在所有目录/资料里重复出现。

Only switch to AND/intersection semantics if the user explicitly says `AND`, `交集`, `必须同时满足`, or gives a strict filtering rule.

## Multi-field and multi-year balancing

If the user provides multiple fields, try to keep the corpus balanced across the `field × year` grid.

Example:

```text
研究领域 = federated learning; semi-supervised learning
年份 = 2022-2025
每年数量 = 每领域每年5篇
```

This means the intended quota is:

| Field | 2022 | 2023 | 2024 | 2025 |
|---|---:|---:|---:|---:|
| federated learning | 5 | 5 | 5 | 5 |
| semi-supervised learning | 5 | 5 | 5 | 5 |

If one field/year cell has too few verified papers, do not silently overfill it with weak or unrelated papers. Mark the deficit and optionally borrow from adjacent years or closely adjacent fields only after saying so.

## If information is missing

- If research fields are missing but a target PDF is supplied, infer 1-3 candidate fields and ask the user to approve before discovery/packaging.
- If years are missing, ask for one or more years or a range. Do not silently default to all years for a professional skill.
- If per-year quantity is missing, ask for it. A reasonable fallback can be proposed, but do not package as production-ready until the user accepts the quota.
- If venues/journals/sources are missing, ask whether to use field-standard top venues/journals, user-provided local PDFs, or discovery-only sources.
- If the user is in ChatGPT Web and mentions a local directory, ask them to upload the PDFs or run this in Codex/project mode; do not pretend the directory is accessible.
- If the user wants a quick exploratory draft, label the output `discovery-only` or `experimental`, not production-ready.

## Corpus roles

Separate sources by role:

| Role | Use |
|---|---|
| `defense_corpus` | accepted papers/reviews for contribution framing and reviewer defense |
| `evaluation_corpus` | benchmark, metric, baseline, protocol, and reproducibility norms |
| `negative_risk_corpus` | weak or rejected-style examples used only as warning patterns |
| `frontier_corpus` | latest papers used for trend/collision/search-plan, not positive templates unless verified and quality-gated |
| `local_author_corpus` | user-provided papers, drafts, reviews, rebuttals, and related work |

## Output before building/updating

Before running build/update, summarize:

```text
子skill语料范围确认：
- 研究领域：...
- 年份范围：...
- 每年数量 / 每领域每年数量：...
- 领域×年份配额表：...
- 来源会议/期刊/官网/数据库：...
- 本地资料：...
- 更新目标（模式3）：...
- 配额不足或尚未验证的部分：...
```

Only after this confirmation should the skill continue to source screening, full-paper deep reading, synthesis, packaging, and child regression checks.
