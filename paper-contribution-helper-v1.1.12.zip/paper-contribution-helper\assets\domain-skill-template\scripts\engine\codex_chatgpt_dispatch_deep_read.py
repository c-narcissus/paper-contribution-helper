#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from common import write_json
from validate_assistant_deep_read_records import REQUIRED_KEYS, REQUIRED_ALIGNMENT, load_jsonl, validate


def display_path(path: Path, root: Path | None = None) -> str:
    roots = [root, Path.cwd()] if root else [Path.cwd()]
    for base in roots:
        if not base:
            continue
        try:
            return path.resolve().relative_to(base.resolve()).as_posix()
        except ValueError:
            continue
    return path.as_posix()


def write_jsonl(path: Path, records: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            line = json.dumps(record, ensure_ascii=False).replace(chr(0x2028), "\\u2028").replace(chr(0x2029), "\\u2029")
            handle.write(line + "\n")


def load_queue(run_dir: Path, packet_dir: Path) -> list[dict[str, Any]]:
    queue_path = packet_dir / "queue.jsonl"
    if not queue_path.exists():
        raise SystemExit(f"Missing assistant packet queue: {queue_path}")
    queue = load_jsonl(queue_path)
    if not queue:
        raise SystemExit(f"Packet queue is empty: {queue_path}")
    missing = []
    for item in queue:
        packet = run_dir / str(item.get("packet", ""))
        request = run_dir / str(item.get("request", ""))
        if not packet.exists():
            missing.append(packet)
        if not request.exists():
            missing.append(request)
    if missing:
        preview = ", ".join(display_path(path, run_dir) for path in missing[:10])
        raise SystemExit(f"Dispatch queue references missing files: {preview}")
    return queue


def chunked(items: list[dict[str, Any]], size: int) -> list[list[dict[str, Any]]]:
    return [items[index : index + size] for index in range(0, len(items), size)]


def task_markdown(run_dir: Path, task_id: int, items: list[dict[str, Any]], records_jsonl: Path) -> str:
    lines = [
        "# Codex/ChatGPT Deep-Read Dispatch Task",
        "",
        "You are a worker in a Codex-orchestrated paper deep-reading run.",
        "",
        "Read each assigned packet and all chunk files from disk. For every paper, write exactly one JSON object",
        "to the packet's `assistant_deep_read_record.json`. The record must satisfy the same contract used by",
        "`validate_assistant_deep_read_records.py`.",
        "",
        "Do not summarize from the rule pre-pass alone. Use the extracted PDF chunks and review/reply files when present.",
        "Do not invent paper facts, citations, baselines, reviewer concerns, or numbers. Mark missing information explicitly.",
        "",
        "Required record keys:",
        "",
    ]
    lines.extend(f"- `{key}`" for key in REQUIRED_KEYS)
    lines.extend(
        [
            "",
            "Required values:",
            "",
            f"- `workflow_alignment` must be `{REQUIRED_ALIGNMENT}`.",
            "- `reading_status` must be `complete`.",
            "- `authoritative_report_markdown` must be at least 400 characters and source-grounded.",
            "- `claim_support_matrix`, `story_option_board`, and `reusable_anonymous_patterns` must be non-empty lists.",
            "- `reusable_anonymous_patterns` must be anonymous: no paper title, author, URL, forum id, or unique source dump.",
            "",
            "Assigned papers:",
            "",
        ]
    )
    for item in items:
        lines.extend(
            [
                f"## {item.get('paper_key')}",
                "",
                f"- Packet: `{item.get('packet')}`",
                f"- Request: `{item.get('request')}`",
                f"- Output record: `{item.get('output_record')}`",
                f"- Chunk count: {item.get('chunk_count')}",
                "",
            ]
        )
    lines.extend(
        [
            "After writing all per-paper JSON files, do not edit the combined JSONL yourself unless explicitly assigned.",
            f"The orchestrator will collect records into `{display_path(records_jsonl, run_dir)}`.",
        ]
    )
    return "\n".join(lines).rstrip() + "\n"


def prepare(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = args.run_dir.resolve()
    packet_dir = (args.packet_dir or run_dir / "analysis" / "assistant_deep_read_packets").resolve()
    dispatch_dir = (args.dispatch_dir or run_dir / "analysis" / "codex_chatgpt_dispatch").resolve()
    records_jsonl = (args.records_jsonl or run_dir / "analysis" / "assistant_deep_read_records.jsonl").resolve()
    queue = load_queue(run_dir, packet_dir)
    if args.limit:
        queue = queue[: args.limit]
    tasks = chunked(queue, max(1, args.papers_per_task))
    dispatch_dir.mkdir(parents=True, exist_ok=True)
    task_records: list[dict[str, Any]] = []
    for index, items in enumerate(tasks, 1):
        task_path = dispatch_dir / f"task_{index:03d}.md"
        task_path.write_text(task_markdown(run_dir, index, items, records_jsonl), encoding="utf-8")
        task_records.append(
            {
                "task_id": index,
                "task_file": display_path(task_path, run_dir),
                "paper_keys": [str(item.get("paper_key")) for item in items],
                "output_records": [str(item.get("output_record")) for item in items],
                "status": "ready_for_codex_chatgpt_worker",
            }
        )
    manifest = {
        "schema_version": "1.0",
        "route": "codex-chatgpt-dispatch-deep-read",
        "run_dir": display_path(run_dir),
        "packet_queue": display_path(packet_dir / "queue.jsonl", run_dir),
        "dispatch_dir": display_path(dispatch_dir, run_dir),
        "records_jsonl": display_path(records_jsonl, run_dir),
        "paper_count": len(queue),
        "task_count": len(task_records),
        "papers_per_task": args.papers_per_task,
        "tasks": task_records,
        "orchestrator_instructions": [
            "Spawn one Codex/ChatGPT worker per task file when the environment exposes sub-agent or background-thread tools.",
            "Each worker reads only its task file, packet files, and chunk files, then writes per-paper assistant_deep_read_record.json files.",
            "Run this script with `collect` after workers finish, then import the combined JSONL.",
        ],
    }
    write_json(dispatch_dir / "dispatch_manifest.json", manifest)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return manifest


def collect(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = args.run_dir.resolve()
    packet_dir = (args.packet_dir or run_dir / "analysis" / "assistant_deep_read_packets").resolve()
    records_jsonl = (args.records_jsonl or run_dir / "analysis" / "assistant_deep_read_records.jsonl").resolve()
    queue = load_queue(run_dir, packet_dir)
    records: list[dict[str, Any]] = []
    missing: list[str] = []
    for item in queue:
        output = run_dir / str(item.get("output_record", ""))
        if not output.exists():
            missing.append(display_path(output, run_dir))
            continue
        data = json.loads(output.read_text(encoding="utf-8", errors="replace"))
        records.append(data)
    expected = {str(item.get("paper_key")) for item in queue if item.get("paper_key")}
    report = validate(records, expected, args.require_all)
    if missing:
        report["valid"] = False
        report["missing_output_records"] = missing
        report["problem_count"] = int(report.get("problem_count", 0)) + len(missing)
    if report["valid"]:
        write_jsonl(records_jsonl, records)
    out_json = run_dir / "analysis" / "codex_chatgpt_dispatch" / "collect_validation.json"
    write_json(out_json, report)
    result = {
        "schema_version": "1.0",
        "valid": report["valid"],
        "record_count": len(records),
        "expected_count": len(expected),
        "records_jsonl": display_path(records_jsonl, run_dir),
        "validation": display_path(out_json, run_dir),
        "missing_output_records": missing,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not report["valid"]:
        raise SystemExit(2)
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare or collect Codex/ChatGPT worker tasks for local deep reading.")
    sub = parser.add_subparsers(dest="command", required=True)
    common: list[argparse.ArgumentParser] = []
    for name in ["prepare", "collect"]:
        p = sub.add_parser(name)
        p.add_argument("--run-dir", type=Path, required=True)
        p.add_argument("--packet-dir", type=Path, default=None)
        p.add_argument("--records-jsonl", type=Path, default=None)
        common.append(p)
    common[0].add_argument("--dispatch-dir", type=Path, default=None)
    common[0].add_argument("--papers-per-task", type=int, default=4)
    common[0].add_argument("--limit", type=int, default=None)
    common[1].add_argument("--require-all", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.command == "prepare":
        prepare(args)
    elif args.command == "collect":
        collect(args)


if __name__ == "__main__":
    main()
