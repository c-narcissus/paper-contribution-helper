# Mode and Analysis-Direction Workflow

This playbook replaces the former default comprehensive route selector.

## Core idea

Generated child skills should not decide whether to directly analyze a paper or update an existing child skill. The user chooses the work mode explicitly. A/B/C/D are analysis directions for the paper/PDF and can be combined. New reusable-helper construction belongs to the parent package, not to generated child skills.

## Work modes

- **模式A1 - Use internal/package knowledge for target-paper analysis**: analyze the current paper directly without generating a child skill. Run related-work intake and submission-context gates before the final report.
- **模式A2 - Update existing child skill**: inspect the existing child skill, verify inheritance, quality-gate new sources, merge or regenerate, then run child regression checks.

## Analysis directions

- **A Contribution/related-work direction**: closest prior, novelty boundary, A+B+C risk, baseline relationship, claim-evidence-risk map.
- **B Layered revision/scientific elevation direction**: L0-L4 edits, failure mode, broken assumption, scientific question, research program.
- **C Reviewer/execution direction**: reviewer/AC attack preplay, answerability, minimal decisive experiments, edit-ready patches, revision loop.
- **D Literature/frontier/KB direction**: dynamic meta-graph, multi-hop retrieval plan, verified literature ledger, quality gate, frontier positioning, reusable pattern capture.

## Mode A2 Corpus Intake

For 模式A2, require a child-skill update corpus spec before discovery or packaging: existing child skill, research field(s), years/year range, per-year paper quantity, source venues/journals/official sites/databases, and local folders/uploaded PDFs/project-run. Load `child_skill_corpus_intake_gate.md` and `field_year_balanced_sampling.md`. If multiple fields are supplied, keep the field×year quota balanced where verified sources exist. If fields or quotas are missing, ask; do not auto-update from vague sources.

## Parsing user replies

Accept compact replies such as:

```text
模式A1，方向A+B+C+D
模式A2，方向D，已有子skill=___，研究领域=___，年份=___，新增来源=___
```

If the mode is absent, ask the user to choose 模式A1 or 模式A2. If directions are absent, ask for A-D directions unless the user clearly says `全面分析`, in which case use A+B+C+D and state that assumption. If the user asks this child skill to create another reusable helper, explain that this route is intentionally disabled in child skills and should be handled by the parent package.

## Execution

After parsing:

- For 模式A1 with any paper direction, run related-work intake and submission-context gates, then load only playbooks needed by selected A-D directions.
- For 模式A2, first inspect the existing child skill and confirm the update corpus spec, then update sources and rerun inheritance/regression checks.

## Evidence hygiene

External literature still requires visible user-provided sources or verified retrieval. Candidate papers inferred from references, related work, or frontier descriptions are `search-plan-only` until verified.
