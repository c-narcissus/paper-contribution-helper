# Startup Mode and Analysis-Direction Menu

The first response after this skill is invoked is a fixed startup menu, not a normal answer.

## Rule

Even if the user asks a detailed question, uploads a PDF, or gives a complete task, the startup reply must only show the compact selection menu and stop. Do not answer the user's substantive question, inspect files, run tools, or load workflow modules before the second user turn.

## Menu structure

The menu has two separate layers:

1. **Work mode**: the user chooses one of the operational routes.
   - 模式1: build a new specialized child skill.
   - 模式2: use the main/package-internal knowledge base to analyze the current paper.
   - 模式3: update or extend an existing specialized child skill.
2. **Analysis directions**: A-D are PDF/paper analysis directions, not operational routes. The user can combine them, e.g. `A+B+C+D`.
   - A: contribution, related work, novelty, closest-prior and claim-evidence-risk.
   - B: L0-L4 layered revision and solution-to-scientific-question elevation.
   - C: reviewer defense, minimal decisive experiments, edit-ready patches and revision loop.
   - D: dynamic meta-graph, multi-hop literature search plan, frontier positioning, literature guard, local KB/child-skill pattern capture.

## Template prefix rule

Every copyable template in the startup menu must begin with:

```text
直接使用paper-contribution-helper-v1.1.12.zip里的skill，
```

Generated child skills should use their own child zip filename in the same prefix pattern.

## No auto route selection

Do not include a default prompt that asks the skill to decide whether to analyze, build, or update. The user must explicitly choose 模式1/2/3. If the mode is missing after startup, ask for the mode. If directions are missing, ask for A-D directions or treat `全面分析` as `A+B+C+D` only when the user clearly says they want comprehensive analysis.

## Keep the menu short

Do not list many long task templates. Provide only one short template for each work mode. Keep the style plain, teacher-like, and practical.

## Child-skill corpus fields

For 模式1 and 模式3, the menu must ask the user to provide: research field(s), years/year range, per-year paper quantity, source conferences/journals/official sites/databases, local folders or uploaded PDFs/project-run, and the existing child skill for updates. State that multiple research fields, multiple years, multiple sources, and multiple local-material entries are OR candidate sets by default, not AND filters. If multiple fields are given, state that the corpus should be balanced across field×year cells. If these are missing after the user selects 模式1/3, ask for them before building or updating.


## Multi-value OR semantics

When the user writes multiple research fields, multiple years, multiple sources, or multiple local-material locations, interpret them as alternative candidate pools to cover, not as a conjunctive filter that every paper must satisfy. Only use AND semantics if the user explicitly says “必须同时满足”, “交集”, or “AND”.
