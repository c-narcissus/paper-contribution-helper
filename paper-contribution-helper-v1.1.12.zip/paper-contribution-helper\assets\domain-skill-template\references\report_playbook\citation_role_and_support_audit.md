# Citation Role and Support Audit

Use this playbook for related work, literature evidence, and claim-support checks.

## Main Idea

Citation correctness is not only “does the paper exist?” It is “does this citation actually support the sentence where it is used?”

## Citation Roles

Assign each important citation one or more roles:

- `background`: establishes the general field.
- `closest-prior`: most likely novelty comparator.
- `baseline`: method that should be compared.
- `method-primitive`: source of a component or technique.
- `evaluation-norm`: benchmark, metric, protocol, or stress test.
- `failure-evidence`: documents the failure mode or broken assumption.
- `frontier-analogy`: adjacent idea, not direct evidence.
- `scope-boundary`: explains where this paper differs.

## Support Check

For each key sentence:

| Sentence/claim | Citation role | Does citation support it? | Risk | Fix |
|---|---|---|---|---|
| ... | closest-prior | yes/partial/no | overclaim / miscitation | rewrite / replace / add source |

## Anti-Hallucination Rule

If the citation was not supplied, visible in the target paper, or verified in this run, do not describe its claims. Mark it `search-plan-only` or `needs verification`.

## Related Work Writing Rule

A good related-work paragraph should not just list papers. It should say:

1. what family of work assumes;
2. why that assumption breaks in the target setting;
3. how the target paper's scope differs;
4. what evidence still needs to be compared fairly.
