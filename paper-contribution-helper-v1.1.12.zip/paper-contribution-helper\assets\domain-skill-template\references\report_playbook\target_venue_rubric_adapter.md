# Target Venue / Journal Rubric Adapter

Use this playbook when a user names a target conference, journal, track, or field quality bar.

## Main Idea

不要用一套泛泛标准审所有论文。计算机顶会、医学顶刊、材料顶刊、社科期刊、工程系统会议看的重点不同。The report should translate the target venue/journal expectation into concrete revision pressure.

## Rubric Adapter

Build a compact rubric map:

| Rubric dimension | What the venue likely checks | Current paper risk | Required repair |
|---|---|---|---|
| novelty | new problem/assumption/method/evidence | incremental / A+B+C risk | boundary + decisive comparison |
| technical soundness | method necessity and correctness | mechanism unclear | ablation / diagnostic / proof sketch |
| empirical evidence | fair baselines, robustness, statistics | weak comparison | minimal decisive experiment |
| reproducibility | code/data/details/seeds/cost | hard to reproduce | resource-parity ledger |
| clarity | problem-story alignment | contribution buried | L0/L1 rewrite |
| scope/ethics/domain validity | bounded claims, deployment risk | overclaiming | risk disclosure |

Adapt these rows to the field rather than treating them as universal.

## Field Handling

- CS/AI: top conferences and flagship journals often reward clear novelty boundary, strong empirical baselines, reproducibility, and clean positioning.
- Systems/security/HCI: include artifact, threat model, user study, deployment, or systems constraints when relevant.
- Biomedical/materials/energy/natural sciences: prioritize domain validity, experimental protocol, mechanism, statistics, and top-journal evidence norms.
- Social sciences/humanities: prioritize construct validity, theory contribution, data/method transparency, and scope.

If the venue standard is unknown, ask for a venue profile or proceed with a conservative top-quality bar.

## Output Rule

Do not say “this meets top venue standard” unless evidence supports it. Say instead:

- `投稿级修补`: likely enough for a near-term submission.
- `顶会/顶刊风险仍高`: important gaps remain.
- `proposal-level`: good research-program direction but not current-paper evidence.
