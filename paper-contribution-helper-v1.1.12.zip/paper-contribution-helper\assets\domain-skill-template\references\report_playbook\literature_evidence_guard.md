# Literature Evidence Guard

Use this playbook whenever the report mentions prior work, latest work, KG retrieval, frontier topics, benchmarks, or collision risk.

## Main Rule

Do not hallucinate literature. If a paper, benchmark, claim, citation, venue, year, DOI, arXiv ID, OpenReview page, or result has not been verified from a visible source, do not present it as fact.

## Source Labels

Every literature item must be labeled:

| Label | Meaning | Can support target-paper claims? |
|---|---|---|
| `target-paper-evidence` | directly from the uploaded/analyzed target paper | yes |
| `user-provided-source` | uploaded or pasted by the user | only for what it actually says |
| `local-reference-case` | anonymous pattern from packaged/local skill corpus | analogy only |
| `verified-external-literature` | checked via web/API/local source with title/year/source and quality role | related-work, collision, evaluation norm, frontier context |
| `search-plan-only` | not yet retrieved or not verifiable in this environment | no |
| `unverified-memory` | model memory only | no; avoid using it |

## Minimum Verification

Before using an external paper in advice, record at least:

- title or stable identifier;
- year or date when available;
- source type: uploaded PDF, arXiv, OpenReview, Semantic Scholar/OpenAlex record, venue page, official benchmark page, etc.;
- why it is relevant: closest prior, collision risk, evaluation norm, mechanism analogy, frontier context;
- what exactly it supports;
- what it does **not** support.

If any item is missing, downgrade the item to `search-plan-only` or `needs-verification`.

## No-Hallucination Wording

Use these safe forms:

- `可以检索这条线：...`
- `如果检索确认有类似工作，那么 related work 需要这样补边界：...`
- `在没有外部检索结果前，这只能作为 proposal-level 方向。`
- `这个说法目前只能由目标论文内部证据支持到 X 层，不能扩展到 Y。`

Avoid these unsafe forms unless verified:

- `最新研究已经表明...`
- `很多论文都在做...`
- `某某工作证明了...`
- `这是当前 SOTA 趋势...`
- invented paper titles, invented benchmark names, or invented reviewer consensus.

## Collision Risk Levels

| Level | Meaning | Action |
|---|---|---|
| `confirmed-collision` | verified paper has very close problem/method/evidence overlap | rewrite novelty boundary and compare if possible |
| `possible-collision` | title/abstract suggests overlap, full evidence not checked | mark as retrieval priority |
| `distant-analogy` | shares constraint/failure mode but not same contribution | use only as framing/evaluation inspiration |
| `no-check-possible` | no retrieval access | output query plan only |

## Report Requirement

Every final report that uses external literature must include a short `Source boundary` note in plain Chinese:

- which claims come from the target paper;
- which ideas come from packaged anonymous cases;
- which external sources were actually checked;
- which frontier suggestions are only retrieval plans or proposal-level ideas.

## Source Quality Pairing

Pair this guard with `source_quality_gate.md`. Verification says “this source exists and says X”; quality gating says “what role this source is allowed to play.” A verified preprint may still be trend-only. A famous venue paper may still be a poor template if the full paper does not support the pattern being borrowed.
