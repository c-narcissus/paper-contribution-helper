# v1.0.9 Benchmark-Audited Upgrade Summary

This upgrade does not copy popular GitHub research skills. It studies their method patterns, records where those patterns help or hurt this package's target draft types, and implements only bounded local playbooks.

Added playbooks:

- `github_research_skill_benchmark.md`
- `claim_evidence_risk_map.md`
- `reviewer_question_answerability.md`
- `paper_logic_completeness_audit.md`
- `risk_self_disclosure_playbook.md`
- `frontier_topic_alignment.md`
- `simulated_review_panel.md`

Updated:

- root routing and module index;
- target-paper workflow and quality contract;
- generated domain-skill template;
- target-PDF pre-pass scaffold and dependency ledger;
- release notes and version.
