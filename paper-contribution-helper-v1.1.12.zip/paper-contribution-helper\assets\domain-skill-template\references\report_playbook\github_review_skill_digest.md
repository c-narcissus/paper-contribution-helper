# Structured Review Digest

Use this as a structure-only reminder for reviewing and defending a target paper. It is not evidence about any target paper.

For package maintenance, first consult `github_research_skill_benchmark.md`. Popular research-assistant projects may provide useful patterns, but they must not be copied directly. Each pattern must be adapted to this package's target: evidence-bounded contribution reframing for A+B+C, incremental, engineering, light-transfer, and old-method-new-setting drafts.

Useful review dimensions:

- clarity of core claim;
- novelty and relation to closest work;
- methodological necessity rather than component inventory;
- evidence alignment with claims;
- baseline and protocol fairness;
- ablation and mechanism sufficiency;
- scope and limitation honesty;
- reproducibility and implementation clarity;
- trend/collision awareness when current literature is requested;
- actionability of revisions.

For author-side reports, convert each dimension into:

1. likely reviewer concern;
2. manuscript trigger;
3. answerability label;
4. no-new-experiment repair;
5. evidence reuse or new-evidence need;
6. safe rebuttal wording.

Do not output generic review scores. The deliverable is manuscript defense and revision priority.
