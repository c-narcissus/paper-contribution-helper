# Simulated Review Panel

Use this playbook to improve reviewer attack preplay without copying external automated-review projects.

## Purpose

A single simulated reviewer often gives generic criticism. For target drafts that may look incremental or component-compositional, use a small panel to expose different fatal risks before submission.

## Panel Roles

Use 3-5 relevant roles, not all roles by default:

1. **Novelty / Closest-Prior Reviewer**: asks whether the paper is more than a known combination.
2. **Mechanism Reviewer**: asks whether the proposed story is demonstrated.
3. **Experiment / Baseline Reviewer**: checks ablations, baselines, metrics, and protocol fairness.
4. **Systems / Reproducibility Reviewer**: checks cost, scalability, implementation details, and repeatability.
5. **Meta-Reviewer / AC**: identifies the single most important accept/reject hinge.

## Output Template

| Reviewer role | Likely score pressure | Main concern | Evidence anchor | What would change their mind | Revision action |
|---|---|---|---|---|---|

## Reflection Rule

After the first panel, synthesize:

- which concerns are duplicates;
- which concern is the true acceptance hinge;
- which concerns can be fixed by Tier 0 writing;
- which require Tier 1 evidence reuse;
- which truly require Tier 2 experiments;
- which claims should be downgraded immediately.

## Do Not

- Present a simulated accept/reject decision as authoritative.
- Let reviewer personas invent missing facts.
- Use the panel to make the report longer without clearer actions.
- Over-index on criticism; every concern should map to a concrete repair or scope boundary.
