# Solution-To-Scientific-Question Elevation

Use this playbook to lift a draft from "we propose a method" to "we expose and study a scientific problem under a meaningful constraint." This is especially important for A+B+C, engineering, transfer, and incremental manuscripts.

## Elevation Ladder

Transform the manuscript through six levels:

1. **Solution**: What did we build?
2. **Failure mode**: What repeatedly fails without this solution?
3. **Broken assumption**: Which assumption in prior work silently breaks in this setting?
4. **Scientific question**: What general question does that broken assumption raise?
5. **Principle / mechanism**: What reusable insight might explain why the solution works?
6. **Research program**: What next experiments would test, generalize, or falsify the principle?

## Template

```text
Current solution framing:
We add/use/combine [A, B, C] to improve [metric] on [setting].

Elevated scientific framing:
This paper studies the problem of [general failure / missing interface / broken assumption] under [constraint regime]. Existing methods assume [assumption], but this assumption fails when [condition]. The proposed design is best understood as a testable mechanism for [repairing / closing / relaxing] that assumption through [principle].
```

## Question Types Worth Elevating

| Local observation | Possible scientific question |
|---|---|
| module improves robustness only under non-IID / scarcity / privacy | What information becomes unavailable under this constraint, and how can models recover it without violating the constraint? |
| performance gain depends on data generation / augmentation | What kind of synthetic evidence is acceptable when real evidence cannot be shared or labeled? |
| aggregation / selection works without validation data | How can systems estimate trust when the usual validation signal is missing? |
| method transfers old primitive to new setting | Which assumption made the old primitive unusable before, and what interface makes it usable now? |
| engineering system works better end-to-end | Which bottleneck in the scientific workflow was actually the limiting factor? |

## High-Level Claim Discipline

High-level language must be evidence-tiered:

- Use `we study`, `we characterize`, `we provide evidence that` for supported scientific framing.
- Use `this suggests`, `this points to`, `a promising direction is` for implications.
- Avoid `we solve`, `we prove`, `we establish a general theory` unless the paper truly has the proof or broad evidence.

## Output Requirement

When this playbook is used, include:

1. The current solution-level story.
2. The elevated scientific question.
3. The broken assumption or missing interface.
4. The evidence already supporting the elevation.
5. What would be needed to make the elevated claim truly top-tier.
