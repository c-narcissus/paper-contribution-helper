# Reviewer Question Answerability

Use this playbook to convert simulated or real reviewer concerns into answerable questions, evidence locations, and repair actions.

## Why This Matters

Many rebuttals fail because the paper can list reviewer attacks but cannot answer them from the manuscript. For contribution-framing drafts, the fatal issue is often not the question itself, but whether the current paper has enough evidence to answer it.

## Required Labels

For each likely reviewer question, assign one label:

- `answerable-strong`: the paper already contains enough evidence; the manuscript needs clearer positioning.
- `answerable-partial`: the answer exists but is scattered or indirect; reorganize evidence and soften wording.
- `unanswerable-writing-gap`: the evidence exists, but the paper does not point to it or explain it.
- `unanswerable-evidence-gap`: the paper lacks the needed baseline, ablation, diagnostic, robustness, cost, or reproducibility evidence.
- `outside-current-scope`: the question is fair but beyond the paper's intended bounded setting; disclose scope.

## Reviewer Question Template

| Reviewer question | Why reviewer asks | Manuscript trigger | Answerability | Best evidence anchor | Safe answer | Repair tier |
|---|---|---|---|---|---|---|

## Default Reviewer Personas

Use only relevant personas; do not force all of them into the final report.

- **Novelty reviewer**: asks whether the idea is more than a known component combination.
- **Closest-prior reviewer**: asks what exactly differs from the most similar prior paper.
- **Mechanism reviewer**: asks whether the proposed explanation is demonstrated, not just asserted.
- **Experiment reviewer**: asks whether baselines, ablations, metrics, and protocols are fair.
- **Systems/cost reviewer**: asks whether gains come from extra computation, data, tuning, or engineering.
- **Scope reviewer**: asks whether the paper overclaims beyond the evaluated regime.
- **Reproducibility reviewer**: asks whether the implementation and evaluation can be reproduced.
- **Meta-reviewer / AC**: asks what one sentence justifies acceptance despite residual weaknesses.

## Repair Tiers

- **Tier 0**: Rewrite abstract, introduction, contributions, related work, method overview, or experiment narration using existing evidence.
- **Tier 1**: Reuse existing logs, appendix results, qualitative examples, cost traces, failed trials, or implementation details.
- **Tier 2**: Add a new experiment, baseline, ablation, stress test, runtime/cost comparison, or reproducibility artifact.

## Final Report Rule

The final report should include the most dangerous 5-8 questions, not an exhaustive list. For each, explain whether the paper can currently answer it and exactly what should change.
