# Source Strategy: Field Venue Quality Standards

Use this strategy when the user asks for a professional reusable child skill, a top-conference/top-journal style upgrade, or a local knowledge base for high-level scientific advice.

## Goal

Define a field-specific source-quality standard before selecting reusable reference papers. The standard should answer:

1. In this field, are top conferences, top journals, books, or society guidelines the main prestige carriers?
2. Which sources are allowed to become positive templates?
3. Which sources are discovery-only or negative-risk examples?
4. What uncertainty remains because the venue list was not visible or user-provided?

## Default Field Policy

- **CS / AI / data / systems / security / HCI:** top peer-reviewed conferences and journals can both be anchor sources. Use field-recognized venue lists when visible or user-provided.
- **Natural sciences / biomedical / engineering sciences:** top journals, society journals, major conference proceedings where the field values them, landmark methods papers, and high-quality reviews.
- **Social sciences / humanities:** field-recognized journals, books, monographs, major association conferences, and expert-curated reading lists.
- **Interdisciplinary topics:** build two small anchor lists, one for each parent field, and mark cross-field borrowing boundaries.

## Venue Profile File

When possible, maintain a small project-local profile such as:

```json
{
  "field": "machine learning",
  "anchor_venues": ["..."],
  "credible_venues": ["..."],
  "evaluation_sources": ["..."],
  "discovery_only_sources": ["arXiv", "workshop", "GitHub"],
  "venue_quality_source": "user-provided / visible ranking / lab list / manual expert list",
  "last_checked": "YYYY-MM-DD"
}
```

If no profile exists, ask the user for one when building a serious child skill, or proceed with conservative labels and write a coverage warning.

## Interaction With KG / Meta-Graph Retrieval

The dynamic meta-graph generates retrieval paths. The venue quality gate decides which retrieved items can be used as:

- `positive_template` for writing and scientific elevation;
- `collision_risk` for novelty boundaries;
- `evaluation_norm` for experiments;
- `trend_signal` for L4 roadmap only;
- `negative_risk` for warning examples.

Do not let the retrieval graph override the quality gate. A multi-hop result that is low-quality or unverified remains discovery-only.
