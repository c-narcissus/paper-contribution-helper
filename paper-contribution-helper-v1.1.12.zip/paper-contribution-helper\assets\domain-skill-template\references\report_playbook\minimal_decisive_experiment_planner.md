# Minimal Decisive Experiment Planner

Use this playbook when the paper needs new evidence or when the user asks how to improve top-venue/top-journal chances.

## Main Idea

不要泛泛说“补更多实验”。Tell the author the smallest experiment that would most reduce reviewer doubt.

## Experiment Priority

Rank experiments by reviewer-defense value:

1. novelty-collision comparison: closest prior or missing baseline;
2. mechanism diagnostic: proves why the proposed component is necessary;
3. failure-mode stress test: validates the claimed constrained regime;
4. resource-parity test: same data/compute/model/budget comparison;
5. robustness/statistical reliability: seeds, variance, confidence intervals, domains;
6. cost/efficiency tradeoff: latency, memory, communication, annotation, compute;
7. ablation-to-claim alignment: each module maps to a failure mode.

## Output Table

| Priority | Minimal experiment | Reviewer question answered | Setup | Success supports | If it fails |
|---|---|---|---|---|---|
| 1 | ... | why not A+B+C / why not prior | smallest feasible setting | safe claim level | downgrade or rewrite |

## One-Experiment Rule

If only one experiment is possible, recommend one decisive experiment, not three nice-to-have experiments. Explain why it dominates.

## Evidence Interpretation

- If the experiment succeeds, say exactly which claim becomes paper-ready.
- If it partially succeeds, say which claim stays discussion-level.
- If it fails, convert the result into limitation/scope or redesign advice.
