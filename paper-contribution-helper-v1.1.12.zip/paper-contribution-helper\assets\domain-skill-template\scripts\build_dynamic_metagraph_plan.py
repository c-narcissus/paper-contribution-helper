#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
from pathlib import Path
from typing import Any

NODE_TYPES = [
    "TargetPaper", "TargetRegime", "ResearchProblem", "BrokenAssumption", "FailureMode",
    "Constraint", "MethodPrimitive", "MechanismHypothesis", "EvidenceAnchor", "Claim",
    "ReviewerRisk", "ClosestPrior", "EvaluationNorm", "FrontierTopic", "ScientificBoundary", "NextExperiment",
]

EDGE_TYPES = [
    "claims", "supports", "overclaims_without", "repairs", "breaks_assumption",
    "shares_constraint_with", "shares_failure_mode_with", "borrows_primitive_from",
    "requires_evaluation_norm", "collides_with", "upgrades_to_question", "touches_boundary",
]

KEYWORDS = {
    "Constraint": ["non-iid", "privacy", "scarce", "limited", "low-resource", "cost", "latency", "noisy", "label", "federated", "decentralized", "robust"],
    "FailureMode": ["failure", "degrade", "drop", "bias", "drift", "collapse", "noise", "overfit", "miscalibration", "unreliable"],
    "MethodPrimitive": ["retrieval", "graph", "diffusion", "contrastive", "causal", "calibration", "mixup", "adapter", "prompt", "agent", "aggregation", "pseudo-label"],
    "EvaluationNorm": ["benchmark", "metric", "ablation", "baseline", "cost", "runtime", "robustness", "stress", "generalization", "reproducibility"],
    "ReviewerRisk": ["incremental", "novelty", "baseline", "ablation", "mechanism", "scope", "fair", "reproduc"],
}


def snippets(text: str, words: list[str], n: int = 3) -> list[str]:
    out = []
    text_norm = re.sub(r"\s+", " ", text)
    for w in words:
        m = re.search(r".{0,90}" + re.escape(w) + r".{0,120}", text_norm, flags=re.I)
        if m:
            s = m.group(0).strip()
            if s not in out:
                out.append(s)
        if len(out) >= n:
            break
    return out


def build_plan(text: str, title: str) -> dict[str, Any]:
    nodes = {"TargetPaper": [title]}
    for typ, words in KEYWORDS.items():
        nodes[typ] = snippets(text, words, 5)
    seeds = []
    for typ in ["Constraint", "FailureMode", "MethodPrimitive", "EvaluationNorm", "ReviewerRisk"]:
        for s in nodes.get(typ, [])[:2]:
            cleaned = re.sub(r"[^A-Za-z0-9\u4e00-\u9fff ,;:_/-]+", " ", s)[:180]
            seeds.append({"from_node_type": typ, "seed": cleaned})
    query_paths = []
    for item in seeds[:8]:
        seed = item["seed"]
        typ = item["from_node_type"]
        query_paths.extend([
            {"path": f"{typ} -> closest prior -> novelty boundary", "query": f"{seed} closest prior limitation novelty"},
            {"path": f"{typ} -> evaluation norm -> missing diagnostic", "query": f"{seed} benchmark ablation cost robustness evaluation"},
            {"path": f"{typ} -> adjacent domain -> borrowable mechanism", "query": f"{seed} adjacent domain method mechanism survey"},
        ])
    return {
        "schema_version": "web-safe-dynamic-metagraph-v1.1.1",
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "source_status": "target-text-only; external retrieval not performed",
        "node_types": NODE_TYPES,
        "edge_types": EDGE_TYPES,
        "dynamic_nodes": nodes,
        "retrieval_query_paths": query_paths[:18],
        "evidence_rule": "Internal nodes come from the target text. External papers must be verified separately before use.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a web-safe dynamic meta-graph retrieval plan from target-paper text. No network calls.")
    parser.add_argument("--text-file", type=Path, required=True, help="Extracted target paper text or summary.")
    parser.add_argument("--title", default="target paper")
    parser.add_argument("--out-dir", type=Path, default=Path("dynamic_metagraph_run"))
    args = parser.parse_args()
    text = args.text_file.read_text(encoding="utf-8", errors="replace")
    plan = build_plan(text, args.title)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "dynamic_metagraph.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    md = [
        "# Dynamic Meta-Graph Retrieval Plan", "",
        f"Generated at: {plan['generated_at']}", "",
        "This is a web-safe retrieval plan, not evidence that latest literature has been checked.", "",
        "## Extracted Target Nodes", "",
    ]
    for typ, vals in plan["dynamic_nodes"].items():
        md.append(f"### {typ}")
        md.extend([f"- {v}" for v in vals] if vals else ["- missing / not explicit"])
        md.append("")
    md.extend(["## Retrieval Query Paths", ""])
    for q in plan["retrieval_query_paths"]:
        md.append(f"- `{q['path']}`: {q['query']}")
    md.extend(["", "## Evidence Boundary", "", plan["evidence_rule"], ""])
    (args.out_dir / "dynamic_metagraph.md").write_text("\n".join(md), encoding="utf-8")
    print(json.dumps({"out_dir": args.out_dir.as_posix(), "queries": len(plan["retrieval_query_paths"])}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
