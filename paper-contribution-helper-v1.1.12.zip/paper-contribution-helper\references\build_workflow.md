# Build Workflow

## Inputs

Required:

- `--skill-name`
- research field(s): `--focus-domains` or approved `--target-paper` inference
- `--years` or explicit year range
- source scope: venues/journals/official sites/databases, local PDF folder/project-run, or approved discovery source
- `--source-mode`
- `--out-dir`

Recommended user-facing fields:

- mode: generate or update a specialized reusable skill;
- research fields: one or more explicit fields/subfields, or a target-paper seed for inference with user approval;
- years/year range, optionally split into defense/evaluation/frontier ranges;
- source venues/journals/official pages/databases, e.g. top conferences, field journals, OpenReview venue, arXiv category, benchmark page;
- local materials: `project-run`, `local-pdf`, `--pdf-dir`, uploaded PDFs, metadata/reviews/replies folders, or corpus manifest;
- quantity/cap and source-quality role when discovery is used;
- output skill name and, for updates, existing child skill zip/folder plus preserve/replace instructions.

Source-specific:

- `project-run`: `--project-run-dir <run_dir>`
- `local-pdf`: `--pdf <paper.pdf>` or `--pdf-dir <folder>`
- `web-abstract-pdf-mixed`: `--abstract-manifest <papers.jsonl-or-csv>`
- `openreview-iclr`: `--cap <n>` and one year for the integrated OpenReview adapter

Preferred source route:

- If the user already has downloaded PDFs, reviews/replies, metadata, or a run directory, use `references/project_corpus_direct_workflow.md` first.
- Prefer `project-run` for an already-normalized corpus.
- Prefer `local-pdf` for a raw folder of downloaded PDFs.
- Prefer `web-abstract-pdf-mixed` when the user has web abstracts and only partial PDF availability. Treat abstracts as discovery records and use `references/corpus_screening_strategy.md` before packaging.
- Use `openreview-iclr` only when the user wants this skill to discover/download the corpus.
- Once a corpus is downloaded or standardized, it is a project-internal file set. Continue local project-file processing from disk. External API/acpx absence is not a stop condition when the current assistant can inspect and synthesize from local files.

Full-paper deep-reading:

- `--llm-deep-read-mode required` is the default for real corpus builds.
- The current assistant's local-file processing route has priority when the user asks to process downloaded/local materials directly. It should read extracted project files from disk, chunk as needed, write per-paper deep-read records, update the manifest, and continue synthesis/package steps if the contract is satisfied.
- Use `references/assistant_local_deep_read_workflow.md` to modularize this route through packet preparation, assistant-written JSONL records, validation, and import.
- `--llm-provider openai-responses` is the default online automation backend, not a required permission gate.
- `--llm-provider openai-chat`, `command`, `command-file`, or `jsonl` may be used when the environment requires a different LLM route.
- `--llm-provider codex-dispatch` prepares current-assistant packets plus Codex/ChatGPT worker task files when the user permits sub-agent/background-thread orchestration. If worker records are missing, the build stops with a non-terminal `CODEX_CHATGPT_DISPATCH_REQUIRED` handoff; after workers finish, collect/import records and rerun the same build command.
- `--llm-provider command-file` writes one request JSON file per chunk/synthesis prompt and reads one response JSON file.
- ACP/acpx is a fallback, not the primary corpus-analysis path. When local assistant processing is not being used and no API key/local command backend is available but ACP/acpx is available, load `references/acp_command_file_workflow.md` and use `--llm-provider command-file --llm-command "python scripts/acp_command_file_bridge.py"`.
- `--llm-provider off` is only for debugging and is rejected when deep reading is required.
- `--llm-results-jsonl <file>` imports precomputed deep-read records keyed by `paper_key`.

Target-paper domain inference:

- If `--focus-domains` is omitted, provide `--target-paper <paper.pdf>` as a domain seed.
- The factory extracts and reads the target paper for domain/subfield inference before corpus discovery.
- This is not direct contribution analysis of that PDF; it does not produce story routes, reviewer defense, or manuscript edits.
- The inference step returns 1-3 searchable focus domains or subfields and saves them to `build/<skill-name>/.delta-contribution-reframer/state/target_domain_inference.json`.
- Inference requires a live LLM route: `openai-responses`, `openai-chat`, `command`, or `command-file`. `jsonl` remains for precomputed reference-paper deep reads and is not used for fresh target-domain inference.

## One-Step Build

Existing project corpus run:

```bash
python scripts/build_domain_skill.py \
  --skill-name paper-helper-from-corpus \
  --focus-domains <domain> ... \
  --years <year> ... \
  --source-mode project-run \
  --project-run-dir <run-dir> \
  --llm-provider openai-responses \
  --llm-deep-read-mode required \
  --out-dir dist \
  --overwrite
```

Raw downloaded PDF folder:

```bash
python scripts/build_domain_skill.py \
  --skill-name paper-helper-from-pdfs \
  --focus-domains <domain> ... \
  --years <year> ... \
  --source-mode local-pdf \
  --pdf-dir <pdf-folder> \
  --metadata-dir <optional-metadata-folder> \
  --reviews-dir <optional-review-folder> \
  --replies-dir <optional-reply-folder> \
  --llm-provider openai-responses \
  --llm-deep-read-mode required \
  --out-dir dist \
  --overwrite
```

Project corpus with Codex/ChatGPT dispatch:

```bash
python scripts/build_domain_skill.py \
  --skill-name paper-helper-codex-dispatch \
  --focus-domains <domain> ... \
  --years <year> ... \
  --source-mode project-run \
  --project-run-dir <run-dir> \
  --llm-provider codex-dispatch \
  --llm-deep-read-mode required \
  --out-dir dist \
  --overwrite
```

Web abstract/PDF manifest:

```bash
python scripts/build_domain_skill.py \
  --skill-name paper-helper-from-web-abstracts \
  --focus-domains <domain> ... \
  --years <year> ... \
  --source-mode web-abstract-pdf-mixed \
  --abstract-manifest <papers.jsonl> \
  --llm-provider openai-responses \
  --llm-deep-read-mode required \
  --out-dir dist \
  --overwrite
```

OpenReview discovery/download:

```bash
python scripts/build_domain_skill.py \
  --skill-name paper-helper-iclr-openreview \
  --display-name "Paper Helper ICLR OpenReview" \
  --focus-domains <domain> ... \
  --years <year> \
  --source-mode openreview-iclr \
  --cap <max-papers> \
  --llm-provider openai-responses \
  --llm-deep-read-mode required \
  --out-dir dist \
  --overwrite
```

If the user does not know the focus domain labels, use the target-paper-as-domain-seed form:

```bash
python scripts/build_domain_skill.py \
  --skill-name paper-helper-target-guided \
  --display-name "Paper Helper Target Guided" \
  --target-paper path/to/target-paper.pdf \
  --years <year> \
  --source-mode openreview-iclr \
  --cap <max-papers> \
  --llm-provider openai-responses \
  --llm-deep-read-mode required \
  --out-dir dist \
  --overwrite
```

## Pipeline Steps

1. Create a staging home under `build/<skill-name>/.delta-contribution-reframer/`.
2. If no focus domains were supplied, read `--target-paper` for domain inference only, infer 1-3 focus domains/subfields, and store the inference record under the staging home.
3. Obtain a corpus run from the selected source mode, using either supplied or inferred focus domains for screening.
   - In `web-abstract-pdf-mixed` mode, first save every abstract/metadata record under `discovery/`, classify candidate roles semantically, then create `materials/_by_paper/` only for records with PDFs.
4. Validate the run against the project corpus contract.
5. Extract and analyze every `materials/_by_paper/<paper_key>/` folder.
6. Run the required full-paper deep-reading pass for every selected PDF, chunking only when needed for context limits. This may be current-assistant local-file processing or an automated backend.
7. Merge the deep-read record with the delta-contribution rule pre-pass.
8. Synthesize anonymous resources into the staging home, including `references/llm_deep_read_synthesis.md`.
9. Package a standalone skill from `assets/domain-skill-template/`.
10. Run generated package validation and startup checks.

The final generated skill should be usable even if the staging home and corpus run are removed.

Do not confuse this workflow with direct target-paper analysis. A target PDF in this workflow is used to pick the field and build a specialized reusable skill from reference papers.

Do not confuse candidate recall with reusable evidence. In abstract/PDF-mixed source mode, abstract-only records can guide what to download, but they cannot be synthesized into reusable cases. Obvious weak-incremental papers are useful as `negative_risk` examples only unless the full paper or review trail shows an effective reframing or defense.

## Blocked-Backend Behavior

If a corpus exists but `OPENAI_API_KEY`, local `command`, ACP/acpx, and complete JSONL records are all unavailable, do not stop at `project-run validated` and do not report backend absence as a reason analysis cannot continue.

Continue project-internal analysis with `references/project_corpus_direct_workflow.md`:

- validate the corpus;
- extract each PDF;
- read review/reply files;
- write per-paper rule pre-pass reports;
- write the per-paper manifest;
- record `llm_deep_reading.status="not_run"` or `failed` when automated deep reading did not run.

Then, if the current assistant can read local project files, continue by producing local-file full-paper deep-read records and updating the manifest. This is mandatory for project-internal corpora; it is not optional merely because a script's automated backend path is unavailable. Stop before anonymous synthesis and final skill packaging only if neither local assistant processing nor another complete deep-read source is available, or if a concrete file-level blocker prevents local reading.

In v1.0.4, use `scripts/engine/continue_local_deep_read.py --run-dir <run-dir> --require-all` as the first no-backend continuation command. A `waiting_for_current_assistant_read` result is an in-progress handoff to the current assistant, not a final status to report as failure.

Script defaults and CLI errors do not override this workflow. Treat an automated-backend failure as a switch from automated batch mode to current-assistant local-file processing.

## Context-Limit Requirement

Do not paste full PDFs or full extracted paper text into the assistant context. The pipeline must process corpus files from disk, split each paper with `--llm-chunk-chars`, save per-paper records and manifests under the project run, and resume with `--reuse-llm` when needed.

## Alignment Requirement

The per-paper analysis step is not a lightweight index. It must run a full-paper LLM deep-read over every selected PDF and produce `delta-contribution-reframer`-aligned reports for every reference paper, including source ledger, evidence boundary, reference regime/failure modes, surface-vs-stronger delta, claim-support matrix, story options, review/reply analysis, and reuse priorities. The generated skill's target-paper mode must also follow the same base target-paper workflow; `analyze_new_pdf.py` is only a pre-pass.

The build is not acceptable unless the machine-readable per-paper manifest can be parsed as one JSON object per physical line and every record includes:

- `workflow_alignment="delta-contribution-reframer"`;
- `deep_read_workflow_alignment="llm-full-paper-deep-read"`;
- `llm_deep_reading.status="complete"`;
- `llm_deep_read_record`;
- `source_ledger`;
- `evidence_boundary`;
- `target_regime_summary`;
- `broken_assumptions_or_failure_modes`;
- `surface_delta`;
- `stronger_delta`;
- `claim_support_matrix`;
- `story_option_board`;
- `workflow_coverage`.

If any of these are missing, stop before synthesis/package validation. Do not ship a generated skill whose reference-paper analysis is shallower than the target `delta-contribution-reframer` workflow or whose real corpus was only rule-analyzed.


## v1.1.1 Child Skill Sync

Generated child skills must inherit the full current methodology from `references/report_playbook/child_skill_generation_sync.md` and `references/report_playbook/child_skill_inheritance_contract.md`: L0-L4 revisions, solution-to-scientific-question elevation, web-safe dynamic meta-graph, literature evidence guard, local-KB pattern construction, related-work intake, submission-context gate, edit-ready patches, minimal decisive experiments, revision loop, figure/table audit, baseline fairness, and citation support. Packaging a child skill with the older casebook-only behavior is not enough.

## v1.1.2 Quality-Gated Professional Corpus

When the user wants a professional reusable child skill or top-conference/top-journal level guidance, do not build from merely related papers. Build from a quality-gated corpus.

Recommended additional inputs:

- `--venue-profile <venue_profile.json>` when available;
- user-provided field top venues/journals if the field is specialized;
- separate caps for anchor-positive, review-rich, negative-risk, frontier, and evaluation sources.

The build report should state whether the generated skill is:

- `top-quality-anchored`: enough anchor-positive sources were fully read;
- `mixed-quality`: useful but not mainly top-tier;
- `discovery-only`: not enough full high-quality sources for reusable positive patterns.

This status matters. A discovery-only corpus can help search and warn, but it should not be marketed as a top-tier paper advisor.


## v1.1.6 Child Skill Regression Gate

After packaging a generated child skill, check that it inherited the execution-oriented target-paper workflow:

- fixed startup menu and child zip prefix;
- related-work intake before final target-paper analysis;
- submission-context gate;
- edit-ready patch generation;
- minimal decisive experiment planning;
- revision iteration loop;
- literature guard and source-quality gate.

Use `references/report_playbook/child_skill_regression_test.md` as the human-readable checklist. When a generated skill directory is available, `scripts/check_child_skill_regression.py <skill_dir>` can smoke-test required files and router markers.

## v1.1.9 Hard Child Inheritance Gate

A generated child skill must inherit the parent methodology, not only the domain-specific casebook. Before final handoff, enforce `references/report_playbook/child_skill_inheritance_contract.md`: required playbooks must exist, router gates must remain in `SKILL.md`, startup templates must use the child zip prefix, and `references/knowledge_manifest.json` must declare the inherited methodology. Run `scripts/check_child_skill_regression.py <skill_dir>` after packaging. If it fails, fix the child skill or label it experimental/debug-only.


## v1.1.11 Child-Skill Corpus Intake Gate

Before building or updating a child skill, load `references/report_playbook/child_skill_corpus_intake_gate.md`. Do not start source discovery or package a production-ready child skill from vague instructions like “find related papers.” Confirm research field(s), years, per-year paper quantity, source venues/journals/official sites/databases, local folders or uploaded PDFs/project-run, and existing child skill when updating. If multiple fields are supplied, build a balanced field×year quota table. If a target PDF is used to infer fields, ask the user to approve the inferred fields before corpus discovery.


## v1.1.12 Disjunctive Corpus Intake

For child skill construction/update, interpret multiple domains, years, source venues/databases, and local folders/PDF sets as OR candidate pools unless the user explicitly requests an intersection. Build a field×year quota plan, collect candidates from any allowed source pool, and report missing cells as quota gaps rather than forcing unrelated papers.
