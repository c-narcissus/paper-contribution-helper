## v1.1.5 - Related-Work Intake and Comparative Deep Read

- Version-bumped the main package from v1.1.4 to v1.1.5 because target-paper analysis now includes a related-work intake gate.
- Added `references/report_playbook/related_work_intake_and_comparative_deep_read.md`.
- Direct analysis, L0-L4 revision, high-level elevation, reviewer defense, and dynamic meta-graph workflows now ask whether the author wants to provide closest related papers, baselines, competing methods, reviews, or rebuttal materials before the final analysis.
- If supplied, related papers must be deep-read and compared as user-provided sources; if absent, the skill mines the target paper's references, related work, experiments, baselines, limitations, and frontier claims for verified retrieval paths or search-plan-only candidates.
- Updated target-report contracts and child-skill templates so generated professional helper skills inherit the same comparative deep-read and literature no-hallucination behavior.
- Updated startup templates to `paper-contribution-helper-v1.1.5.zip` and added related-work guidance to the direct-analysis templates.

## v1.1.4

- Version-bumped the main package from v1.1.3 to v1.1.4 because the startup-menu prompt templates changed.
- Added the explicit prefix `直接使用paper-contribution-helper-v1.1.4.zip里的skill，` to every main startup-menu template so users copy prompts that name the exact skill zip version.
- Updated the generated child-skill template to follow the same pattern with `直接使用{{SKILL_NAME}}.zip里的skill，`, so child skills name their own zip instead of the parent package.
- Documented the template-prefix convention in `references/report_playbook/startup_feature_menu.md`.

## v1.1.3 - startup feature menu

- Adds a strict first-turn startup menu: list core functions and prompt templates only; never answer the user's substantive task in the startup turn.
- Documents the startup-menu behavior in `startup_feature_menu.md` and the startup initialization workflow.
- Synchronizes the startup-menu rule into generated child-skill templates.
- Keeps the router valid by moving detailed operational policy out of the top-level line budget while preserving project-files-first behavior.

# Release Notes

## v1.0.9

- Added a benchmark-adapted analysis layer for popular GitHub research-assistant projects: external tools are evaluated for target-draft fit, danger, and adapted local rules rather than copied directly.
- Added target-paper playbooks for claim-evidence-risk mapping, reviewer-question answerability, paper logic completeness, risk self-disclosure, frontier topic alignment / novelty collision, and simulated review panels.
- Updated target-paper workflow and quality contract so stronger contribution framing must be evidence-bounded, answerability-aware, scope-controlled, and trend-aware only when a real bridge exists.
- Updated generated domain-skill templates and target-PDF pre-pass scaffolds so child skills inherit the new adapted methodology.

## v1.0.8

- Fixed a Windows/Markdown path rendering hazard where paths containing `\_`, such as `...\_skill_runtime\...`, could be displayed without the backslash before `_skill_runtime`.
- Updated path policy and generated-skill instructions: prefer workspace-relative paths in user-facing output; if an absolute Windows path is explicitly needed, show it in a fenced code block or normalize it to forward slashes rather than placing a raw drive-letter path in a Markdown link or inline sentence.
- Clarified that generated ZIP/package locations should be reported as relative paths when possible, with raw machine absolute paths treated as secondary diagnostic information only.

## v1.0.7

- Changed generated target-paper report delivery to use portable workspace-relative `reports/` paths instead of user-facing raw machine absolute paths.
- Updated `scripts/analyze_new_pdf.py` in the generated-skill template so persisted source ledgers omit machine-specific absolute directories for user PDFs, reviews, replies, and skill roots.
- Updated generated-skill instructions to prevent leaking internal drafting notes, placeholders, or raw Windows drive paths as final user-facing report links.

## v1.0.6

- Added a load-safe public report mirror for target-paper analysis. `scripts/analyze_new_pdf.py` now reports both the original `public_report` path and a `load_safe_public_report` path under the workspace `reports/` directory.
- The load-safe report scaffold is written as UTF-8 with BOM to avoid Windows/Markdown clients failing to load hidden overlay paths, paths with spaces/non-ASCII characters, or non-BOM UTF-8 Markdown.
- Updated generated-skill templates and usage instructions so final user-facing target-paper reports should be saved to and linked from `load_safe_public_report` when available.

## v1.0.5

- Changed target-paper analysis default output from an exhaustive matrix-style report to a plain advisor/teacher-style report: conclusion first, direct Chinese explanation, fewer tables, and concrete rewrite advice.
- Added `references/report_playbook/plain_teacher_reporting.md` and made generated child skills inherit it.
- Updated target-report contracts and workflows so six-route boards, full comparison matrices, and long anonymous appendices are detailed-mode outputs only when explicitly requested.
- Updated the target PDF pre-pass scaffold so newly generated skills create a readable plain-report scaffold by default.

## v1.0.4

- Added an explicit no-backend continuation rule: missing `OPENAI_API_KEY`, ACP/acpx, or a local LLM backend must move a project-internal corpus into current-assistant local deep reading instead of ending the task.
- Added `scripts/engine/continue_local_deep_read.py`, an idempotent coordinator that validates a run, creates extraction/rule-prepass artifacts, prepares assistant-readable packets, and imports assistant-written records when available.
- Clarified that `waiting_for_current_assistant_read` is an in-progress handoff state, not a final blocker.
- Updated generated-skill templates so child skills inherit the same no-backend local deep-read continuation behavior.

## v1.0.3

- Reframed corpus selection around `contribution-reframing-useful` papers instead of merely finding papers with visible incremental/A+B/C/engineering/transfer risk.
- Added `references/corpus_screening_strategy.md` with explicit `positive_framing`, `contested_accepted`, `negative_risk`, `domain_reference`, and `unclear` candidate roles.
- Added `web-abstract-pdf-mixed` source-mode documentation for web abstracts with partial PDF availability. Abstract-only records are discovery candidates only; reusable cases still require full-PDF deep reading.
- Added a web abstract/PDF manifest adapter script that preserves all abstract records in discovery artifacts and creates project material folders only for records with local or downloadable PDFs.
- Clarified that keyword matching is a broad recall mechanism, while semantic screening and full-paper evidence decide reference usefulness.

## v1.0.2

- Added a modular current-assistant local deep-read route for project-run corpora when `OPENAI_API_KEY`, local command backends, or ACP/acpx are unavailable.
- Added assistant packet preparation, assistant-written JSONL validation, and import scripts.
- Added JSON config-file support for build/synthesis stages so long domain/year inputs can move out of CLI arguments.
- Shortened generated domain-profile filenames with a stable hash to avoid Windows long-path failures while preserving full domain metadata in manifests and report content.

## v1.0.0

- Initial `paper-contribution-helper` package.
- Modularized the skill around a small router, on-demand workflow references, explicit module boundaries, context loading policy, and path hygiene validation.
- Added a mandatory first-response opening rule: on first invocation, the skill outputs the fixed opening message only and does not answer substantive questions until the user replies again.
- Added an ACP command-file bridge for environments without `OPENAI_API_KEY`; long full-paper prompts are passed through request/prompt/response files instead of command-line arguments.
- Added target-paper domain inference: users can provide `--target-paper` instead of manually supplying `--focus-domains`.
- The factory deep-reads the whole target PDF, infers 1-3 searchable domains or subfields, records the inference artifact, and uses those labels for corpus screening.
- Documented the more user-friendly startup path and the evidence boundary for inferred routing metadata.
- Made downloaded project corpus files the primary initialization path through `references/project_corpus_direct_workflow.md`, covering both `project-run` and `local-pdf`.
- Clarified that ACP/acpx is only an optional `command-file` fallback when no API key, local command backend, or precomputed JSONL backend is available.
- Added explicit context-limit policy: never paste full PDFs or a complete corpus into chat context; use project files, chunking, intermediate artifacts, manifests, and `--reuse-llm`.
- Split the PDF entrypoint into two explicit modes: direct target-paper analysis, or target-PDF/domain-field input for generating a specialized reusable skill.
- Added the rule that an unspecified PDF upload must trigger a two-choice clarification before any analysis or corpus build starts.
- Reworded the mandatory startup message around clear A/B entrypoints so users can distinguish direct paper analysis from specialized skill generation.
- Locked the mandatory startup message to the exact user-approved text as a highest-priority first-response rule.
- Added a project-internal corpus stage contract: downloaded/provided `project-run` or `local-pdf` materials must continue through validation, extraction, per-paper artifacts, manifests, and explicit LLM status even when final synthesis/packaging is blocked.
- Promoted local project-file processing to the highest operational priority after the first-response rule: downloaded/uploaded/standardized PDFs, reviews, replies, metadata, and corpus runs must be processed from disk first; API/acpx/local command backends are optional automation routes, not permission gates.

## v1.1.0 - Scientific-Elevation and KG-Frontier Upgrade

- Added an L0-L4 multi-layer revision ladder so reports can move from wording fixes to argument repair, evidence repair, scientific-question elevation, and frontier/boundary expansion.
- Added solution-to-scientific-question elevation: solution -> failure mode -> broken assumption -> scientific question -> principle/mechanism -> research program.
- Added scholarly knowledge-graph frontier retrieval with multi-hop paths over closest priors, constraints, failure modes, method primitives, evaluation norms, and adjacent domains.
- Added scientific boundary roadmap and top-scientist advisor lens for ambitious but evidence-labeled high-level advice.
- Added `scripts/discover_scholarly_kg_frontier.py` as a small optional discovery pre-pass for OpenAlex/Semantic Scholar style KG search. Network failures are recorded instead of blocking the workflow.
- Updated target-report contracts, workflow, generated-skill template, and pre-pass scaffold so generated child skills inherit the elevation workflow.


## v1.1.1 — Web-safe meta-graph, local KB, and literature evidence guard

- Clarified that KG-style frontier reasoning must not assume a persistent thread-level knowledge graph.
- Added a fixed meta-graph schema and a paper-specific dynamic graph workflow for ChatGPT Web use.
- Added a no-hallucination literature evidence guard: no unverified paper titles, no unsupported “latest work shows”, and no external claims without source labels.
- Added local KB construction rules that distinguish defense, negative-risk, collision, frontier, and evaluation corpora.
- Added child-skill sync requirements so generated domain skills inherit L0-L4 revision, scientific elevation, web-safe dynamic meta-graph, and literature evidence rules.
- Added `build_dynamic_metagraph_plan.py` for offline/local query-plan generation.

## v1.1.2 — Source/Venue Quality Gate

- Added `source_quality_gate.md` so reusable positive templates must come from field-appropriate, quality-gated sources rather than merely related papers.
- Added `source_strategy_venue_quality.md` to distinguish CS top-conference norms, journal-centric fields, humanities/social-science norms, and interdisciplinary venue standards.
- Added `scripts/screen_source_quality_gate.py`, an offline helper that annotates paper manifests with quality roles using a project-local venue profile.
- Updated local-KB construction, target-report contracts, KG frontier strategy, and child-skill generation sync so L3/L4 scientific-elevation advice is quality-aware.
- Clarified that arXiv, GitHub, blogs, workshops, and trend pages may be useful for discovery or collision risk but should not become positive templates unless verified and quality-gated.

## v1.1.6 - Execution-Oriented Revision Flow

- Added submission-context gate and target venue/journal rubric adapter.
- Added edit-ready patch generation for abstract, contribution, related work, figures/tables, experiments, limitations, and rebuttal snippets.
- Added minimal decisive experiment planner, revision iteration loop, figure/table evidence audit, baseline fairness/reproducibility ledger, and citation-role support audit.
- Added child skill regression test checklist and script so generated child skills inherit startup, related-work, evidence guard, and execution-oriented workflows.
- Synced all new playbooks into the domain-skill template.

## v1.1.7 - Child Skill Inheritance Lock

- Promoted child-skill sync from a recommendation to a hard inheritance contract.
- Added `references/report_playbook/child_skill_inheritance_contract.md` and copied it into the domain-skill template.
- Expanded child regression testing to check required playbooks, router gates, startup prefix behavior, and `knowledge_manifest.json` inherited methodology declarations.
- Updated packaging manifest to declare `v1.1.7-child-inheritance-locked` and the full inherited workflow list.
- Updated `build_domain_skill.py` so generated child skills run the inheritance regression check after normal validation and startup checks.
- Updated startup templates to reference `paper-contribution-helper-v1.1.7.zip`.
## v1.1.8 - Default Comprehensive Workflow Prompt

- Added startup template `0` for a full workflow entrypoint.
- The default prompt asks the skill to choose among direct target-paper analysis with packaged/internal knowledge, generating a new specialized child skill, or updating/extending an existing child skill.
- Added `references/report_playbook/default_comprehensive_workflow.md` and copied it into the domain-skill template.
- Updated generated child-skill templates, inheritance manifest, and regression checks so child skills also include the default route-selector prompt.
- Updated startup template prefixes to `paper-contribution-helper-v1.1.8.zip`.


## v1.1.9 - Explicit Mode + A-D Analysis-Direction Menu

- Removed the default prompt that asked the skill to decide among direct analysis, new child-skill build, or existing child-skill update.
- Startup now separates work modes from PDF analysis directions: 模式1 build new child skill, 模式2 use package/internal knowledge to analyze, 模式3 update existing child skill.
- A/B/C/D are now analysis directions for the paper and can be combined, e.g. A+B+C+D.
- Updated child-skill inheritance/regression checks to require the mode/direction menu instead of the default comprehensive route selector.


## v1.1.10 - Child Skill Corpus Intake Gate

- Added a required corpus-intake gate for building or updating child skills.
- Mode 1/3 require research fields, years/year range, source venues/journals/official sites/databases, local folders or uploaded PDFs/project-run, and existing child skill for updates.
- Updated child-skill inheritance/regression checks and manifests to require the corpus-intake playbook.


## v1.1.11 - Balanced Per-Year Corpus Quota

- Replaces the Mode 1/3 startup field `质量要求` with `每年数量` / per-year paper quantity.
- Supports multiple explicit years or year ranges for child-skill corpus construction and update.
- When multiple research fields are supplied, requires a balanced `field × year` quota plan where verified papers exist.
- Adds `field_year_balanced_sampling.md` and inherits it into generated child skills.
- Regression checks now require per-year quantity markers and field-year balanced sampling in child-skill manifests.


## v1.1.12 - Disjunctive Corpus Intake

- Simplifies the Mode 1 startup template from `构建新的___方向专业子skill` to `构建子skill` because `研究领域=___` already specifies the domain.
- Simplifies the Mode 3 update template to `更新/扩展子skill`.
- Defines multiple research fields, multiple years, multiple sources, and multiple local materials as OR candidate pools by default, not AND/intersection filters.
- Keeps multi-field, multi-year child-skill corpora balanced by field×year quota while reporting quota gaps honestly.
