# Claim-Evidence-Risk Map

Use this playbook whenever a target paper is being reframed, especially if it may look incremental, A+B+C, engineering-only, or like old methods moved to a new setting.

## Goal

Every strong contribution sentence must be tied to evidence already present in the target paper or clearly marked as a future-boundary hook. This keeps the report strong but honest.

## Required Map

Create a compact map before finalizing contribution bullets:

| Candidate claim | Claim class | Evidence anchor in target paper | Evidence strength | Reviewer risk | Safe wording | Unsafe overclaim | Repair tier |
|---|---|---|---|---|---|---|---|

Use these claim classes:

- `paper-explicit`: directly stated and supported by the target paper.
- `latent-but-supported`: not phrased well in the manuscript, but supported by existing method/experiment/ablation evidence.
- `story-level reframing`: an organizing narrative that connects existing evidence without adding a new factual claim.
- `future-boundary hook`: plausible direction or implication that lacks current evidence; only usable in limitation/future work.

## Evidence Strength Labels

- **Strong**: supported by method design plus direct experiment/ablation/analysis.
- **Medium**: supported by method design plus partial or indirect evidence.
- **Weak**: only suggested by motivation, qualitative argument, or one narrow result.
- **Missing**: not supported in the current paper.

## Downgrade Rules

- If evidence is **Weak**, do not put the claim in contribution bullets unless it is softened.
- If evidence is **Missing**, move it to future work or remove it.
- If a mechanism is only supported by ablation, say **supports** or **is consistent with**, not **proves**.
- If generalization is tested on a narrow setting, write a bounded-regime claim, not a universal claim.
- If cost, privacy, safety, robustness, or reproducibility are not directly evaluated, disclose the boundary rather than claiming resolution.

## A+B+C-Specific Check

For each module, ask:

1. Which failure mode does this module repair?
2. Why does the constrained setting make this repair necessary?
3. What evidence shows this module contributes more than extra complexity?
4. What happens if this module is removed, replaced, or cost-normalized?
5. Does the paper show interaction between modules, or only independent improvements?

If the answers are weak, the final report must recommend either claim softening or a diagnostic experiment.

## Output Requirement

The final report should not dump a huge table by default. It should use the map internally and then show only the highest-risk claims in a concise section, with safe vs unsafe wording.
