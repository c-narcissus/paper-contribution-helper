#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any


def fetch_json(url: str, timeout: int = 30) -> dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": "paper-contribution-helper/1.1"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec: user-selected scholarly APIs
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def safe_fetch(url: str) -> dict[str, Any]:
    try:
        return {"ok": True, "data": fetch_json(url), "url": url}
    except Exception as exc:  # network/API may be unavailable in offline runs
        return {"ok": False, "error": str(exc), "url": url}


def openalex_search(query: str, per_page: int) -> list[dict[str, Any]]:
    url = "https://api.openalex.org/works?" + urllib.parse.urlencode({
        "search": query,
        "per-page": str(per_page),
        "sort": "publication_date:desc",
    })
    payload = safe_fetch(url)
    if not payload["ok"]:
        return [{"source": "openalex", "query": query, "status": "error", "error": payload["error"], "url": payload["url"]}]
    rows = []
    for item in payload["data"].get("results", []):
        rows.append({
            "source": "openalex",
            "query": query,
            "status": "ok",
            "id": item.get("id"),
            "title": item.get("title"),
            "year": item.get("publication_year"),
            "publication_date": item.get("publication_date"),
            "cited_by_count": item.get("cited_by_count"),
            "concepts_or_topics": [c.get("display_name") for c in item.get("concepts", [])[:8] if c.get("display_name")],
            "referenced_works": item.get("referenced_works", [])[:12],
            "url": item.get("doi") or item.get("id"),
            "evidence_label": "external-frontier",
        })
    return rows


def semantic_scholar_search(query: str, limit: int) -> list[dict[str, Any]]:
    fields = "title,year,venue,citationCount,referenceCount,influentialCitationCount,fieldsOfStudy,publicationDate,url,abstract"
    url = "https://api.semanticscholar.org/graph/v1/paper/search?" + urllib.parse.urlencode({
        "query": query,
        "limit": str(limit),
        "fields": fields,
    })
    payload = safe_fetch(url)
    if not payload["ok"]:
        return [{"source": "semantic_scholar", "query": query, "status": "error", "error": payload["error"], "url": payload["url"]}]
    rows = []
    for item in payload["data"].get("data", []):
        rows.append({
            "source": "semantic_scholar",
            "query": query,
            "status": "ok",
            "id": item.get("paperId"),
            "title": item.get("title"),
            "year": item.get("year"),
            "venue": item.get("venue"),
            "publication_date": item.get("publicationDate"),
            "citation_count": item.get("citationCount"),
            "influential_citation_count": item.get("influentialCitationCount"),
            "fields_of_study": item.get("fieldsOfStudy") or [],
            "abstract_hint": (item.get("abstract") or "")[:600],
            "url": item.get("url"),
            "evidence_label": "external-frontier",
        })
    return rows


def make_queries(seed: str) -> list[dict[str, str]]:
    seed = seed.strip()
    templates = [
        ("closest-prior", seed),
        ("constraint-hop", f"{seed} constraint robustness scarcity privacy non-iid evaluation"),
        ("failure-mode-hop", f"{seed} failure mode benchmark diagnostic limitation"),
        ("frontier-hop", f"{seed} survey position paper open problem frontier"),
        ("evaluation-hop", f"{seed} benchmark dataset metric reproducibility cost ablation"),
    ]
    return [{"path_type": t, "query": q} for t, q in templates]


def main() -> None:
    parser = argparse.ArgumentParser(description="Small scholarly-KG frontier discovery helper. Network/API failures are recorded, not fatal. Use build_dynamic_metagraph_plan.py first in Web-safe/offline settings.")
    parser.add_argument("--seed", action="append", default=[], help="Seed topic, method, problem, constraint, or closest-prior title. Repeatable.")
    parser.add_argument("--seed-file", type=Path, default=None, help="Optional text file with one seed per line.")
    parser.add_argument("--out-dir", type=Path, default=Path("kg_frontier_run"))
    parser.add_argument("--per-query", type=int, default=5)
    parser.add_argument("--sleep", type=float, default=0.2)
    args = parser.parse_args()

    seeds = list(args.seed)
    if args.seed_file and args.seed_file.exists():
        seeds.extend([line.strip() for line in args.seed_file.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip()])
    if not seeds:
        raise SystemExit("Provide --seed or --seed-file.")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for seed in seeds:
        for q in make_queries(seed):
            for row in openalex_search(q["query"], args.per_query):
                row.update({"seed": seed, "path_type": q["path_type"]})
                records.append(row)
            time.sleep(args.sleep)
            for row in semantic_scholar_search(q["query"], args.per_query):
                row.update({"seed": seed, "path_type": q["path_type"]})
                records.append(row)
            time.sleep(args.sleep)

    jsonl = args.out_dir / "kg_frontier_records.jsonl"
    jsonl.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in records) + "\n", encoding="utf-8")

    md = [
        "# Scholarly KG Frontier Discovery Notes",
        "",
        f"Generated at: {dt.datetime.now().isoformat(timespec='seconds')}",
        "",
        "This is a discovery pre-pass, not target-paper evidence. Label results as external-prior, external-frontier, external-evaluation-norm, external-collision-risk, or external-analogy after inspection.",
        "",
        "Web-safe note: do not assume a persistent thread KG. If API calls failed or were not run, treat this as a retrieval plan, not verified literature.",
        "",
        "## Seeds",
        "",
    ]
    md.extend(f"- {s}" for s in seeds)
    md.extend(["", "## Suggested Reading Questions", ""])
    md.extend([
        "1. Which results are closest-prior collision risks?",
        "2. Which papers share the same constraint or failure mode but use a different method primitive?",
        "3. Which recent papers introduce evaluation norms missing from the target paper?",
        "4. Which adjacent-domain papers suggest a high-level scientific question?",
        "5. Which frontier ideas are only proposal-level and must not be written as current claims?",
        "",
        f"Raw records: `{jsonl.name}`",
    ])
    (args.out_dir / "kg_frontier_notes.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps({"records": len(records), "out_dir": args.out_dir.as_posix(), "jsonl": jsonl.as_posix()}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
