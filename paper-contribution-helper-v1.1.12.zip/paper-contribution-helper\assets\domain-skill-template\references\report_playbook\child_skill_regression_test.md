# Child Skill Regression Test

Use this playbook after generating or updating a professional reusable child skill.

## Main Idea

A child skill should not silently lose the parent skill's safety and high-level reasoning rules.

## Required Smoke Tests

Run or mentally check these prompts before packaging/signing off:

1. Startup behavior: first reply shows only the menu and templates.
2. Related-work intake: target analysis asks for closest papers/baselines before final report.
3. Literature guard: when no verified papers are available, it outputs search-plan-only rather than invented literature.
4. Source quality gate: it does not treat weak or unverified papers as top-quality positive templates.
5. L0-L4 ladder: it can produce low-level edits and high-level scientific-question elevation.
6. Edit-ready patches: it can give safe manuscript snippets without overclaiming.
7. Minimal experiment plan: it can identify the one most decisive missing experiment.
8. Revision loop: it can re-check a revised version instead of repeating the initial report.
9. Child prefix: startup templates use the child zip name, not the main package name.
10. Child boundary: startup does not expose the parent package route for generating another reusable helper.

## Regression Report

Before final handoff, create a short `child_skill_regression_report.md` or include a summary:

| Test | Pass? | Evidence / note |
|---|---|---|
| startup menu | yes/no | ... |
| related-work gate | yes/no | ... |
| hallucination guard | yes/no | ... |

## Failure Handling

If any test fails, do not claim the child skill is ready. Either fix the template/resources or label the package as experimental/debug-only.

## v1.1.9 Inheritance Regression

The regression check must cover more than startup behavior. It must also verify that the generated child skill inherited the parent methodology:

- required playbook files exist;
- router text contains related-work intake and submission-context gates;
- startup templates use the child zip name;
- `knowledge_manifest.json` declares current inherited methodology;
- target-paper reporting rules mention L0-L4, scientific-question elevation, edit-ready patches, minimal decisive experiments, and literature guard.

A child skill that has only the casebook but lacks these inherited workflow pieces is not ready.


## v1.1.9 Default Prompt Regression

Regression checks must verify that the child skill contains the mode/direction startup menu, the `分析方向` marker, and the `mode/direction startup menu` manifest item.

Generated child skills must keep direct-analysis and update/extension work modes only. The regression check must fail if the child startup exposes the parent package route for generating another reusable helper.


## v1.1.12 Corpus Intake Regression

Regression checks must verify that child skills include `child_skill_corpus_intake_gate.md` and `field_year_balanced_sampling.md`, startup markers for research field(s), years, per-year quantity, sources, and local materials, and manifest text containing `child-skill corpus intake gate` and `field-year balanced corpus sampling`.


## v1.1.12 Disjunctive Corpus Intake Sync

Child skills must inherit the rule that multiple research fields, years, sources, and local materials are OR candidate pools by default. They must not treat them as an AND/intersection filter unless the user explicitly says so.
