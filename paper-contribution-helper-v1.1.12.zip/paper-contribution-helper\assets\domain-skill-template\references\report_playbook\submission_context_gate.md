# Submission Context Gate

Use this gate after the startup menu and related-work intake, before producing a final target-paper report.

## Why This Gate Exists

同一篇论文，投 workshop、普通会议、顶会、顶刊，修改策略不一样。没有投稿目标和修改预算，advisor 很容易给出“正确但不落地”的建议。

The gate should collect enough context to decide whether to recommend wording repair, story restructuring, new experiments, or a larger research-program roadmap.

## Compact Intake Question

Ask one compact question unless the user already gave the information:

```text
再确认一下投稿上下文：目标会议/期刊是什么？离截止还有多久？现在还能补实验吗，大概能补几个？有没有页数限制？你希望这次是保守改稿，还是愿意重构故事线？

如果你不想补充，就回复“按默认顶会/顶刊严格标准先分析”，我会明确写出默认假设。
```

Do not trap the user in a long form. If the user wants immediate analysis, proceed with stated assumptions.

## Default Assumptions When Missing

If context is missing, use conservative defaults:

- target quality: field-recognized top conference/journal bar;
- experiment budget: unknown, so separate no-new-experiment fixes from minimal-new-experiment fixes;
- page budget: constrained, so prioritize abstract, introduction, contribution bullets, related work boundary, method overview, and main experiment narrative;
- risk posture: strong but honest; no overclaiming.

State these defaults in plain Chinese before the report.

## Required Output Fields

Include a small context card:

| Field | Value / assumption | Effect on advice |
|---|---|---|
| target venue/journal | given or assumed | strictness of novelty/evidence bar |
| deadline | given or unknown | whether to prioritize no-new-experiment fixes |
| experiment budget | none / 1 / 3+ / unknown | L2 evidence plan |
| page budget | tight / flexible / unknown | how much restructuring to recommend |
| risk posture | conservative / ambitious / unknown | claim wording strength |

## How It Changes L0-L4 Advice

- L0: if deadline is tight, prioritize abstract, contribution bullets, related-work boundary, and figure captions.
- L1: if the story is weak but experiments are fixed, restructure the problem-to-claim chain.
- L2: if one experiment is possible, recommend the single most decisive experiment.
- L3: if aiming at top venues, identify the broken assumption and scientific question explicitly.
- L4: only propose frontier/boundary expansion as discussion or future work unless new evidence is feasible.
