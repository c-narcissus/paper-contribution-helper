# Generated Skill Contract

## Required Layout

```text
<generated-skill>/
  SKILL.md
  agents/openai.yaml
  references/
    knowledge_manifest.json
    anonymous_casebook.jsonl
    per_pdf_report_synthesis.md
    llm_deep_read_synthesis.md
    domain_profile_*.md
    evidence_policy.md
    evolution_policy.md
    usage_workflows.md
    llm_deep_reading_workflow.md
    report_playbook/plain_teacher_reporting.md
  scripts/
    startup_check.py
    analyze_new_pdf.py
    evolve_casebook.py
    validate_skill_package.py
    engine/                         # full blank delta initializer engine
  references/
    base_delta/                     # full blank delta workflows/contracts
```

## Portability Requirements

- `knowledge_manifest.json` stores package-relative paths.
- `anonymous_casebook.jsonl`, `per_pdf_report_synthesis.md`, and `llm_deep_read_synthesis.md` are non-empty for initialized real-corpus packages.
- No old PDFs, raw review dumps, forum IDs, URLs, authors, or paper titles are bundled.
- No full-paper LLM prompts, chunk outputs, or per-paper LLM reports are bundled.
- Startup must not require project-local initialization.
- Evolution from new papers writes a local overlay by default.
- If packaged base knowledge is absent, the generated skill must still expose the same initialization workflows and scripts as the blank `delta-contribution-reframer`.

## Delta Reframer Parity Requirements

Generated skills must stay behaviorally aligned with `delta-contribution-reframer`.

- Target-paper analysis must follow `references/base_delta/workflow_target_paper_reframing.md`.
- `scripts/analyze_new_pdf.py` is only an extraction and pattern-detection pre-pass; it must mark `prepass_only=true`, save target evidence artifacts, and create a full-report scaffold.
- A final target-paper report must default to the plain advisor style: source/evidence boundary, target regime, broken assumptions, surface-vs-stronger delta, practical rewrite advice, reviewer attacks, revision priorities, and manuscript/rebuttal snippets. Detailed claim matrices and ranked story-option boards are required only when the user asks for detailed mode.
- Corpus/reference-paper analysis must use the same full reframing structure for every selected paper, not only pattern matching.
- Corpus/reference-paper analysis must run a full-paper LLM deep-read for every selected PDF before synthesis. Chunking is allowed; selective reading is not.
- Abstract-only discovery records are not selected corpus papers and must not be packaged into anonymous casebooks. If they are preserved, keep them only in project discovery artifacts or pending acquisition notes.
- Generated casebooks should distinguish `positive_framing`, `contested_accepted`, and `negative_risk` roles when that information is available. Negative cases support attack taxonomy and risky wording, not recommended contribution templates.
- `analysis/per_paper/<paper_key>/analysis.md` must include source ledger, evidence boundary, reference regime/failure modes, surface-vs-stronger delta, claim-support matrix, story option board, review attack analysis, reply move analysis, and reuse priorities.
- `analysis/per_paper/<paper_key>/analysis_record.json` and `analysis/per_paper_analysis_manifest.jsonl` must declare `workflow_alignment="delta-contribution-reframer"` and `deep_read_workflow_alignment="llm-full-paper-deep-read"`, have `llm_deep_reading.status="complete"`, and include `llm_deep_read_record`, `source_ledger`, `evidence_boundary`, `target_regime_summary`, `broken_assumptions_or_failure_modes`, `surface_delta`, `stronger_delta`, `claim_support_matrix`, `story_option_board`, and `workflow_coverage`.
- Generated packages must include `references/base_delta/workflow_target_paper_reframing.md` and `references/base_delta/contract_story_options.md`.
- Synthesis and packaging must fail if the per-paper manifest is missing, empty, malformed, not line-safe JSONL, lacks any required parity field, or shows incomplete LLM deep-reading.


## v1.1.1 Generated Child Skill Requirements

A generated child skill must include the web-safe dynamic meta-graph, literature evidence guard, local KB construction, and child-skill sync playbooks. The packaged knowledge must be anonymous pattern knowledge with source/reuse boundaries. It must not package raw PDFs, raw review dumps, unverified latest-literature claims, or hidden thread-graph assumptions.

## v1.1.9 Mode/Direction Menu Child Skill Requirements

Generated child skills must inherit the parent methodology, not just anonymous case resources. A production-ready child skill must include `references/report_playbook/child_skill_inheritance_contract.md`, preserve related-work and submission-context router gates, keep startup prompt prefixes with the child zip filename, and declare `v1.1.12-disjunctive-corpus-intake` plus the full inherited methodology list in `references/knowledge_manifest.json`.

Packaging is not complete until `scripts/check_child_skill_regression.py <child_skill_dir>` passes. If it fails, the child skill may be shared only as experimental/debug-only with the missing inherited blocks named explicitly.


## v1.1.9 Mode and Analysis-Direction Menu Requirement

Generated child skills must include the compact mode/direction startup menu. Work modes must be explicit choices, while A-D are analysis directions for the target PDF and may be combined. Do not include a default prompt that asks the skill to auto-decide direct analysis vs build vs update.


## v1.1.11 Child Corpus Intake Requirement

Generated child skills must include `child_skill_corpus_intake_gate.md` and `field_year_balanced_sampling.md`, and declare them in `knowledge_manifest.json`. Mode 1/3 prompts must collect research field(s), years, per-year paper quantity, source venues/journals/official pages/databases, local folders/uploaded PDFs/project-run, and existing child skill information for updates before build/update execution. With multiple fields, the planned corpus must be balanced across field×year cells when verified sources exist.


## v1.1.12 Disjunctive Corpus Intake Requirement

When building or updating child skills, multiple research fields, years, sources, and local-material entries are OR candidate pools by default. They should be covered and balanced, not intersected, unless the user explicitly requests AND/交集/必须同时满足 semantics. Child skills must preserve this rule in startup templates, corpus-intake playbooks, and regression manifest declarations.
