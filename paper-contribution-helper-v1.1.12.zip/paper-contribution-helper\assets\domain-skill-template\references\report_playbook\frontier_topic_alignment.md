# Frontier Topic Alignment And Novelty Collision

Use this playbook when the user asks how to connect a paper to current research topics, check novelty collisions, or make the work feel timely without hype.

## Principle

Do not rename an old contribution with fashionable terms. Bridge only through real shared constraints, evaluation gaps, system bottlenecks, or interfaces.

## Two-Corpus Rule

Keep two corpora separate:

- **Defense corpus**: mature papers, reviews, author replies, and meta-reviews used to learn how this field frames contribution and handles reviewer attacks.
- **Trend corpus**: very recent papers, workshop pages, arXiv recent entries, Hugging Face trending papers, Semantic Scholar recommendations, Papers with Code tasks, and fast-rising GitHub repositories used to detect novelty collisions and timely positioning.

The defense corpus teaches **how to defend**. The trend corpus checks **what may be new, crowded, or timely**. Do not let recent hype override target-paper evidence.

## Trend Signal Extraction

For each recent item, extract:

| Field | Question |
|---|---|
| Task | What problem is the community studying? |
| Setting | What constrained regime matters? |
| Broken assumption | What assumption has become unrealistic? |
| Failure mode | What goes wrong in current systems? |
| Method primitive | What kind of solution is being tried? |
| Evaluation protocol | What metric, benchmark, or stress test is now expected? |
| Claimed novelty | What wording is the community using? |
| Limitation | What remains open? |
| Collision risk | Is the target paper already preempted, partially overlapped, or still distinct? |

## Trend Bridge Card

For the target paper, produce cards like this:

| Trend | Why it is hot | Real connection to this paper | Safe bridge sentence | Unsafe hype sentence | Needed evidence | Collision risk |
|---|---|---|---|---|---|---|

## Safe Ways To Connect To Trends

- Shared constraint: data scarcity, privacy, distribution shift, compute, latency, reliability, evaluation, reproducibility.
- Shared interface: retrieval, memory, data-space, label-space, model-space, alignment, evaluation, deployment.
- Shared evaluation gap: robustness, contamination, cost-normalized baselines, long-tail settings, real-world constraints.
- Shared failure mode: hallucination, calibration, unreliable pseudo-labels, non-IID shift, missing validation signal, brittle composition.

## Unsafe Ways

- Rebranding a normal pipeline as an agentic or foundation-model framework without evidence.
- Adding LLM/diffusion/multimodal wording when those systems are not part of the method or motivation.
- Claiming SOTA relevance only because a trend is popular.
- Ignoring a very recent closest-prior collision.

## Novelty Collision Tiers

- **No collision**: recent work shares broad area only; emphasize difference in setting, assumptions, or evidence.
- **Partial collision**: recent work shares one module or primitive; tighten related work and highlight failure-mode/interface difference.
- **Strong collision**: recent work solves the same setting with similar method/evidence; downgrade novelty and reposition around empirical insight, system tradeoff, or missing evaluation.
- **Fatal collision**: a recent paper already makes the same claim with stronger evidence; recommend major reframing or new evidence.

## Final Report Rule

Only include trend alignment if it produces a safe bridge sentence and a clear evidence requirement. If the bridge is mostly buzzword overlap, say so plainly.
