# Web-Safe Dynamic Meta-Graph

Use this playbook whenever the user asks for knowledge-graph-style frontier retrieval, latest-topic alignment, or high-level scientific elevation, especially when the skill may run inside ChatGPT Web.

## Plain Idea

Do not assume a persistent thread knowledge graph. In ChatGPT Web, the safe default is:

1. use a fixed **meta-graph schema** shipped inside the skill;
2. rebuild a small **paper-specific dynamic graph** from the target PDF and any uploaded/current sources;
3. turn the graph into retrieval queries or reading tasks;
4. attach retrieved literature only after it is verified;
5. write the graph summary into the report so the next run can reconstruct it.

If no web/API/tool retrieval is available, output a retrieval plan instead of pretending that recent literature was checked.

## Fixed Meta-Graph Schema

### Node Types

| Node | Meaning |
|---|---|
| `TargetPaper` | the paper being analyzed |
| `TargetRegime` | the bounded setting, e.g. low-label, non-IID, privacy, scarce supervision, long-horizon, high-cost |
| `ResearchProblem` | the broader scientific problem behind the engineering solution |
| `BrokenAssumption` | what prior methods quietly assume but this setting breaks |
| `FailureMode` | the observable way existing methods fail |
| `Constraint` | resource, data, privacy, compute, deployment, safety, or supervision limit |
| `MethodPrimitive` | reusable method family: retrieval, graph, diffusion, contrastive, causal, calibration, agent loop, etc. |
| `MechanismHypothesis` | why the proposed design should work |
| `EvidenceAnchor` | table, figure, ablation, theorem, qualitative example, or appendix item from the target paper |
| `Claim` | what the paper wants to claim |
| `ReviewerRisk` | likely reviewer objection |
| `ClosestPrior` | nearest prior work or baseline family |
| `EvaluationNorm` | benchmark, metric, diagnostic, cost comparison, or stress test expected by the field |
| `FrontierTopic` | active recent topic or adjacent field direction |
| `ScientificBoundary` | information, generalization, scale, trust, evaluation, mechanism, or transfer boundary |
| `NextExperiment` | decisive experiment needed to upgrade the claim |

### Edge Types

| Edge | Meaning |
|---|---|
| `claims` | target paper claims something |
| `supports` | evidence supports a claim |
| `overclaims_without` | a claim is unsafe without missing evidence |
| `repairs` | method repairs a failure mode |
| `breaks_assumption` | target regime breaks an assumption in prior work |
| `shares_constraint_with` | external work shares the same constraint |
| `shares_failure_mode_with` | external work faces the same failure mode |
| `borrows_primitive_from` | a method primitive may transfer across fields |
| `requires_evaluation_norm` | the field expects a missing diagnostic |
| `collides_with` | external work may weaken novelty |
| `upgrades_to_question` | solution-level story becomes a scientific question |
| `touches_boundary` | the work touches a broader scientific boundary |

## Dynamic Graph Build Steps

1. **Target-only graph first.** Extract `TargetRegime`, `BrokenAssumption`, `FailureMode`, `MethodPrimitive`, `EvidenceAnchor`, `Claim`, and `ReviewerRisk` from the target PDF. Do not add external papers yet.
2. **Evidence lock.** Mark each claim as `paper-explicit`, `latent-but-supported`, `discussion-ready`, `proposal-only`, or `unsafe-now`.
3. **Retrieval seed generation.** Create seeds from graph paths, not just keywords:
   - `BrokenAssumption -> FailureMode`
   - `Constraint -> EvaluationNorm`
   - `MethodPrimitive -> adjacent domain`
   - `ClosestPrior -> cited-by / follow-up`
   - `FailureMode -> benchmark / diagnostic`
4. **External retrieval.** Use web, scholarly APIs, uploaded reference PDFs, or local corpus if available. If not available, output the query plan.
5. **Source verification.** External nodes become usable only if title/year/source and relevance are verified.
6. **Report card.** Include a compact `Dynamic Meta-Graph Card` in the report.

## Dynamic Meta-Graph Card

Use this compact format in normal reports:

| Field | Content |
|---|---|
| Current solution | what the method does |
| Higher scientific question | the general question it suggests |
| Broken assumption | what prior work assumes |
| Core failure mode | what breaks under the target regime |
| Internal evidence | target-paper table/figure/ablation support |
| Missing evidence | what would make the high-level claim stronger |
| Retrieval seeds | 3-6 graph-path queries |
| External source status | checked / not checked / uploaded-only / web-needed |
| Safe use | paper-ready / discussion-ready / proposal-only / unsafe-now |

## ChatGPT Web Rule

When running in ChatGPT Web or any environment without persistent project state:

- rebuild the dynamic graph from the current uploaded paper and visible sources each time;
- do not refer to a hidden or previous thread graph as evidence;
- if the user wants reuse, put the `Dynamic Meta-Graph Card` in the report so it can be copied into the next run;
- if retrieval tools are not available, say: `这里我只能给检索路径，不能声称已经查到最新文献。`

## Codex / Local Project Rule

When running in Codex or a local project folder, the same meta-graph may be saved as artifacts such as:

- `reports/dynamic_metagraph.md`
- `reports/dynamic_metagraph.json`
- `reports/frontier_retrieval_plan.md`
- `reports/literature_evidence_ledger.jsonl`

These files are local aids. They are not a permanent thread-level graph unless the user explicitly provides them again.
