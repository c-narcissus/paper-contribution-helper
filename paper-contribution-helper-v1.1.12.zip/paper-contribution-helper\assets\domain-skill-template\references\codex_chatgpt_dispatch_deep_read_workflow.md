# Codex/ChatGPT Dispatch Deep-Read Workflow

Use this workflow when a project corpus already exists and the Codex environment can spawn background Codex/ChatGPT workers or sub-agents. It is a parallel version of `assistant_local_deep_read_workflow.md`, not a weaker shortcut.

## When To Use

- The corpus is already a validated `project-run` or has been standardized from local PDFs.
- `analysis/per_paper/<paper_key>/pdf_text.txt` exists for every selected paper.
- The user explicitly permits Codex to dispatch ChatGPT/Codex workers, or the environment has approved sub-agent/background-thread tools and batch reading would be too slow in the main thread.
- The final build still requires `llm_deep_reading.status="complete"` and `deep_read_workflow_alignment="llm-full-paper-deep-read"` for every selected paper.

Do not use dispatch to skip full-paper reading. Each worker must read the packet and chunk files assigned to it, then write a complete assistant deep-read record.

## File Protocol

The workflow reuses the current-assistant packet contract:

```bash
python scripts/engine/continue_local_deep_read.py \
  --run-dir <run-dir> \
  --require-all
```

If the run is not yet complete, prepare dispatch tasks:

```bash
python scripts/engine/codex_chatgpt_dispatch_deep_read.py prepare \
  --run-dir <run-dir> \
  --papers-per-task 4
```

This writes:

```text
<run-dir>/analysis/codex_chatgpt_dispatch/dispatch_manifest.json
<run-dir>/analysis/codex_chatgpt_dispatch/task_001.md
<run-dir>/analysis/codex_chatgpt_dispatch/task_002.md
...
```

The orchestrating Codex thread should spawn one worker per task file when available. Each worker reads only:

```text
<run-dir>/analysis/codex_chatgpt_dispatch/task_NNN.md
<run-dir>/analysis/assistant_deep_read_packets/<paper_key>/packet.md
<run-dir>/analysis/assistant_deep_read_packets/<paper_key>/chunks/chunk_*.txt
```

For each assigned paper, the worker writes:

```text
<run-dir>/analysis/assistant_deep_read_packets/<paper_key>/assistant_deep_read_record.json
```

After workers finish, collect and validate:

```bash
python scripts/engine/codex_chatgpt_dispatch_deep_read.py collect \
  --run-dir <run-dir> \
  --require-all
```

Then import into the normal manifest:

```bash
python scripts/engine/import_assistant_deep_read_records.py \
  --run-dir <run-dir> \
  --records-jsonl <run-dir>/analysis/assistant_deep_read_records.jsonl \
  --require-all
```

## One-Step Build Handoff

`build_domain_skill.py` accepts:

```bash
python scripts/build_domain_skill.py \
  --skill-name <skill-name> \
  --focus-domains <domain> ... \
  --years <year> ... \
  --source-mode project-run \
  --project-run-dir <run-dir> \
  --llm-deep-read-mode required \
  --llm-provider codex-dispatch \
  --out-dir <out-dir> \
  --overwrite
```

If deep-read records are missing, the build stops with `CODEX_CHATGPT_DISPATCH_REQUIRED` and writes a handoff JSON containing the dispatch manifest. That is not a terminal blocker. Spawn workers, collect records, and rerun the same build command. If records are complete, the build converts to `jsonl` import and continues to synthesis/package validation.

## Worker Quality Rules

- Read every assigned chunk before setting `reading_status="complete"`.
- Treat rule pre-pass anchors as scaffolding only; they cannot replace the PDF text.
- Distinguish paper-stated facts from inference.
- Mark missing reviews/replies as missing; do not fabricate reviewer reactions.
- Keep `reusable_anonymous_patterns` anonymous and source-role based.
- Do not paste full paper text into final chat messages; write JSON records to disk.

## Completion Gate

Packaging may continue only after:

```text
analysis/assistant_deep_read_records.jsonl validates with --require-all
analysis/per_paper_analysis_manifest.jsonl has llm_deep_reading.status="complete" for every paper
analysis/per_paper_analysis_manifest.jsonl has deep_read_workflow_alignment="llm-full-paper-deep-read" for every paper
```
