# Contract: Target Report Quality

Generated skills must not answer a target-paper PDF request with a generic extraction summary. The final report must help the author understand why the paper may look incremental, recover a stronger evidence-bounded contribution story, and decide what to revise first.

## Default Report Mode: Plain Advisor Report

By default, use `references/report_playbook/plain_teacher_reporting.md`. The report should feel like a careful advisor explaining the paper to the author:

1. Start with the conclusion in plain Chinese.
2. State the submission context or assumptions: target venue/journal, deadline, page/experiment budget, and risk posture.
3. Explain what the paper is really trying to repair under its constrained regime.
3. Explain why the current framing may look incremental, A+B+C, engineering-only, or old-method-to-new-scenario.
4. Before finalizing the story, account for supplied or verified related work: closest priors, baselines, collision risks, evaluation norms, and frontier analogies.
5. Recover the stronger contribution story, but keep it bounded by target-PDF evidence and verified/supplied related-work evidence.
6. Show the highest-risk claim-evidence-risk checks and the safe/unsafe wording boundary.
7. Tell the author how to rewrite the abstract, introduction, contribution bullets, method overview/Figure, related-work boundary, and experiments.
8. Simulate the most likely reviewer attacks with answerability labels and practical defenses.
9. Explain elegant risk disclosure and scope control.
10. Give a multi-layer L0-L4 revision ladder: wording repair, argument repair, evidence repair, scientific-question elevation, and frontier/boundary expansion.
11. Provide only evidence-bounded English snippets for manuscript or rebuttal use; high-level L3/L4 ideas must be labeled as paper-ready, discussion-ready, proposal-only, or unsafe-now.

12. Include edit-ready patches for the highest-impact manuscript locations, bounded by evidence.
13. If new evidence is needed, identify the minimal decisive experiment and explain what claim it would support.
14. Include a revision-loop note: what to send back next and what will be re-checked.

## Complexity Budget

- Do not force six story routes into the main report unless the user asks for a detailed route board.
- Do not use large comparison matrices by default. Use at most two compact tables when they genuinely make the advice easier to scan.
- Do not include a long anonymous case appendix by default. Mention only the relevant borrowing pattern and the boundary.
- Keep detailed audit material in an optional appendix or separate detailed report only when the user asks for it.

## Required Rigor

- The report must be paper-specific. Name the target regime, broken assumptions, modules, evidence anchors, tables/figures/appendix items, and claim boundaries from the target PDF where available.
- Before major novelty claims, show how the target differs from supplied or verified related work: problem, regime, assumption, method primitive, evidence, baseline fairness, cost, dataset, metric, or scope.
- Do not list modules as the contribution. Explain the interaction, failure mode, interface, or constrained-regime repair that makes the modules necessary together.
- Separate `paper-explicit`, `latent-but-supported`, `story-level reframing`, and `future-boundary hook` claims in plain language.
- For major claims, include safe claim, unsafe overclaim, evidence anchor, reviewer risk, and repair tier.
- Classify likely reviewer questions as answerable, partially answerable, writing-gap, evidence-gap, or outside-scope.
- Audit the paper logic chain: problem, broken assumption, method necessity, evidence, boundary, and claim.
- Disclose residual risks as bounded-scope control rather than self-defeating apology.
- Do not directly reuse popular GitHub research skills; adapt only their useful method patterns through `github_research_skill_benchmark.md`.
- For high-level improvement, explicitly transform solution-level framing into failure mode, broken assumption, scientific question, principle/mechanism, and research-program roadmap.
- When latest-research alignment is requested, use the web-safe dynamic meta-graph: fixed schema, paper-specific nodes, graph-path retrieval seeds, and verified sources only. Do not assume a persistent thread knowledge graph. Label external material as frontier/collision/analogy/evaluation norm, not target evidence.
- Distinguish local manuscript fixes from top-scientist roadmap advice; frontier or boundary-breaking suggestions must name the decisive evidence needed before they can become manuscript claims.
- Do not stop at "missing evidence". Convert each gap into a concrete revision action and a reviewer-defense purpose.
- Include a revision iteration plan so the author knows what to send back and how the next check will update risks.
- Audit figures/tables, baseline fairness, reproducibility, and citation roles when they are central to the paper.
- When evidence is missing, rank the minimal decisive experiment before listing optional experiments.
- Produce edit-ready patches for abstract, contribution bullets, related-work boundary, figure/table captions, experiment narrative, and limitation/discussion when relevant.
- Adapt critique to the target venue/journal rubric when supplied; otherwise use a conservative top-quality bar and label that assumption.
- Account for submission context: target venue/journal, deadline, page budget, experiment budget, and risk posture. If unknown, state conservative assumptions rather than blocking.
- Include manuscript-facing English snippets only where they can be directly used in the paper or rebuttal.
- Use Chinese for diagnosis, reasoning, ranking, risks, anonymous analogies, and revision planning. Use English only for manuscript-facing and rebuttal-ready snippets.
- If the PDF text extraction is weak, say so and degrade the report to a partial audit rather than inventing evidence.
- State the source ledger and evidence boundary clearly. Treat packaged anonymous cases as analogy only, never as target-paper evidence. Apply the literature evidence guard: no invented papers, no unverified “latest work shows”, and no external source without title/year/source/relevance when literature is used.

## Detailed Mode

If the user explicitly asks for a detailed report, complete route comparison, reviewer-defense matrix, or full audit, add the older exhaustive structure:

- six ranked story-route slots, marking unsupported routes when needed;
- route comparison over novelty defense, evidence fit, A+B/C resistance, baseline control, mechanism control, cost/reproducibility, rewrite cost, and new-experiment pressure;
- per-route expansion with evidence anchors, rewrite targets, boundaries, and snippets;
- full reviewer attack table with why-asked, trigger, answerability, defense posture, and no-new-experiment repair;
- submission-context card and target-venue rubric adapter;
- claim-evidence-risk map and logic completeness audit;
- figure/table evidence audit, baseline fairness ledger, citation-role audit, edit-ready patches, and minimal decisive experiment plan;
- simulated review panel with AC synthesis;
- risk disclosure box, L0-L4 revision ladder, solution-to-scientific-question elevation, and frontier/collision bridge when relevant;
- rebuttal pattern library with risky wording to avoid;
- anonymous case appendix with borrowing paths and boundaries.

## Failure Modes To Avoid

- Generic reports that could fit any paper.
- Reports that are complete but exhausting to read.
- Reports that hide the main recommendation behind many tables.
- Story sections that only provide route names or slogans.
- Reviewer attacks without practical manuscript repairs.
- English snippets that overclaim beyond the evidence boundary.
- Trend alignment that merely renames the work with popular terms.
- High-level scientific language that sounds ambitious but has no broken-assumption, failure-mode, or evidence path.
- Frontier roadmap advice that hides whether it is paper-ready, discussion-ready, proposal-only, or unsafe-now.
- External-tool-inspired outputs that ignore this package's target draft types or evidence boundary.
- Advice that is correct but impossible under the deadline or experiment budget.
- Reports that diagnose problems but do not give patch-ready text or a next revision checkpoint.

## v1.1.2 Quality-Aware High-Level Advice

When the report borrows high-level framing from external literature, it must say whether those sources are top-quality anchors, ordinary accepted papers, trend-only items, or unverified search plans.

- L0-L2 manuscript repair can rely mostly on the target paper and packaged patterns.
- L3 scientific-question elevation should prefer field-recognized anchor papers or clearly say the elevation is only a hypothesis.
- L4 frontier/boundary expansion must distinguish top-tier anchor evidence from trend discovery.
- If the reference corpus is not top-quality-gated, write: `这里可以给修改方向，但不能声称已经达到顶会/顶刊视野的完整参照。`

## Related-Work Rigor

- If the user supplied related papers, deep-read them and include a compact relation map.
- If the user supplied no related papers, mine the target paper's references/related work/experiments and use verified retrieval when available; otherwise provide search-plan-only candidates.
- Do not invent external literature. Every external paper must be user-provided, verified in the run, or explicitly marked search-plan-only.
- A professional comparison asks what relationship matters: same task, same failure mode, same assumption gap, same method primitive, direct baseline, evaluation norm, collision risk, or frontier analogy.


## v1.1.6 Execution-Oriented Report Requirements

Target-paper reports should now close the loop from diagnosis to action.

- Start with a short submission-context card. If the user did not provide the context, say the assumptions.
- For the target venue/journal, translate review expectations into concrete pressure points.
- Give the author a small number of safe, edit-ready manuscript patches.
- For evidence gaps, identify the single most decisive experiment first, then optional experiments.
- Treat figures, tables, baselines, resources, reproducibility details, and citations as evidence infrastructure, not decoration.
- End with a revision-loop instruction: “下一版你把改好的 abstract/contribution/related work 或新增实验发回来，我会重新检查 claim 是否还过头、related-work 边界是否清楚、reviewer 问题是否变成可回答。”
