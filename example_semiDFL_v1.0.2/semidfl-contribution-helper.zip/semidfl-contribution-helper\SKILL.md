---
name: semidfl-contribution-helper
description: Self-contained author-side skill for reframing delta-sized or incremental research contributions in federated semi-supervised learning, decentralized federated learning, semi-supervised learning with pseudo-labeling using packaged anonymous base knowledge from 2023, 2024. Use when Codex needs to help package a new paper, diagnose novelty risk, simulate reviewer attacks, draft rebuttal-safe defenses, or evolve the local anonymous casebook from new PDFs without access to the old corpus PDFs.
---

# SemiDFL Contribution Helper

This skill is self-contained. It has two modes:

- Packaged mode: use package-local anonymous base knowledge in `references/`.
- Blank-initializer mode: if packaged base knowledge is missing or the user wants a fresh corpus, use the embedded blank delta engine under `scripts/engine/` and `references/base_delta/`.

It never needs an external `delta-contribution-reframer` skill. It does not require old PDFs or old OpenReview data after packaged mode succeeds.

## Startup

Run `python scripts/startup_check.py --skill-dir <this-skill-dir>` when status is needed. If base resources are non-empty, the skill is usable.

## Supreme Operational Rule: Project Files First

Once PDFs, reviews, replies, metadata, or a corpus run exist in the workspace, treat them as project-internal files and continue from disk. External API, local command, and ACP/acpx backends are automation conveniences, not permission gates. If the current assistant can read the local files, it must continue validation, extraction, chunked deep reading, manifest updates, anonymous synthesis, and packaging as far as the file evidence allows.

Script-level backend gates are not workflow gates. A `not_run` deep-read status caused by missing automation is a handoff to current-assistant local-file processing, not a final blocker.

## Load On Demand

- Package contents and provenance limits: `references/knowledge_manifest.json`
- Evidence labels and no-fabrication rules: `references/evidence_policy.md`
- Update behavior from new PDFs: `references/evolution_policy.md`
- Task workflows: `references/usage_workflows.md`
- Direct analysis from downloaded project corpus files: `references/project_corpus_direct_workflow.md`
- Current-assistant local deep reading when no callback backend is available: `references/assistant_local_deep_read_workflow.md`
- LLM deep-reading workflow for new initialization: `references/llm_deep_reading_workflow.md`
- ACP command-file backend only when API keys/local command backends are unavailable and ACP/acpx exists: `references/acp_command_file_workflow.md`
- Target-paper-guided domain inference: `references/base_delta/workflow_target_domain_inference.md`
- Target-report quality bar: `references/base_delta/contract_target_report_quality.md`
- Reader-friendly report style: `references/report_playbook/reader_friendly_reporting.md`
- Report methodology dependencies: `references/report_playbook/positive_reframing_patterns.md`, `references/report_playbook/latent_contribution_mining.md`, `references/report_playbook/reviewer_attack_taxonomy.md`, `references/report_playbook/rebuttal_pattern_library.md`, and `references/report_playbook/github_review_skill_digest.md`
- Reusable patterns: `references/per_pdf_report_synthesis.md`, `references/llm_deep_read_synthesis.md`, and `references/anonymous_casebook.jsonl`
- Blank initialization workflows/contracts: `references/base_delta/`

## Routing

| User task | Action |
|---|---|
| PDF supplied without purpose | Ask whether to directly analyze the paper or use it as a domain seed for initializing/generating specialized reusable knowledge; do not run tools yet. |
| Directly analyze or reframe a target PDF | Follow `references/base_delta/workflow_target_paper_reframing.md`; use package casebook patterns as analogies only. |
| Simulate reviewer attacks | Mark as `simulated-review` unless real reviews are supplied. |
| Write rebuttal strategy | Ground in user-supplied reviews/replies or label missing sources. |
| Run target-paper report workflow | Run `scripts/analyze_new_pdf.py` as an extraction/pattern pre-pass, then produce the full target-paper report required by `workflow_target_paper_reframing.md`; save the user-facing final report to the script's `public_report` path. |
| Evolve local casebook | Run `scripts/evolve_casebook.py`; write project-local overlay by default. |
| Initialize from a downloaded corpus or project run | Treat the corpus as project files and follow `references/project_corpus_direct_workflow.md`; if no automated callback backend is available and the current assistant can read files, continue through `references/assistant_local_deep_read_workflow.md`. |
| Initialize from scratch or generate specialized reusable knowledge | If the user does not know focus domains, first follow `workflow_target_domain_inference.md` on their target PDF as a domain seed only; then prefer downloaded project files through `references/project_corpus_direct_workflow.md`; use `scripts/engine/standardize_local_pdf_intake.py`, `validate_project_corpus.py`, `analyze_extracted_papers.py`, and `synthesize_initialized_resources.py`; run full-paper LLM deep-reading for every selected reference PDF before synthesis; follow `references/llm_deep_reading_workflow.md` and `references/base_delta/workflow_*`. |

For target-paper analysis, do not stop at the script output. The final report must satisfy `contract_target_report_quality.md`: reader-friendly plain-language explanations, deep evidence base, strong packaging diagnosis, latent contribution mining, top-conference story reconstruction with problem equation/contribution ladder/abstract/intro/contribution/related-work/method/figure outputs, six ranked story-route slots by default with a comparison table and recommended route combination, per-route expansion with examples/analogies, reviewer attack preplay with why-asked/trigger/defense/no-new-experiment repair, manuscript trigger localization, Tier 0 / Tier 1 / Tier 2 revision plan, rebuttal pattern library with risky wording to avoid, anonymous case appendix with borrowing paths, residual safe/unsafe claim boundaries, and English manuscript/rebuttal snippets.

For domain-seed initialization, the target PDF is used only to infer fields/subfields for corpus screening and reusable skill generation. Do not produce a contribution report, story routes, reviewer attacks, rebuttal text, or manuscript edits unless the user explicitly chooses direct target-paper analysis.

For corpus initialization, treat downloaded PDFs and corpus folders as project files. Do not paste full PDF text or a full corpus into chat context; scripts must extract, chunk, save intermediate artifacts, and synthesize from manifests.

In initialization mode, once reference PDFs/reviews/replies are downloaded, provided, or standardized as a `project-run`/`local-pdf`, they are current project-internal files. Missing API keys or LLM backends may block only automated batch execution; they must not block current-assistant local-file validation, extraction, rule pre-pass, per-paper analysis folders, manifests, full-paper deep-read records, and explicit pending/failed LLM status artifacts.

Do not tell the user that a project-internal corpus cannot be analyzed merely because API/acpx/local-command automation is missing. Continue locally or name a concrete non-backend blocker, such as unreadable PDFs, missing files, or exhausted context after saved partial artifacts.

For corpus initialization, do not package initialized knowledge unless every selected PDF has `llm_deep_reading.status=complete` and `deep_read_workflow_alignment="llm-full-paper-deep-read"` in `analysis/per_paper_analysis_manifest.jsonl`. Rule-only analysis is a debug pre-pass, not an acceptable initialized corpus. If the current assistant is doing the reading, use assistant packet preparation, assistant-written JSONL validation, and import rather than treating the rule pre-pass as complete.

Keep hidden `.semidfl-contribution-helper/` paths for evidence artifacts and state. Return user-facing report links using the public report path, formatted with forward slashes as a clickable absolute Markdown file link.

Use Chinese for diagnosis, reasoning, ranking, and risks. Use English only for manuscript-facing snippets.
