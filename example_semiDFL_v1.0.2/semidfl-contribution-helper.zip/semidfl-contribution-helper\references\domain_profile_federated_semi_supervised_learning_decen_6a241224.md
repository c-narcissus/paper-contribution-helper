# Initialized Delta Contribution Domain Profile

- Updated at: 2026-05-21T16:06:52
- Source kind: `iclr-openreview-combined`
- Domain scope: `computer-science`
- Focus domains: `federated semi-supervised learning`, `decentralized federated learning`, `semi-supervised learning with pseudo-labeling`
- Years: `2023`, `2024`
- Paper count: 20
- Evidence coverage: see `.delta-contribution-reframer/state/per_paper_analysis_state.json`; reusable knowledge is stored as anonymous project-local resources.

## Category Counts

| Category | Count |
|---|---:|
| `Other` | 20 |

## Incremental Modes

| Mode | Count |
|---|---:|
| `transfer_or_light_adaptation` | 20 |
| `engineering_or_efficiency` | 19 |
| `evidence_or_benchmark` | 19 |
| `abc_combination` | 14 |
| `low_novelty_or_incremental` | 4 |

## Review Attack Patterns

| Attack | Count |
|---|---:|
| `abc_or_mechanism` | 10 |
| `ablation_evidence` | 10 |
| `baseline_fairness` | 10 |
| `experiment_scope` | 10 |
| `novelty_incrementality` | 10 |
| `reproducibility` | 10 |
| `cost_efficiency` | 9 |

## Reply Move Patterns

| Reply move | Count |
|---|---:|
| `claim_softening_or_clarification` | 10 |
| `existing_evidence_resurfacing` | 10 |
| `setting_boundary_defense` | 10 |
| `new_experiment_or_result` | 9 |

## LLM Deep-Read Coverage

| LLM status | Count |
|---|---:|
| `complete` | 20 |

## Reusable Anonymous Case Labels

| Case label | Examples | Route use | Dominant domains | Common attacks |
|---|---:|---|---|---|
| `delta-sized-accepted-paper-pattern` | 10 | fallback delta-packaging route | `Other` |  |
| `combination-method-needs-mechanism-claim` | 4 | surrogate / coupling / interface route | `Other` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `incremental-gain-with-ablation-pressure` | 4 | failure-mode / mechanism-evidence route | `Other` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `light-transfer-with-scope-generalization-risk` | 2 | scope-boundary / transfer route | `Other` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `baseline-contract-fairness-defense` | 10 | baseline-contract route | `Other` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `evidence-system-coverage-defense` | 10 | evidence-system route | `Other` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `efficiency-system-claim-under-cost-scrutiny` | 19 | quality-cost / deployment-boundary route | `Other` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `scope-generalization-boundary-defense` | 10 | scope-boundary route | `Other` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |

## Evidence Rules

All reusable cases are anonymous aggregates. Use `simulated-review` only when applying these patterns to a new target paper without real reviews.
