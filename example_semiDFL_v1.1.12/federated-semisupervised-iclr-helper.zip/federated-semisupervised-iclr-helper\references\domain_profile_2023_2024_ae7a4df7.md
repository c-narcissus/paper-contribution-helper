# Initialized Delta Contribution Domain Profile

- Updated at: 2026-06-15T23:04:48
- Source kind: `iclr-openreview`
- Domain scope: `computer-science`
- Focus domains: `联邦学习`, `半监督学习`
- Years: `2023`, `2024`
- Paper count: 20
- Evidence coverage: see `.delta-contribution-reframer/state/per_paper_analysis_state.json`; reusable knowledge is stored as anonymous project-local resources.

## Category Counts

| Category | Count |
|---|---:|
| `联邦学习` | 13 |
| `半监督学习` | 11 |

## Incremental Modes

| Mode | Count |
|---|---:|
| `evidence_or_benchmark` | 20 |
| `transfer_or_light_adaptation` | 20 |
| `engineering_or_efficiency` | 19 |
| `abc_combination` | 15 |
| `low_novelty_or_incremental` | 4 |

## Review Attack Patterns

| Attack | Count |
|---|---:|
| `abc_or_mechanism` | 10 |
| `ablation_evidence` | 10 |
| `baseline_fairness` | 10 |
| `experiment_scope` | 10 |
| `novelty_incrementality` | 10 |
| `reproducibility` | 10 |
| `cost_efficiency` | 9 |

## Reply Move Patterns

| Reply move | Count |
|---|---:|
| `claim_softening_or_clarification` | 10 |
| `existing_evidence_resurfacing` | 10 |
| `setting_boundary_defense` | 10 |
| `new_experiment_or_result` | 9 |

## LLM Deep-Read Coverage

| LLM status | Count |
|---|---:|
| `complete` | 20 |

## Reusable Anonymous Case Labels

| Case label | Examples | Route use | Dominant domains | Common attacks |
|---|---:|---|---|---|
| `delta-sized-accepted-paper-pattern` | 10 | fallback delta-packaging route | `半监督学习`, `联邦学习` |  |
| `combination-method-needs-mechanism-claim` | 5 | surrogate / coupling / interface route | `半监督学习`, `联邦学习` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `incremental-gain-with-ablation-pressure` | 4 | failure-mode / mechanism-evidence route | `联邦学习`, `半监督学习` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `light-transfer-with-scope-generalization-risk` | 1 | scope-boundary / transfer route | `联邦学习` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `baseline-contract-fairness-defense` | 10 | baseline-contract route | `联邦学习`, `半监督学习` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `evidence-system-coverage-defense` | 10 | evidence-system route | `联邦学习`, `半监督学习` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `efficiency-system-claim-under-cost-scrutiny` | 19 | quality-cost / deployment-boundary route | `联邦学习`, `半监督学习` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |
| `scope-generalization-boundary-defense` | 10 | scope-boundary route | `联邦学习`, `半监督学习` | `novelty_incrementality`, `abc_or_mechanism`, `baseline_fairness` |

## Evidence Rules

All reusable cases are anonymous aggregates. Use `simulated-review` only when applying these patterns to a new target paper without real reviews.
