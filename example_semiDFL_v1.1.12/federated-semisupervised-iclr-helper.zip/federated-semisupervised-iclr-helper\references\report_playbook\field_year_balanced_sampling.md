# Field-Year Balanced Corpus Sampling

Use this playbook when building or updating a child skill from multiple research fields and multiple years.

## Goal

A reusable child skill should not be biased toward one year or one subfield just because those papers are easier to find. When the user gives multiple fields and multiple years, build a balanced `field × year` sampling plan.

## Default OR semantics

Multiple fields, years, sources, and local-material entries are OR candidate pools by default. The sampling plan should cover them as separate quota cells or source pools. Do not interpret them as an intersection unless the user explicitly asks for AND/交集/必须同时满足.

## Required quota plan

Create a table before discovery:

| Field | Year | Target count | Verified count | Status |
|---|---:|---:|---:|---|
| field A | 2023 | 5 | 0 | pending |
| field A | 2024 | 5 | 0 | pending |
| field B | 2023 | 5 | 0 | pending |
| field B | 2024 | 5 | 0 | pending |

## Rules

- If the user says `每年10篇` and gives one field, treat it as 10 papers per year.
- If the user says `每年10篇` and gives multiple fields, ask whether this means 10 total per year or 10 per field per year.
- If the user says `每领域每年5篇`, fill each field-year cell with 5 papers when verified sources exist.
- If a cell cannot be filled, do not fabricate papers or silently replace the field. Mark it as `quota_gap` and explain the reason.
- Adjacent-year borrowing is allowed only when explicitly labeled, e.g. `2023 cell supplemented with 2022/2024 papers because no verified 2023 papers were available`.
- Source-quality screening still happens after candidate collection; quota pressure never overrides evidence quality or verification.

## Output

Report both the intended quota and the actual verified corpus. A child skill is `production-ready` only when quota gaps are explained and the user accepts the final corpus coverage.
