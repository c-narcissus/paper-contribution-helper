# Scientific Boundary Breakthrough Roadmap

Use this playbook for high-level advice. It asks whether a draft can move from local improvement to boundary-touching research, and what must be added before making that claim.

## Boundary Types

A paper may touch a scientific boundary if it challenges or relaxes one of these:

| Boundary | Question |
|---|---|
| information boundary | What signal is unavailable, hidden, private, noisy, or too expensive? |
| generalization boundary | Where do current methods fail outside the training/evaluation regime? |
| scale boundary | What breaks when data, agents, models, labels, or compute scale? |
| trust boundary | How can we know a prediction/model/system is reliable without the usual validation signal? |
| evaluation boundary | What does the field currently fail to measure? |
| mechanism boundary | What causal/mechanistic explanation is missing? |
| theory-practice boundary | What practical result lacks a formal or conceptual explanation? |
| domain-transfer boundary | What principle transfers across domains despite surface differences? |

## Roadmap Shape

For each promising boundary, produce:

1. **Observed local result**: what the current paper actually shows.
2. **Boundary touched**: what general limit it hints at.
3. **Scientific hypothesis**: a falsifiable statement.
4. **Minimum decisive experiment**: the smallest study that would support or falsify the hypothesis.
5. **Top-tier version**: what the paper would look like if the hypothesis were validated.
6. **Current manuscript version**: what can be safely claimed now.

## Top Scientist Lens

A top-level advisor should ask:

- What would still be interesting if the method name changed?
- What assumption did the field not realize it was making?
- What result would surprise a skeptical expert?
- What is the smallest decisive experiment that separates this idea from engineering luck?
- What adjacent field has already faced the same boundary?
- What is the negative result that would honestly limit the claim?

## Safety Rule

Boundary language is powerful but dangerous. Unless broad evidence exists, write boundary insights as motivation, discussion, or future research program, not as final achieved contribution.
