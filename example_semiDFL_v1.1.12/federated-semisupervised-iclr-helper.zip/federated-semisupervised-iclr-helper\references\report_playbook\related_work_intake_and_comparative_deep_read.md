# Related-Work Intake and Comparative Deep Read

Use this playbook after the startup menu when the user selects direct paper analysis, L0-L4 revision, high-level scientific elevation, reviewer defense, or dynamic meta-graph search for a target paper.

## Why This Gate Exists

A target paper cannot be judged well in isolation. For A+B+C, incremental, engineering, transfer, and old-method-new-setting papers, the main risk is often not inside the paper itself. The real question is: compared with the closest papers, what is actually new, necessary, and defensible?

Write like an advisor: "我先不急着下结论。你这篇文章最怕被 reviewer 拿来对比的是哪几篇？如果你有 PDF 或链接，先给我。没有也可以，我会从你论文里的 related work、references、实验 baseline 和前沿表述里主动抽线索。"

## Intake Question

Before the final analysis, ask one compact question unless the user already answered it:

```text
在我正式分析前，先确认一件事：你有没有想让我一起看的相关工作论文、最接近 baseline、竞品方法、reviewer 可能会提到的论文，或者已经收到的 review/rebuttal 材料？

有的话请上传 PDF、贴标题/链接，或者说“重点对比 A/B/C”。
没有的话直接回复“没有，按论文里的 related work 和 references 主动找”。我会先从目标论文的 related work、references、实验 baseline、frontier/limitation 表述里抽候选，再做可验证检索；没检索到的只标 search-plan，不编文献。
```

If the user explicitly asks to skip this gate, proceed, but add a source-boundary note saying no user-supplied related work was used.

## If The User Provides Related Papers

1. Build a source ledger for every supplied item: target paper, related paper, link, review, reply, baseline description, code/repository, benchmark, or venue page.
2. For PDFs, run the same deep-read discipline as the target paper. Use `llm_deep_reading_workflow.md` or `assistant_local_deep_read_workflow.md` when local project files are available.
3. Read at least the abstract, introduction, method, experiments, limitations, and contribution claims of each supplied paper before making a comparison.
4. Assign each supplied work a relation role:
   - `closest-prior`: same problem/regime and similar method or claim.
   - `baseline-method`: method compared experimentally or should be compared.
   - `same-problem-different-assumption`: same goal but relies on signals/resources unavailable to the target paper.
   - `same-method-different-setting`: similar primitive but used under a different regime.
   - `evaluation-norm`: defines benchmark, metric, stress test, or cost protocol.
   - `frontier-analogy`: useful high-level idea, not direct evidence.
   - `collision-risk`: could weaken novelty unless boundary is clarified.
   - `negative-risk`: shows a weak framing pattern to avoid.
5. Ask informed relation questions only when needed. Do not ask generic questions that the papers already answer.

## Professional Relation Questions

The skill should behave like a professional who knows what relationships matter. Ask questions like:

- "这篇最接近工作和你的方法，是同一个 failure mode，还是只是同一个 task？"
- "你想主张的是比它效果更好，还是在它不能用的约束下仍然能工作？"
- "它需要的 supervision / data access / validation signal / compute / annotation，你这里是不是没有？"
- "实验里你有没有和它做同预算、同数据、同 setting 的比较？如果没有，原因能不能合理解释？"
- "你的模块 A/B/C 哪一个是在修它没解决的 assumption gap？"
- "这篇论文如果被 reviewer 提出来，你希望 related work 里怎么一句话划边界？"

Keep the questions few and useful. If the relationship is already clear from the papers, answer it directly instead of asking.

## If The User Does Not Provide Related Papers

1. Read the target paper's related work, references, experiments, baselines, claims of novelty, limitations, and future-work/frontier language.
2. Build a dynamic meta-graph with nodes such as problem, regime, failure mode, broken assumption, method primitive, baseline, metric, dataset, closest prior, and frontier topic.
3. Generate candidate retrieval paths:
   - target claim -> closest prior in references -> cited-by or recent follow-up;
   - baseline in experiment -> official paper/benchmark -> evaluation norm;
   - failure mode -> adjacent domain with same failure -> borrowable mechanism or stress test;
   - method primitive -> recent arXiv/OpenReview/publisher records -> collision risk;
   - dataset/metric -> benchmark page or leaderboard -> fair comparison requirements.
4. Use visible retrieval sources when available: arXiv, OpenReview, official conference/journal pages, publisher pages, Semantic Scholar/OpenAlex-style records, Papers with Code/benchmark pages, or user-approved search results.
5. If retrieval is unavailable, output a search-plan-only table. Do not invent paper titles, years, venues, or results from memory.

## Comparative Output Required

The final report should include a compact related-work section:

| Related work role | What it challenges | Difference to target paper | Evidence status | Revision action |
|---|---|---|---|---|
| closest-prior / baseline / evaluation-norm / collision-risk | novelty, mechanism, baseline, scope, cost, or evaluation | same/different problem, setting, assumption, method, or evidence | supplied PDF, verified external, target reference, or search-plan-only | rewrite boundary, add experiment, downgrade claim, or cite as future work |

Then connect it to L0-L4 revision:

- L0: where to mention or cite the related work.
- L1: how to rewrite the problem and related-work boundary.
- L2: which baseline, ablation, cost, robustness, or stress test is needed.
- L3: what broken assumption/scientific question emerges from the comparison.
- L4: which frontier path is real, which is only proposal-level, and which would require new evidence.

## Anti-Hallucination Boundary

Never say "this paper does X" unless the paper was supplied, retrieved, or visible in the current run. Use `literature_evidence_guard.md` and `source_quality_gate.md` together:

- verified source = it exists and says X;
- quality role = how much it is allowed to influence the report;
- target-paper evidence = what supports the author's own claims;
- search-plan-only = useful next step, not evidence.

Packaged anonymous cases may inspire a question, but they cannot prove that a specific external paper exists or that the target paper beats it.
