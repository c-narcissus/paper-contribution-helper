# Figure and Table Evidence Audit

Use this playbook when the paper includes method diagrams, result tables, ablations, case studies, or appendix evidence.

## Main Idea

很多论文不是没实验，而是图表没有帮作者讲贡献。Every figure/table should answer a reviewer doubt.

## Audit Questions

For each important figure/table:

- What claim does it support?
- Which reviewer doubt does it answer?
- Is it main evidence, diagnostic evidence, or illustration only?
- Is the caption explaining the failure mode or only describing components?
- Is key evidence hidden in appendix but needed in the main text?
- Does the table mix unfair budgets, data, or settings?

## Output Format

| Figure/Table | Current role | Reviewer reading risk | Better narrative | Revision action |
|---|---|---|---|---|
| Fig. 1 method | pipeline diagram | looks like A+B+C | show missing interface/failure mode | redraw/caption |
| Table 2 main results | accuracy | unclear why setting matters | emphasize constrained regime | paragraph rewrite |

## Caption Repair

Method figure captions should say what failure mode the design repairs, not only name modules.

Experiment captions should say what question the table answers: baseline fairness, robustness, mechanism, cost, or scope.
