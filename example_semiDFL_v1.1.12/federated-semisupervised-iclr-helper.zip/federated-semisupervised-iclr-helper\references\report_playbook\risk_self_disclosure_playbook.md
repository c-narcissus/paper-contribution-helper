# Risk Self-Disclosure Playbook

Use this playbook to help authors disclose weaknesses elegantly without weakening the paper unnecessarily.

## Principle

Do not confess weakness as apology. Convert risk into a bounded setting, controlled claim, or explicit tradeoff.

Bad pattern:

```text
Our method is simple and may not generalize.
```

Better pattern:

```text
We focus on the bounded regime where [constraint] makes [old assumption] unavailable. Our goal is not to claim universal generalization, but to show that [specific repair] is effective under this controlled setting.
```

## Disclosure Table

| Risk | Where to disclose | Safe framing | Dangerous wording |
|---|---|---|---|
| Novelty primitives are known | Introduction / related work | The primitives are known, but the paper contributes a constrained-regime coupling or interface repair | The method is simple / only combines existing methods |
| Limited scope | Introduction / limitation | The bounded setting isolates the missing assumption and makes the evidence interpretable | The work only works for one setting |
| Mechanism evidence is indirect | Experiment narration / limitation | Ablations support the proposed mechanism and identify failure-mode sensitivity | Ablations prove the mechanism |
| Baseline fairness risk | Experiment setup | We separate same-resource comparisons from diagnostic extra-resource comparisons | Some baselines are unfair |
| Cost overhead | Experiment / limitation | We report the gain-cost tradeoff and identify when the added cost is justified | The cost is negligible without logs |
| Generalization | Limitation / conclusion | The results support the evaluated regime; broader deployment requires additional validation | The method is generally applicable |
| Reproducibility | Implementation / appendix | We provide the protocol/configuration details needed to reproduce the reported setting | The work is fully reproducible without artifacts |

## Risk Disclosure Box

For each major risk, generate:

1. What to disclose.
2. Where to disclose.
3. Safe wording.
4. Dangerous wording to avoid.
5. Whether the risk needs a new experiment or only a claim boundary.

## Final Report Rule

Risk disclosure should appear before the reviewer weaponizes the issue. Put the bounded version in the manuscript, not only in rebuttal.
