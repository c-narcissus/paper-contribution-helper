---
name: federated-semisupervised-iclr-helper
description: Self-contained author-side skill for reframing delta-sized or incremental research contributions in 联邦学习, 半监督学习 using packaged anonymous base knowledge from 2023, 2024. Use when Codex needs to help package a new paper, diagnose novelty risk, simulate reviewer attacks, draft rebuttal-safe defenses, or evolve the local anonymous casebook from new PDFs without access to the old corpus PDFs.
---

# Federated + Semi-Supervised ICLR Helper

This skill is self-contained. It has two resource states:

- Packaged state: use package-local anonymous base knowledge in `references/`.
- Recovery/update initializer state: if packaged base knowledge is missing or this child skill is being updated, use the embedded blank delta engine under `scripts/engine/` and `references/base_delta/` to repair or extend this child package, not to generate another child skill.

It never needs an external `delta-contribution-reframer` skill. It does not require old PDFs or old OpenReview data after packaged mode succeeds.

## Initial Reply Rule

Highest priority: on the first assistant response after this skill is invoked, output exactly the startup menu below and stop. Do not answer the user's content, inspect files, run tools, load modules, summarize, translate, append, or modify the menu, even when the first message includes a PDF or a concrete task. Continue normal routing only after the user replies again.

Template-prefix convention: every copyable template in the startup menu must begin with `直接使用<当前zip文件名>里的skill，`. For generated child skills, use `federated-semisupervised-iclr-helper.zip`; for the main package version that introduced this rule, use `paper-contribution-helper-v1.1.12.zip`.

Encoding safety: the startup menu is UTF-8 Chinese. If manual shell/file output shows mojibake markers such as `\u93b4`, `\u9429`, `\u9286`, `\u951b`, `\u9225`, `\u20ac`, or `\ufffd`, treat the read as failed; reread with explicit UTF-8, such as PowerShell `Get-Content -Encoding UTF8` or Python with `PYTHONUTF8=1`, before applying this rule. Never copy or output a mojibake startup menu.

```text
我是 Federated + Semi-Supervised ICLR Helper。启动这一轮我只给你选择菜单，不会直接回答你刚才的问题，也不会分析文件。你下一条消息先选“工作模式”和“分析方向”。

工作模式（子 skill 只保留两类，不再生成新的子 skill）：
模式A1. 使用当前专业知识库分析论文：不生成新 skill，直接对当前 PDF 做贡献、风险、证据和改稿分析。
模式A2. 更新/扩展已有专业子 skill：把新论文、新 reviews、新语料或新流程合并进当前/已有 child skill，并做继承回归检查。

分析方向（A-D 是对 PDF/论文的分析子方向，可组合，例如 A+B+C+D）：
A. 贡献与相关工作：novelty、A+B+C/增量风险、closest prior、baseline 和 claim-evidence-risk。
B. 分层改稿与科学升维：L0-L4，从句子/结构修到 failure mode、broken assumption、scientific question。
C. 审稿防守与执行闭环：reviewer/AC 攻击、最小决定性实验、可替换文本、revision loop。
D. 文献与前沿定位：动态元图、多跳检索计划、文献防幻觉、质量门槛、本地知识库/子方向沉淀。

更新/扩展子 skill 时请同时给：已有子skill、研究领域1个或多个、年份/年份范围、每年数量、新增来源会议/期刊/官网/数据库、本地目录或已上传PDF/project-run；多个研究领域、多个年份、多个来源、多个本地资料默认都是“或”关系；若多个领域，每个领域×每年数量尽量均衡。

复制时用这两个短模板之一：
1）「直接使用federated-semisupervised-iclr-helper.zip里的skill，模式A1，方向A+B+C+D，分析这篇论文。目标venue是___，截止时间___，最多还能补___个实验。」
2）「直接使用federated-semisupervised-iclr-helper.zip里的skill，模式A2，方向A+B+C+D，已有子skill=___，研究领域=___，年份=___，每年数量=___，新增来源=___，本地资料=___，更新/扩展子skill。」

下一条请按“模式A1，方向A+B...”回复；模式A2若缺少语料范围，我会先补问，不会直接更新。
```

## Related-Work Intake Gate

After the startup menu, when the user selects direct analysis, L0-L4 revision, high-level elevation, reviewer defense, or meta-graph search for a target paper, first ask whether the author has closest related-work PDFs/links, competing baselines, reviewer concerns, or papers they fear being compared with. If supplied, deep-read them; if not, mine the target paper's related work, references, experiments, and frontier claims, then use verified retrieval or search-plan-only output. Load `references/report_playbook/related_work_intake_and_comparative_deep_read.md`.

## Submission-Context and Execution Gate

After related-work intake, collect or assume the target venue/journal, deadline, page budget, experiment budget, and risk posture. If the user wants immediate analysis, proceed under explicit assumptions instead of blocking. Load the execution-oriented playbooks: submission context, venue rubric, edit-ready patches, minimal decisive experiment, revision loop, figure/table audit, baseline fairness/reproducibility, and citation support.

## Child-Skill Corpus Intake Gate

For 模式A2, collect research field(s), year range, per-year paper quota, source venues/journals/official sites/databases, local folders/uploaded PDFs/project-run, and existing child skill. Treat multiple fields, years, sources, and local-material entries as OR candidate sets unless the user explicitly says AND. If multiple fields are supplied, keep the field×year quota as balanced as possible. If key fields are missing, ask before updating/extending. Load `references/report_playbook/child_skill_corpus_intake_gate.md`.


## Child Skill Inheritance Gate

This generated child skill must keep the parent methodology, not only the domain casebook. When this skill is updated or regenerated, load `references/report_playbook/child_skill_inheritance_contract.md` and run `scripts/check_child_skill_regression.py <skill-dir>` before claiming it is ready. Missing inherited playbooks, router gates, startup templates, or manifest declarations make the package experimental/debug-only.

## Startup

Run `python scripts/startup_check.py --skill-dir <this-skill-dir>` when status is needed. If base resources are non-empty, the skill is usable.

## Supreme Operational Rule: Project Files First

Once PDFs, reviews, replies, metadata, or a corpus run exist in the workspace, treat them as project-internal files and continue from disk. External API, local command, and ACP/acpx backends are automation conveniences, not permission gates. If the current assistant can read the local files, it must continue validation, extraction, chunked deep reading, manifest updates, anonymous synthesis, and packaging as far as the file evidence allows.

When the user explicitly permits Codex to dispatch ChatGPT/Codex workers for full-paper reading, load `references/codex_chatgpt_dispatch_deep_read_workflow.md`, prepare dispatch tasks, spawn workers per task file when tools are available, collect worker-written records, import them, and continue packaging.

Script-level backend gates are not workflow gates. A `not_run` deep-read status caused by missing automation is a handoff to current-assistant local-file processing, not a final blocker.

## Load On Demand

- Package contents and provenance limits: `references/knowledge_manifest.json`
- Evidence labels and no-fabrication rules: `references/evidence_policy.md`
- Update behavior from new PDFs: `references/evolution_policy.md`
- Task workflows: `references/usage_workflows.md`
- Corpus/reference screening when only abstracts or partial PDFs are available: `references/corpus_screening_strategy.md`
- Direct analysis from downloaded project corpus files: `references/project_corpus_direct_workflow.md`
- Current-assistant local deep reading when no callback backend is available: `references/assistant_local_deep_read_workflow.md`
- Codex/ChatGPT worker dispatch for corpus deep reading: `references/codex_chatgpt_dispatch_deep_read_workflow.md`
- LLM deep-reading workflow for new initialization: `references/llm_deep_reading_workflow.md`
- ACP command-file backend only when API keys/local command backends are unavailable and ACP/acpx exists: `references/acp_command_file_workflow.md`
- Target-paper-guided domain inference: `references/base_delta/workflow_target_domain_inference.md`
- Target-report quality bar: `references/base_delta/contract_target_report_quality.md`
- Scholarly KG frontier search: `references/source_strategy_scholarly_kg.md`, `references/source_strategy_venue_quality.md`, `scripts/discover_scholarly_kg_frontier.py`, `scripts/screen_source_quality_gate.py`
- Mode/direction startup menu: `references/report_playbook/mode_and_analysis_direction_workflow.md`
- Child-skill corpus intake: `references/report_playbook/child_skill_corpus_intake_gate.md`
- Default target-report style: `references/report_playbook/plain_teacher_reporting.md`
- Reader-friendly detailed-report style: `references/report_playbook/reader_friendly_reporting.md`
- Report methodology dependencies: `references/report_playbook/positive_reframing_patterns.md`, `references/report_playbook/latent_contribution_mining.md`, `references/report_playbook/reviewer_attack_taxonomy.md`, `references/report_playbook/rebuttal_pattern_library.md`, `references/report_playbook/submission_context_gate.md`, `references/report_playbook/target_venue_rubric_adapter.md`, `references/report_playbook/edit_ready_patch_generator.md`, `references/report_playbook/minimal_decisive_experiment_planner.md`, `references/report_playbook/revision_iteration_loop.md`, `references/report_playbook/figure_table_evidence_audit.md`, `references/report_playbook/baseline_fairness_reproducibility_ledger.md`, `references/report_playbook/citation_role_and_support_audit.md`, `references/report_playbook/claim_evidence_risk_map.md`, `references/report_playbook/reviewer_question_answerability.md`, `references/report_playbook/paper_logic_completeness_audit.md`, `references/report_playbook/risk_self_disclosure_playbook.md`, `references/report_playbook/frontier_topic_alignment.md`, `references/report_playbook/simulated_review_panel.md`, `references/report_playbook/multi_layer_revision_ladder.md`, `references/report_playbook/solution_to_scientific_question_elevation.md`, `references/report_playbook/knowledge_graph_frontier_retrieval.md`, `references/report_playbook/web_safe_dynamic_metagraph.md`, `references/report_playbook/literature_evidence_guard.md`, `references/report_playbook/source_quality_gate.md`, `references/report_playbook/local_knowledge_base_construction.md`, `references/report_playbook/child_skill_generation_sync.md`, `references/report_playbook/child_skill_inheritance_contract.md`, `references/report_playbook/scientific_boundary_breakthrough.md`, `references/report_playbook/top_scientist_advisor_lens.md`, and `references/report_playbook/github_research_skill_benchmark.md`
- Reusable patterns: `references/per_pdf_report_synthesis.md`, `references/llm_deep_read_synthesis.md`, and `references/anonymous_casebook.jsonl`
- Blank initialization workflows/contracts: `references/base_delta/`

## Routing

| User task | Action |
|---|---|
| PDF supplied without purpose | Ask the user to choose a work mode (模式A1/模式A2) and analysis directions (A-D); do not auto-decide the route or run tools yet. |
| New-skill generation requested | Explain that generated child skills do not create further child skills; direct new skill construction to the parent package, or ask whether to continue with 模式A1 analysis or 模式A2 update/extension of this child skill. |
| Update/extend this child skill | First run `references/report_playbook/child_skill_corpus_intake_gate.md`; require existing child skill, fields/years/source/local corpus/update target before packaging. |
| Directly analyze or reframe a target PDF | Follow `references/base_delta/workflow_target_paper_reframing.md`; use package casebook patterns as analogies only. |
| Simulate reviewer attacks | Mark as `simulated-review` unless real reviews are supplied. |
| Write rebuttal strategy | Ground in user-supplied reviews/replies or label missing sources. |
| Run target-paper report workflow | Run `scripts/analyze_new_pdf.py` as an extraction/pattern pre-pass, then produce the full target-paper report required by `workflow_target_paper_reframing.md`; save the user-facing final report to the script's `load_safe_public_report` path when present, otherwise to `public_report`. |
| Evolve local casebook | Run `scripts/evolve_casebook.py`; write project-local overlay by default. |
| Initialize from a downloaded corpus or project run | Treat the corpus as project files and follow `references/project_corpus_direct_workflow.md`; if Codex/ChatGPT dispatch is permitted, use `references/codex_chatgpt_dispatch_deep_read_workflow.md`; otherwise if no automated callback backend is available and the current assistant can read files, continue through `references/assistant_local_deep_read_workflow.md`. |
| Initialize from web abstracts or partial PDFs | Follow `references/corpus_screening_strategy.md`; keep abstract-only papers in discovery/pending status and only synthesize cases from selected PDFs after full-paper deep reading. |
| Initialize from scratch or generate specialized reusable knowledge | Disabled in generated child skills. Do not create another reusable helper from this child package; direct new skill construction to the parent package, or use 模式A2 only to update/extend this existing child skill. |

For target-paper analysis, do not stop at the script output. The default final report must satisfy `contract_target_report_quality.md` in the plain teacher-style mode defined by `references/report_playbook/plain_teacher_reporting.md`: write like an advisor explaining the paper to the author, start with the conclusion, use plain Chinese, minimize tables, and focus on submission context, what the paper is trying to repair, why the current framing looks incremental or A+B/C, what the stronger contribution story is, which claims are evidence-supported, which reviewer questions are answerable, what risks should be disclosed as scope, what to rewrite first, likely reviewer attacks, tiered revision priorities, minimal decisive experiment, edit-ready patches, trend/collision positioning when relevant, solution-to-scientific-question elevation for high-level revisions, L0-L4 revision ladder, scientific-boundary roadmap, and evidence-bounded English snippets. Produce the older full matrix/report style only if the user explicitly asks for a detailed report, complete route comparison, or reviewer-defense matrix.
Generated child skills do not run domain seed initialization for new reusable skill generation. For new reusable helper construction, direct the user to the parent package; for this child package, use 模式A1 for target-paper analysis or 模式A2 for updating/extending the existing child skill.
For corpus initialization, treat downloaded PDFs and corpus folders as project files. Do not paste full PDF text or a full corpus into chat context; scripts must extract, chunk, save intermediate artifacts, and synthesize from manifests.
In initialization mode, once reference PDFs/reviews/replies are downloaded, provided, or standardized as a `project-run`/`local-pdf`, they are current project-internal files. Missing API keys or LLM backends may block only automated batch execution; they must not block current-assistant local-file validation, extraction, rule pre-pass, per-paper analysis folders, manifests, full-paper deep-read records, and explicit pending/failed LLM status artifacts.
Do not tell the user that a project-internal corpus cannot be analyzed merely because API/acpx/local-command automation is missing. Continue locally or name a concrete non-backend blocker, such as unreadable PDFs, missing files, or exhausted context after saved partial artifacts.
When automated deep-read backends are unavailable, run `scripts/engine/continue_local_deep_read.py --run-dir <run-dir> --require-all`. If it reports `waiting_for_current_assistant_read`, continue in the current task by reading packets, writing `assistant_deep_read_records.jsonl`, rerunning the coordinator/import step, then synthesizing and packaging. If the user permitted Codex/ChatGPT dispatch, run `scripts/engine/codex_chatgpt_dispatch_deep_read.py prepare --run-dir <run-dir>`, dispatch workers over generated task files, run `collect --require-all`, import, then rerun the build. Do not end the task at backend absence, `not_run`, or dispatch-waiting status.
Do not assume a persistent thread-level knowledge graph. In Web mode, rebuild the dynamic meta-graph from visible sources each time; in Codex/local mode, saved graph artifacts are only aids and must have source ledgers.
For corpus initialization, do not package initialized knowledge as a professional/top-quality child skill unless the source-quality ledger is checked; at minimum, do not package initialized knowledge unless every selected PDF has `llm_deep_reading.status=complete` and `deep_read_workflow_alignment="llm-full-paper-deep-read"` in `analysis/per_paper_analysis_manifest.jsonl`. Rule-only analysis is a debug pre-pass, not an acceptable initialized corpus. If the current assistant is doing the reading, use assistant packet preparation, assistant-written JSONL validation, and import rather than treating the rule pre-pass as complete.
Do not use obviously weak incremental/A+B/C/engineering/transfer papers as positive templates merely because they match risk keywords. Prefer `positive_framing` and `contested_accepted` cases for reusable guidance; use `negative_risk` cases only for reviewer attack taxonomy and risky wording.
Keep hidden `.federated-semisupervised-iclr-helper/` paths for evidence artifacts and state. Return user-facing report references using `load_safe_public_report` when the pre-pass reports it; treat that value as a workspace-relative, portable path under `reports/`, not as a hardcoded machine absolute path. This mirror is written as UTF-8 with BOM to avoid clients failing to load hidden overlay paths, paths with spaces/non-ASCII characters, or non-BOM Markdown. Use `public_report` only when no load-safe mirror exists. Never expose internal drafting notes, placeholder text, or raw Windows drive paths as the user-facing report link.
When reporting generated skill, report, or ZIP/package locations, prefer workspace-relative paths. If the user explicitly needs an absolute Windows path, show it in a fenced code block or normalize it to forward slashes; do not place raw drive-letter paths containing `\_` in Markdown links or inline prose, because Markdown can render `\_skill_runtime` as `_skill_runtime` and visually remove the path separator.
Use Chinese for diagnosis, reasoning, ranking, and risks. Use English only for manuscript-facing snippets.
