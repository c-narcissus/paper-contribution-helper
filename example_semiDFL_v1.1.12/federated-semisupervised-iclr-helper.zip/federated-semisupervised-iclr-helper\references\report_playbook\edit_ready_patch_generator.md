# Edit-Ready Patch Generator

Use this playbook to convert diagnosis into text the author can actually paste into a manuscript or rebuttal.

## Main Idea

很多学生看完建议会点头，但不知道怎么改稿。So the report must include a small number of evidence-bounded rewrite patches.

## Patch Types

Generate only patches that are safe under the evidence boundary:

1. abstract thesis sentence;
2. introduction problem/framing paragraph;
3. contribution bullets;
4. related-work boundary sentence;
5. method overview / figure caption language;
6. experiment narrative sentence;
7. limitation or discussion sentence;
8. rebuttal-ready answer when reviews are provided.

## Safe / Strong / Unsafe

For each major patch, separate:

- `safe version`: supported by current evidence;
- `stronger version`: only if the target paper plus supplied/verified sources support it;
- `unsafe version`: do not write unless new evidence is added.

## Format

Use concise blocks:

```text
【可直接替换：Contribution bullet】
We identify ... and show that ... under ...

【为什么这样写】
这句话把贡献从“加了模块”改成“修复了某个 failure mode”，但没有声称解决所有 setting。
```

Do not produce many alternatives by default. Give the best one first, then one backup if useful.

## Evidence Boundary

Never let a patch overclaim beyond the claim-evidence-risk map. If a nice sentence sounds good but lacks evidence, label it as `discussion-only` or `unsafe-now`.
