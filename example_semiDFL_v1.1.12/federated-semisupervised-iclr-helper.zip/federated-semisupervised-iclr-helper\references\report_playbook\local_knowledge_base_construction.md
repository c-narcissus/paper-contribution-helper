# Local Knowledge Base Construction

Use this playbook when building, initializing, or explaining the local reusable knowledge base.

## Plain Explanation

本地知识库不是把论文 PDF 塞进 skill 里，也不是让模型背文献。它应该沉淀的是：

- 哪些论文容易被打成增量 / A+B+C / 工程优化；
- reviewer 是怎么打的；
- 作者怎样把贡献讲清楚；
- 哪些 claim 有证据，哪些 claim 过头；
- 哪些实验、消融、baseline、scope control 真正起作用；
- 哪些 pattern 可以匿名复用到新论文。

## Corpus Roles

Split sources by purpose:

| Corpus role | Purpose | Reusable? |
|---|---|---|
| `defense_corpus` | mature papers + reviews/replies; learn how to defend delta contributions | yes, after full read and anonymization |
| `negative_risk_corpus` | papers/reviews where novelty or A+B/C failed | yes, as warning patterns |
| `collision_corpus` | most recent close papers | no as casebook; used for current novelty boundary |
| `frontier_corpus` | adjacent hot topics and new ideas | no as target evidence; used for L4 roadmap |
| `evaluation_corpus` | benchmark/SOTA/protocol pages | yes as evaluation norm, not contribution proof |

## Required Per-Paper Record

A reference paper can enter the reusable KB only after a full-paper record exists with:

- `source_ledger`;
- `evidence_boundary`;
- `target_regime_summary`;
- `broken_assumptions_or_failure_modes`;
- `surface_delta`;
- `stronger_delta`;
- `claim_support_matrix`;
- `reviewer_attack_and_reply_patterns` when reviews/replies exist;
- `dynamic_metagraph_pattern` using the shipped meta-graph schema;
- `reuse_boundary`: where this case can and cannot be borrowed.

Abstract-only items can help discovery, but they cannot become reusable examples.

## New v1.1.1 Improvement

In addition to the older anonymous casebook, the KB should now preserve reusable **patterns**, not just story slogans:

1. `problem_to_failure_mode_pattern`;
2. `solution_to_scientific_question_pattern`;
3. `claim_evidence_risk_pattern`;
4. `reviewer_question_answerability_pattern`;
5. `risk_disclosure_pattern`;
6. `metagraph_path_pattern`, e.g. `constraint -> evaluation norm -> missing experiment`;
7. `frontier_borrowing_boundary`, e.g. paper-ready vs discussion-ready vs proposal-only.

## Local Artifacts

Recommended local artifacts:

- `.delta-contribution-reframer/references/anonymous_casebook.jsonl`
- `.delta-contribution-reframer/references/per_pdf_report_synthesis.md`
- `.delta-contribution-reframer/references/llm_deep_read_synthesis.md`
- `.delta-contribution-reframer/references/metagraph_pattern_bank.jsonl`
- `.delta-contribution-reframer/references/literature_evidence_policy.md`
- `.delta-contribution-reframer/state/knowledge_state.json`
- `.delta-contribution-reframer/state/source_coverage_report.md`

If a script version does not create every optional artifact yet, the final report must still apply the rules manually and state the coverage gap.

## What Not To Do

- Do not include raw PDFs in the generated reusable skill.
- Do not include raw review dumps unless explicitly requested and privacy-safe.
- Do not use weak papers as positive templates.
- Do not treat packaged cases as evidence about a new target paper.
- Do not say a literature claim is known unless it is backed by a visible source ledger.

## v1.1.2 Source Quality Gate

Apply `references/report_playbook/source_quality_gate.md` before a source becomes reusable knowledge.

The KB now has a quality-weighted rule:

- `anchor_positive` papers form the main positive template bank for high-level L1-L4 advice;
- `accepted_quality` papers can supplement patterns but should not dominate scientific-elevation guidance;
- `review_rich_case` papers are especially useful for reviewer attack and rebuttal patterns;
- `trend_discovery` papers can guide collision and frontier search but cannot become positive templates unless later peer-reviewed and fully read;
- `negative_risk` papers become warning examples only.

Required or recommended additional artifacts:

- `source_quality_ledger.jsonl`: one record per candidate with venue/source quality role;
- `venue_profile.json`: field-specific anchor/credible/evaluation/discovery source lists when available;
- `quality_coverage_report.md`: explains how many references are anchor-positive, accepted-quality, review-rich, discovery-only, negative-risk, or unverified.

If the field's venue standard is unknown, ask the user for a venue profile or proceed conservatively. Do not pretend a corpus is top-tier just because it is related.


## v1.1.6 Execution-Oriented KB Additions

When building a reusable domain KB, also preserve patterns that help future authors actually revise manuscripts:

- `submission_context_pattern`: how venue/deadline/experiment budget changed the advice;
- `edit_ready_patch_pattern`: safe abstract, contribution, related-work, and experiment-narrative rewrites;
- `minimal_decisive_experiment_pattern`: smallest evidence addition that resolved a reviewer risk;
- `figure_table_evidence_pattern`: how a figure/table was reframed as claim evidence;
- `resource_parity_pattern`: baseline fairness/cost/reproducibility issues and repairs;
- `citation_role_pattern`: how closest-prior, baseline, and evaluation-norm citations were used safely;
- `revision_loop_pattern`: what changed from v0 to v1/v2 and which risks remained.

These patterns should be anonymized and quality-gated just like older contribution-framing cases.


## Corpus scope intake

Before local KB construction, confirm research field(s), years, per-year paper quantity, source venues/journals/official sites/databases, and local materials. If multiple fields are supplied, build a balanced field×year quota table. A local KB built without this scope record should be marked exploratory, not professional.
