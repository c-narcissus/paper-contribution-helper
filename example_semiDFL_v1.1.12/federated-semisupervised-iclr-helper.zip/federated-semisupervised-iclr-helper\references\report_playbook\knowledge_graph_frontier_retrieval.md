# Knowledge-Graph Frontier Retrieval

**Important:** this playbook does not require a persistent thread-level knowledge graph. Default to the web-safe dynamic meta-graph in `web_safe_dynamic_metagraph.md`: fixed schema, paper-specific graph, verified retrieval, and explicit source boundary.


Use this playbook when the user asks to connect a paper to the latest research, perform multi-hop literature search, or borrow adjacent frontier ideas without hype.

## Why Knowledge-Graph Retrieval

In ChatGPT Web, treat "knowledge graph" as a reasoning schema and retrieval plan, not as a hidden long-lived database. In Codex/local mode, scripts may save graph artifacts, but the report must still show what was actually retrieved and verified.


Keyword search finds papers with the same words. Frontier search should also find papers connected by problem, constraint, method primitive, dataset, evaluation metric, failure mode, theory, or citation neighborhood. OpenAlex describes scholarly works, authors, venues, institutions, and concepts as an open scientific knowledge graph; Semantic Scholar exposes literature search, citation links, influential citations, fields, and recommendation-style discovery; ORKG represents research contributions in structured, machine-actionable form for comparison and knowledge discovery.

## Node Types

Extract these nodes from the target paper:

- `problem`: the general scientific problem;
- `constraint`: scarcity, privacy, non-IID, latency, safety, distribution shift, etc.;
- `failure_mode`: what goes wrong;
- `assumption`: what prior work assumes;
- `method_primitive`: model, optimizer, augmentation, retrieval, graph, causal, diffusion, agentic loop, etc.;
- `evidence`: dataset, metric, benchmark, ablation, diagnostic;
- `domain`: application field;
- `frontier_topic`: latest active community theme;
- `boundary`: what is not yet solved.

## Edge Types

Use multi-hop paths rather than one-shot keyword matches:

| Edge | Meaning |
|---|---|
| cites / cited-by | citation neighborhood |
| shares-constraint | same scarce/unsafe/private/non-IID/low-resource regime |
| shares-failure-mode | same error pattern or bottleneck |
| borrows-primitive | same reusable method family |
| evaluates-on | same benchmark or metric |
| contradicts / negative-result | evidence that weakens naive claims |
| adjacent-domain | same problem structure in a different field |
| frontier-trend | recently active topic or workshop direction |

## Recommended Multi-Hop Queries

Run at least three of these paths when frontier positioning matters:

1. `target method primitive -> recent papers using same primitive -> different constraint -> transferable idea`.
2. `target failure mode -> adjacent domain with same failure -> method not used in target field`.
3. `target constraint -> latest benchmark/evaluation protocol -> missing experiment in target paper`.
4. `closest prior -> cited-by recent papers -> new limitation/critique -> safer related-work boundary`.
5. `target dataset/metric -> SOTA papers -> new evaluation norm -> fairness/cost/reproducibility gap`.
6. `target scientific question -> survey/position/workshop papers -> open problem -> L4 research-program extension`.

## Frontier Borrowing Rule

Borrow only five kinds of information from latest work:

- a sharper problem definition;
- a failure-mode taxonomy;
- an evaluation protocol;
- a mechanism lens;
- a feasible next experiment.

Do not borrow unsupported claims, buzzwords, or labels. Never rename a paper as a frontier topic unless the target paper has a real node-edge path to that topic.

## Output Requirement

Before any frontier bridge, output or internally build the `Dynamic Meta-Graph Card` from `web_safe_dynamic_metagraph.md`.


For each frontier bridge, output a `Frontier Bridge Card`:

| Field | Required content |
|---|---|
| Multi-hop path | e.g., target constraint -> recent benchmark -> missing diagnostic |
| Why it matters | what scientific boundary or reviewer risk it touches |
| Borrowable idea | problem lens / method primitive / evaluation / limitation |
| Safe manuscript use | paper-ready / discussion-ready / proposal-only |
| Needed evidence | what would be required to claim more |
| Hype risk | how this could become dishonest if overstated |
