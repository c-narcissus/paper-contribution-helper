# Workflow: Target Paper Reframing

Use after initialization, or for a single user-provided paper that should be analyzed without updating the reusable knowledge base. The quality bar is defined in `contract_target_report_quality.md`. The default style is the plain advisor style in `references/report_playbook/plain_teacher_reporting.md`.

## Pre-Pass

1. Run the related-work intake gate from `related_work_intake_and_comparative_deep_read.md`. Ask whether the author has related-work PDFs/links/baselines/reviews to provide. If they already provided them, do not ask again; deep-read them. If they say no, use the target paper to derive candidates and verified search paths.
2. Build a source ledger for the target PDF, supplied related papers, supplied reviews/replies, metadata, verified external sources, and unread/search-plan-only sources.
3. Extract and inspect the target PDF text first. Save intermediate artifacts when a writable output directory is available.
4. Run `scripts/analyze_new_pdf.py` when available, but treat it as a pre-pass only. Its pattern hits and scaffold are inputs to the final report, not the final report itself.
5. Load `references/anonymous_casebook.jsonl` and `references/per_pdf_report_synthesis.md` only as anonymous analogy resources. Do not use them as evidence about the target paper.
6. For the final decision, run the adapted report playbooks when relevant: `related_work_intake_and_comparative_deep_read.md`, `submission_context_gate.md`, `target_venue_rubric_adapter.md`, `edit_ready_patch_generator.md`, `minimal_decisive_experiment_planner.md`, `revision_iteration_loop.md`, `figure_table_evidence_audit.md`, `baseline_fairness_reproducibility_ledger.md`, `citation_role_and_support_audit.md`, `claim_evidence_risk_map.md`, `reviewer_question_answerability.md`, `paper_logic_completeness_audit.md`, `risk_self_disclosure_playbook.md`, `simulated_review_panel.md`, `multi_layer_revision_ladder.md`, `solution_to_scientific_question_elevation.md`, `knowledge_graph_frontier_retrieval.md`, `scientific_boundary_breakthrough.md`, `top_scientist_advisor_lens.md`, and `frontier_topic_alignment.md`.
7. If external GitHub/research-tool patterns are considered during skill maintenance, consult `github_research_skill_benchmark.md`; do not copy external skills directly into target-paper reports.

## Default Final Report

Write like a careful advisor talking to the author. Do not make the author read a route matrix before they understand the main point.

1. Start with a direct conclusion: whether the current contribution framing is weak, why, and what the better main story is.
2. Explain the target regime in plain Chinese: what problem the paper is really trying to repair, what old assumptions are unavailable, and why naive methods fail.
3. Explain why the current manuscript may look incremental, A+B+C, engineering-only, or old-method migration.
4. Compare against supplied or verified related work before finalizing the story. Explain whether the real difference is problem, regime, assumption, method, evidence, cost, or evaluation protocol.
5. Recover the stronger evidence-bounded contribution. Name the mechanism/failure/interface/constrained-regime repair that makes the method more than a module list.
6. Add a compact claim-evidence-risk check for the highest-risk contribution claims: safe claim, unsafe overclaim, evidence anchor, and repair tier.
7. Give concrete rewrite advice for the abstract, introduction, contribution bullets, related-work boundary, method overview/Figure, and experiment organization.
8. Simulate the main reviewer attacks with practical responses and answerability labels. Include novelty/incrementality, A+B/C, closest-prior, baseline fairness, mechanism evidence, cost/scalability, scope, privacy/safety, or reproducibility only when relevant.
9. Explain how to disclose the most important residual risks elegantly as scope boundaries rather than apologies.
10. Provide an L0-L4 revision ladder: L0 wording repair, L1 argument repair, L2 evidence repair, L3 solution-to-scientific-question elevation, and L4 frontier/boundary expansion.
11. For high-level advice, show how the solution can be lifted into failure mode, broken assumption, scientific question, principle/mechanism, and research-program roadmap.
12. Include knowledge-graph frontier/trend alignment only when there is a real multi-hop bridge or collision risk; label external sources as positioning evidence, not target-paper proof.
13. Include English manuscript/rebuttal snippets only when they are evidence-bounded and directly usable.
14. Include safe edit-ready patches and the one most decisive experiment when the evidence gap is material.
15. End with a short revision-loop checkpoint: what the author should revise/send back next.

## Detailed Mode

If the user asks for a detailed report, complete route comparison, or reviewer-defense matrix, extend the report with:

- six story-route slots by default, marking unsupported routes clearly;
- route comparison table;
- per-route expansion with examples, evidence anchors, rewrite targets, boundaries, and snippets;
- full manuscript-trigger localization;
- related-work relationship map and comparison questions;
- claim-evidence-risk map;
- reviewer question answerability table;
- paper logic completeness audit;
- simulated review panel and AC synthesis;
- risk disclosure box;
- solution-to-scientific-question elevation, L0-L4 ladder, KG multi-hop frontier bridge cards, scientific boundary roadmap, and novelty collision table when current sources are supplied or requested;
- rebuttal pattern library with risky wording to avoid;
- anonymous case appendix with borrowing paths and boundaries.

Do not ship a generic target report that merely follows section names. The final report must make paper-specific packaging decisions and explain the tradeoffs in language the author can immediately act on.


## v1.1.1 Web-Safe Meta-Graph Step

When high-level scientific elevation or latest-literature alignment is requested:

1. Build the target-only dynamic meta-graph from the PDF using `web_safe_dynamic_metagraph.md`.
2. Separate internal target-paper evidence from external literature.
3. If retrieval is available, verify sources and fill a literature evidence ledger.
4. If retrieval is unavailable, output graph-path queries and mark them `search-plan-only`.
5. Keep the explanation in the plain teacher style: solution -> failure mode -> broken assumption -> scientific question -> safe next step.

Do not say that the skill has checked the latest literature unless it actually used a visible retrieval source in this run.


## v1.1.5 Related-Work Intake and Comparative Deep Read

When the user chooses to analyze a paper, the first normal reply after the startup menu should not be the final report unless the user already supplied or declined related work. Ask for closest related papers, baselines, competitor methods, reviews, or rebuttal material. If supplied, deep-read those papers and treat them as user-provided sources. If absent, mine the target paper's related work, references, baseline tables, experiments, limitations, and frontier language to generate verified retrieval paths. Use arXiv/OpenReview/official venue or publisher pages/benchmark pages only when visible retrieval is available. If retrieval is not available, label the result `search-plan-only`.

The final advice must explain relations, not just list papers: same problem vs same method, same setting vs different assumptions, direct baseline vs distant analogy, evaluation norm vs collision risk. Tie those relations to L0-L4 revision actions.


## v1.1.6 Submission Context and Executable Revision Flow

After the related-work intake gate, do a compact submission-context gate before the final report:

1. Ask or infer target venue/journal, deadline, page limit, experiment budget, and risk posture. If the user does not answer, continue under explicit conservative assumptions.
2. Adapt the advice to the target venue/journal rubric instead of using a generic review standard.
3. Convert diagnosis into edit-ready manuscript patches: abstract thesis, contribution bullets, related-work boundary, method/figure caption, experiment narrative, limitation/discussion, and rebuttal snippets when relevant.
4. If evidence is weak, propose the minimal decisive experiment first: the smallest baseline, ablation, diagnostic, stress test, resource-parity check, or reproducibility addition that most reduces reviewer doubt.
5. Audit figures/tables as evidence objects: each important table or figure should support a claim or answer a reviewer question.
6. Build a baseline fairness/reproducibility ledger when comparisons matter.
7. Audit citation roles and support: closest prior, baseline, method primitive, evaluation norm, failure evidence, frontier analogy, or scope boundary.
8. End with a revision-loop plan: what the author should send back in v1/v2, and what the skill will re-check.

Use the corresponding playbooks in `references/report_playbook/`. Keep this in plain teacher voice: “先别急着大改，我们先看目标场子、还剩多少时间、能不能补实验。然后决定哪些是今天就能改的句子，哪些是必须补证据的地方。”
