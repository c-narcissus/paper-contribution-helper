# Source Strategy: Scholarly Knowledge-Graph Frontier Search

Default assumption: ChatGPT Web may not have a persistent KG or callable scholarly APIs. Use this strategy as a verified retrieval plan unless external search/API results are actually available. Pair it with `references/report_playbook/web_safe_dynamic_metagraph.md` and `literature_evidence_guard.md`.


Use this source strategy for latest-topic alignment, novelty collision search, and multi-hop frontier discovery.

## Preferred Sources

- **Semantic Scholar**: paper search, references, citations, influential citation signals, fields of study, and recommendation-style discovery. Good for citation-neighborhood and closest-prior expansion.
- **OpenAlex**: open scholarly knowledge graph covering works, authors, venues, institutions, and concepts/topics. Good for concept/topic expansion, venue filtering, citation graph traversal, and broad coverage.
- **ORKG / Open Research Knowledge Graph**: structured representation of research contributions, methods, materials, and results. Good for comparing contribution dimensions and converting prose papers into problem-method-result structures.
- **arXiv recent / OpenReview / conference workshops**: recency-sensitive frontier and collision detection.
- **Papers with Code / benchmark pages**: evaluation norms, datasets, metrics, and SOTA baselines.

## Corpus Split

Never mix the purposes of the sources:

| Corpus | Purpose | Use in report |
|---|---|---|
| defense corpus | mature prior work and reviews before/around target area | teaches framing and reviewer defenses |
| collision corpus | most recent related papers | checks novelty risk and closest-prior boundary |
| frontier corpus | adjacent hot research | suggests L4 roadmap, not current claims |
| evaluation corpus | benchmarks, datasets, leaderboards | checks experimental completeness |

## Multi-Hop Search Budget

Default frontier search should be small and purposeful:

1. one hop from closest prior via citations/cited-by;
2. one hop from target constraint to recent papers;
3. one hop from failure mode to adjacent domains;
4. one hop from dataset/metric to current evaluation norms;
5. one synthesis step to produce frontier bridge cards.

## Evidence Labels

Label all external material:

- `external-prior`: related work evidence;
- `external-frontier`: emerging direction, not target evidence;
- `external-evaluation-norm`: benchmark or protocol expectation;
- `external-collision-risk`: possible novelty collision;
- `external-analogy`: adjacent idea only.

External frontier sources can motivate high-level advice but cannot prove the target paper's contribution.


## Web-Safe Fallback

If no retrieval tool is available, do not invent references. Produce:

1. dynamic meta-graph nodes from the target paper;
2. 3-6 graph-path retrieval queries;
3. a list of source types to check;
4. what each source would be allowed to support;
5. a note that latest-literature claims are unverified until retrieved.

## Quality Gate Interaction

After KG-style retrieval, run the source/venue quality gate before reusing anything. Multi-hop relevance is not enough.

- `anchor_positive` results can shape high-level framing and scientific-question elevation.
- `accepted_quality` results can supplement framing and evidence norms.
- `trend_discovery` results can only become collision/frontier/retrieval signals.
- `negative_risk` results are warning examples.
- `excluded_or_unverified` results should remain search tasks.

In reports, say plainly when a result is only a trend signal rather than a top-quality template.
