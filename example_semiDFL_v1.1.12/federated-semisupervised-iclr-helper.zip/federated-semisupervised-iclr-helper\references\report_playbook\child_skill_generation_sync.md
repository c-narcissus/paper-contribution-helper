# Child Skill Generation Sync Requirements

Use this playbook when generating a professional reusable child skill from a domain corpus.

## Main Idea

A child skill must inherit the upgraded methodology, not just the old casebook. It should be able to help future papers at all levels:

- L0: wording and section repair;
- L1: argument-chain repair;
- L2: evidence repair;
- L3: solution-to-scientific-question elevation;
- L4: frontier/boundary roadmap with no hallucinated literature.

## Required Sync From Parent Skill

Generated child skills must include or reference these playbooks:

- claim-evidence-risk map;
- reviewer question answerability;
- paper logic completeness audit;
- risk self-disclosure;
- L0-L4 multi-layer revision ladder;
- solution-to-scientific-question elevation;
- web-safe dynamic meta-graph;
- literature evidence guard;
- local knowledge-base construction rules;
- scientific boundary breakthrough;
- top-scientist advisor lens;
- GitHub research-skill benchmark adaptation.

## Child Skill KB Contents

The child skill should package anonymized reusable knowledge only:

| Packaged item | Allowed? | Why |
|---|---|---|
| anonymous case patterns | yes | reusable contribution-defense knowledge |
| metagraph path patterns | yes | reusable high-level reasoning structure |
| claim-risk/evidence patterns | yes | helps future target papers avoid overclaiming |
| reviewer attack/rebuttal patterns | yes | supports defense planning |
| raw PDFs | no | too large, privacy/provenance risk |
| raw review dumps | no by default | privacy and overfitting risk |
| unverified latest-paper claims | no | hallucination/currency risk |

## Domain Child Skill Report Style

Generated child skills must keep the plain advisor voice. The default report should sound like:

> 这篇文章不是没有贡献，而是现在还停在“我做了一个方案”的层面。更好的写法是先说它修复了哪个失败模式，再说这个失败模式背后是哪条旧假设坏了。至于最新研究，只能作为检索和 discussion 的方向，不能直接写成你已经解决了。

Avoid making the child skill sound like a formal audit robot.

## Generation Gate

Do not ship a child skill unless:

1. every selected reusable reference PDF has full-paper deep-read status or a clear coverage warning;
2. every reusable pattern has a source ledger and reuse boundary;
3. external frontier items are labeled as collision/frontier/evaluation/analogy, not target evidence;
4. the child template includes the v1.1.9 inherited playbooks;
5. validation confirms no raw PDFs, temp caches, or absolute paths are packaged.

## v1.1.2 Quality Gate Sync

A professional child skill must inherit the source/venue quality gate.

Before packaging, it should report:

1. the field-specific quality standard used;
2. which papers are `anchor_positive`, `accepted_quality`, `review_rich_case`, `negative_risk`, `trend_discovery`, or `evaluation_norm`;
3. whether top-level L3/L4 scientific-elevation advice is backed mainly by anchor-positive sources;
4. which sources are discovery-only and must not become positive templates;
5. any coverage warning, e.g. “only abstracts were available” or “venue quality was not verified.”

If this check is missing, the child skill may still be useful for local drafting, but it should not claim top-conference/top-journal-level methodology coverage.


## v1.1.6 Execution Sync

Generated child skills must also inherit the execution-oriented workflow:

- submission-context gate and target-venue/journal rubric adapter;
- edit-ready patch generation;
- minimal decisive experiment planning;
- revision iteration loop;
- figure/table evidence audit;
- baseline fairness and reproducibility ledger;
- citation role and support audit;
- child-skill regression test.

Before packaging, check that the child startup menu still uses the child zip filename, omits the new-skill-generation route, and that target-paper analysis still asks for related work plus submission context before the final report.

## v1.1.9 Hard Inheritance Requirement

From v1.1.9 onward, synchronization is not a soft recommendation. A generated child skill is ready only if it passes the child inheritance contract in `references/report_playbook/child_skill_inheritance_contract.md`.

Required implementation:

1. copy all required report playbooks from the parent template;
2. keep the child startup menu and child zip-name prompt prefix;
3. keep the related-work intake gate and submission-context gate in the child router;
4. keep the execution modules: edit-ready patches, minimal decisive experiments, revision loop, figure/table audit, baseline fairness, and citation support;
5. write an inherited-methodology list into `references/knowledge_manifest.json`;
6. run `scripts/check_child_skill_regression.py <child_skill_dir>` and do not hand off a production-ready child skill if it fails.

The domain knowledge can be specialized; the methodology cannot be silently downgraded.


## Child Startup Boundary Sync

Generated child skills must inherit `references/report_playbook/mode_and_analysis_direction_workflow.md` and a startup menu with explicit 模式A1/模式A2 plus A-D directions. The generated prompt must use the child zip filename, not the parent zip filename, and must not expose the parent package route for generating another reusable helper.


## v1.1.12 Child-Corpus Intake Sync

Generated child skills must inherit `references/report_playbook/child_skill_corpus_intake_gate.md` and `field_year_balanced_sampling.md`. The update/extension mode must ask for existing child skill, research field(s), years/year range, per-year paper quantity, source venues/journals/official sites/databases, and local folders/uploaded PDFs/project-run. If multiple fields are supplied, corpus collection should be balanced across field×year cells. The inherited methodology manifest must include `child-skill corpus intake gate` and `field-year balanced corpus sampling`, and the regression check must fail if this playbook or startup/menu markers are missing.


## v1.1.12 Disjunctive Corpus Intake Sync

Child skills must inherit the rule that multiple research fields, years, sources, and local materials are OR candidate pools by default. They must not treat them as an AND/intersection filter unless the user explicitly says so.
