# Paper Logic Completeness Audit

Use this playbook to check whether the manuscript forms a complete contribution argument rather than a list of modules.

## Core Chain

A strong target-paper report should test this chain:

```text
Problem -> Broken Assumption -> Method Necessity -> Evidence -> Boundary -> Claim
```

If any link is missing, the paper will look more incremental than it may actually be.

## Audit Questions

| Chain link | What to check | Common failure in A+B+C / engineering drafts | Repair |
|---|---|---|---|
| Problem | Is the problem specific to a constrained setting? | The intro names a broad challenge but not the concrete failure regime | Rewrite the problem as a bounded regime with unavailable assumptions |
| Broken assumption | What old method assumption fails here? | Related work says prior work is limited but not why | Add a closest-prior boundary paragraph |
| Method necessity | Is each component forced by the failure chain? | Components are listed as independent improvements | Re-explain modules as repairs to distinct failure modes or interfaces |
| Evidence | Does each experiment answer a reviewer doubt? | Results are narrated as accuracy gains only | Organize experiments around failure modes, not tables alone |
| Boundary | Are unsupported generalizations contained? | Contribution bullets are stronger than evidence | Add scope control and safe claim wording |
| Claim | Does the final claim match evidence strength? | The paper claims a general method while testing a narrow setting | Use constrained-regime contribution language |

## Logic Failure Symptoms

- The abstract says “we propose a framework” but not what assumption it repairs.
- Contribution bullets repeat component names.
- Related work compares topics but not closest mechanisms.
- Ablation tables exist but are not linked to failure modes.
- The method overview figure shows pipeline order but not conceptual necessity.
- Limitations are vague self-criticism rather than bounded-scope control.

## Final Report Rule

Before recommending a story route, identify the weakest link in the chain. The strongest story is usually the one that repairs the weakest link with existing evidence.
