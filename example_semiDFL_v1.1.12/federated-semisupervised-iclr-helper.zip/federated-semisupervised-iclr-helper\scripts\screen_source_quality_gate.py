#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any


def load_profile(path: Path | None) -> dict[str, Any]:
    if not path:
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def norm(s: Any) -> str:
    return str(s or "").strip().lower()


def read_records(path: Path) -> list[dict[str, Any]]:
    if path.suffix.lower() == ".jsonl":
        rows = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rows.append(json.loads(line))
        return rows
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else data.get("records", [])
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def classify(record: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    venue = norm(record.get("venue") or record.get("venue_or_source") or record.get("source") or record.get("journal") or record.get("conference"))
    title = str(record.get("title") or "").strip()
    year = record.get("year") or record.get("date") or ""
    has_pdf = bool(record.get("pdf_path") or record.get("pdf_url") or record.get("local_pdf"))
    has_reviews = bool(record.get("review_url") or record.get("reviews_path") or record.get("openreview_forum") or record.get("meta_review"))
    peer = norm(record.get("peer_review_status"))

    anchor = {norm(v) for v in profile.get("anchor_venues", [])}
    credible = {norm(v) for v in profile.get("credible_venues", [])}
    evals = {norm(v) for v in profile.get("evaluation_sources", [])}
    discovery = {norm(v) for v in profile.get("discovery_only_sources", ["arxiv", "workshop", "github", "blog", "leaderboard"])}
    excluded = {norm(v) for v in profile.get("excluded_sources", [])}

    role = "excluded_or_unverified"
    allowed = ["do_not_use"]
    reason = "no venue/profile match or insufficient metadata"

    if venue in excluded:
        role = "excluded_or_unverified"
        reason = "source appears in excluded_sources profile"
    elif venue in anchor and has_pdf:
        role = "anchor_positive"
        allowed = ["positive_template", "evaluation_norm", "reviewer_risk"]
        reason = "venue/source matches anchor_venues and PDF is available"
    elif venue in credible and has_pdf:
        role = "accepted_quality"
        allowed = ["positive_template", "reviewer_risk"]
        reason = "venue/source matches credible_venues and PDF is available"
    elif venue in evals:
        role = "evaluation_norm"
        allowed = ["evaluation_norm"]
        reason = "source matches evaluation_sources profile"
    elif any(token in venue for token in discovery):
        role = "trend_discovery"
        allowed = ["trend", "collision"]
        reason = "source is discovery-only by default"
    elif has_reviews and has_pdf:
        role = "review_rich_case"
        allowed = ["reviewer_risk", "rebuttal_pattern"]
        reason = "PDF plus review/reply evidence available, but venue quality not anchored"
    elif peer in {"accepted", "peer-reviewed", "verified"} and has_pdf:
        role = "accepted_quality"
        allowed = ["positive_template", "reviewer_risk"]
        reason = "peer-review status is explicit and PDF is available"
    elif has_pdf:
        role = "accepted_quality"
        allowed = ["reviewer_risk"]
        reason = "PDF available but venue quality is unverified; use conservatively"

    out = dict(record)
    out.update({
        "source_quality_gate": {
            "title": title,
            "year": year,
            "venue_or_source": venue or "unknown",
            "quality_role": role,
            "quality_evidence": profile.get("venue_quality_source", "manifest/profile/manual"),
            "read_status": "pdf_available" if has_pdf else "metadata_or_abstract_only",
            "allowed_use": allowed,
            "reason": reason,
        }
    })
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="Annotate a paper manifest with source/venue quality roles. No network access is used.")
    parser.add_argument("--manifest", type=Path, required=True, help="JSONL/JSON/CSV paper manifest")
    parser.add_argument("--venue-profile", type=Path, default=None, help="Optional JSON field venue profile")
    parser.add_argument("--out", type=Path, required=True, help="Output JSONL path")
    args = parser.parse_args()

    profile = load_profile(args.venue_profile)
    records = read_records(args.manifest)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(classify(record, profile), ensure_ascii=False) + "\n")
    print(json.dumps({"records": len(records), "out": args.out.as_posix()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
