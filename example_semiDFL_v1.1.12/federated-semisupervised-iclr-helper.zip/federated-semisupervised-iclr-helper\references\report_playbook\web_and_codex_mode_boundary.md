# Web And Codex Mode Boundary

Use this short playbook to explain environment differences without overcomplicating the report.

## ChatGPT Web Mode

Assume no persistent local graph, no guaranteed external APIs, and no hidden project state. The skill should:

- use packaged methodology and uploaded sources;
- dynamically rebuild the meta-graph from the current paper;
- ask for or list literature retrieval targets when sources are unavailable;
- avoid claiming it has searched latest literature unless web/search tools are actually used;
- keep the report readable and teacher-like.

## Codex / Local Mode

Codex/local mode can additionally:

- run scripts;
- save local reports and ledgers;
- build a corpus-run;
- create reusable child skills;
- write `dynamic_metagraph.json`, `frontier_retrieval_plan.md`, and source ledgers.

But Codex/local artifacts are still not magical evidence. They only matter if the files exist and can be inspected.
