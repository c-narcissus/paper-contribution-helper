# Reusable Delta-Contribution Synthesis

Scope: iclr-openreview corpus, focused on 联邦学习, 半监督学习, years 2023, 2024.

## What The Initialized Corpus Supports

- Low-novelty defense should be built around explicit failure modes, not around claiming a larger algorithmic leap.
- Accepted delta-sized work often survives by narrowing the setting, clarifying the mechanism, and making the evidence chain auditable.
- Rebuttal patterns frequently combine existing-evidence resurfacing, claim clarification, and boundary defense; new experiments appear in real author replies but should not be invented for future use.
- Use domain-specific constraints as the contribution anchor: heterogeneity, label scarcity, communication/cost, benchmark protocol, or deployment limits.

## Reusable Case Cards

### anonymous-delta-case-001: delta-sized-accepted-paper-pattern

- Examples: 10
- Domains: 半监督学习, 联邦学习
- Modes: transfer_or_light_adaptation, evidence_or_benchmark, engineering_or_efficiency, abc_combination
- Review attacks: 
- Reply moves: 
- Route use: fallback delta-packaging route
- Raw weakness pattern: 贡献小但没有被放进清晰问题压力时，容易被直接判为 incremental。
- Effective packaging pattern: 以问题压力、证据链和边界化 claims 组织贡献。
- Reframing: 把小改动放入明确问题压力、可检验证据链和边界化 claims 中。
- Borrowable move: 用于 strong packaging diagnosis 和 report fallback。
- Risk boundary: 不要夸大成 broad framework；防守 narrow but recurring failure case。
- Best report sections: Strong Packaging Diagnosis, Residual Risk

English manuscript-facing snippet:

> The contribution is deliberately scoped: it addresses a narrow but recurring failure case and provides evidence for that scope.

### anonymous-delta-case-002: combination-method-needs-mechanism-claim

- Examples: 5
- Domains: 半监督学习, 联邦学习
- Modes: abc_combination, transfer_or_light_adaptation, engineering_or_efficiency, evidence_or_benchmark
- Review attacks: novelty_incrementality, abc_or_mechanism, baseline_fairness, ablation_evidence, experiment_scope
- Reply moves: existing_evidence_resurfacing, setting_boundary_defense, claim_softening_or_clarification, new_experiment_or_result
- Route use: surrogate / coupling / interface route
- Raw weakness pattern: 工作容易被攻击为 known components assembly 或 A+B/C。
- Effective packaging pattern: 把每个组件映射到受约束场景中的一个压力，证明耦合是由场景需求驱动的。
- Reframing: 承认组件来自已有谱系，但把贡献定位为组合后的机制闭环、接口约束或目标冲突解决。
- Borrowable move: 用于 Story Option Board 的主线、method overview、Figure 1 caption、A+B/C rebuttal。
- Risk boundary: 不要说每个 primitive 都全新；防守的是 constraint-driven coupling。
- Best report sections: Option 1, Option 3, Rebuttal A+B/C

English manuscript-facing snippet:

> The novelty lies in the interaction design: the components are individually known, but their coupling resolves a mismatch that neither component addresses in isolation.

### anonymous-delta-case-003: incremental-gain-with-ablation-pressure

- Examples: 4
- Domains: 联邦学习, 半监督学习
- Modes: low_novelty_or_incremental, transfer_or_light_adaptation, engineering_or_efficiency, evidence_or_benchmark, abc_combination
- Review attacks: novelty_incrementality, abc_or_mechanism, baseline_fairness, ablation_evidence, experiment_scope
- Reply moves: existing_evidence_resurfacing, new_experiment_or_result, setting_boundary_defense, claim_softening_or_clarification
- Route use: failure-mode / mechanism-evidence route
- Raw weakness pattern: 工作容易被读成小幅性能提升或单点替换。
- Effective packaging pattern: 先命名失败模式，再把模块写成 targeted intervention，并用 ablation 支撑必要性。
- Reframing: 把“提升幅度”改写为“在受约束设定下稳定消除特定失败模式”，并把 ablation 组织成机制排除表。
- Borrowable move: 用于 strong packaging diagnosis、mechanism rebuttal、Tier 0 ablation discussion rewrite。
- Risk boundary: 不要把 ablation 写成完整机制证明；只能说 supports the mechanism 或 rules out simpler explanations。
- Best report sections: Option 1, Option 4, Reviewer Attack Preplay, Rebuttal Mechanism

English manuscript-facing snippet:

> Our contribution is not a standalone component swap; it identifies a failure mode in the constrained setting and shows that each design choice is necessary to remove that failure.

### anonymous-delta-case-004: light-transfer-with-scope-generalization-risk

- Examples: 1
- Domains: 联邦学习
- Modes: transfer_or_light_adaptation, engineering_or_efficiency, evidence_or_benchmark
- Review attacks: novelty_incrementality, abc_or_mechanism, baseline_fairness, ablation_evidence, experiment_scope
- Reply moves: existing_evidence_resurfacing, new_experiment_or_result, setting_boundary_defense, claim_softening_or_clarification
- Route use: scope-boundary / transfer route
- Raw weakness pattern: 迁移或适配工作容易被认为 novelty 不足或 scope 过窄。
- Effective packaging pattern: 把贡献限制在共享结构瓶颈下的可验证适配，而不是泛化到所有场景。
- Reframing: 避免宣称通用迁移；明确源任务和目标任务之间的结构同构，再用边界条件解释为什么轻量适配成立。
- Borrowable move: 用于 related-work boundary、scope/generalization rebuttal、residual risk。
- Risk boundary: 不要宣称 universal transfer；只说 evaluated regime 或 shared structural bottleneck。
- Best report sections: Option 2, Option 6, Residual Risk

English manuscript-facing snippet:

> We focus on the regime where the source and target settings share the same structural bottleneck, which makes a lightweight adaptation sufficient and testable.

### anonymous-delta-case-005: baseline-contract-fairness-defense

- Examples: 10
- Domains: 联邦学习, 半监督学习
- Modes: transfer_or_light_adaptation, engineering_or_efficiency, evidence_or_benchmark, abc_combination, low_novelty_or_incremental
- Review attacks: novelty_incrementality, abc_or_mechanism, baseline_fairness, ablation_evidence, experiment_scope
- Reply moves: existing_evidence_resurfacing, setting_boundary_defense, claim_softening_or_clarification, new_experiment_or_result
- Route use: baseline-contract route
- Raw weakness pattern: baseline 资源边界不清会被读成回避强对照。
- Effective packaging pattern: 在实验前加入 comparison contract，把服务器、共享数据、共享验证集、标注预算、通信预算等条件显式化。
- Reframing: 先定义 same-contract baseline，再解释哪些对照满足相同资源约束，哪些只是 broader-regime diagnostic。
- Borrowable move: 用于 related work boundary、experiment setup、baseline fairness rebuttal。
- Risk boundary: 不要简单说 baseline 不可比；要说明 resource mismatch 和 diagnostic value。
- Best report sections: Option 2, Reviewer Attack Preplay, Rebuttal Baseline

English manuscript-facing snippet:

> We clarify the comparison contract by distinguishing same-resource baselines from diagnostic baselines that rely on additional coordination or supervision.

### anonymous-delta-case-006: evidence-system-coverage-defense

- Examples: 10
- Domains: 联邦学习, 半监督学习
- Modes: transfer_or_light_adaptation, engineering_or_efficiency, evidence_or_benchmark, abc_combination, low_novelty_or_incremental
- Review attacks: novelty_incrementality, abc_or_mechanism, baseline_fairness, ablation_evidence, experiment_scope
- Reply moves: existing_evidence_resurfacing, setting_boundary_defense, claim_softening_or_clarification, new_experiment_or_result
- Route use: evidence-system route
- Raw weakness pattern: 实验结果存在但没有说明每个结果防守哪个 reviewer concern。
- Effective packaging pattern: 把 performance、label scarcity、non-IID、topology、ablation、runtime 或 appendix 证据逐一映射到攻击点。
- Reframing: 把现有实验重排成回答审稿疑问的证据系统，而不是按数据集或表格顺序堆结果。
- Borrowable move: 用于 Option 4、Tier 0 experiment-roadmap rewrite、appendix pointer。
- Risk boundary: 证据系统只能支撑 evaluated regime，不能自动支撑 universal generalization。
- Best report sections: Option 4, Manuscript Trigger Localization, Tier 0

English manuscript-facing snippet:

> We organize the evaluation around the main failure modes: end-to-end performance, robustness to the constrained regime, and component-level evidence for the proposed mechanism.

### anonymous-delta-case-007: efficiency-system-claim-under-cost-scrutiny

- Examples: 19
- Domains: 联邦学习, 半监督学习
- Modes: transfer_or_light_adaptation, engineering_or_efficiency, evidence_or_benchmark, abc_combination, low_novelty_or_incremental
- Review attacks: novelty_incrementality, abc_or_mechanism, baseline_fairness, ablation_evidence, experiment_scope
- Reply moves: existing_evidence_resurfacing, setting_boundary_defense, claim_softening_or_clarification, new_experiment_or_result
- Route use: quality-cost / deployment-boundary route
- Raw weakness pattern: 系统工作容易被要求更多成本、通信、规模和复现细节。
- Effective packaging pattern: 主动定义 quality-cost tradeoff 和 resource contract，把成本边界放进 limitation 或 discussion。
- Reframing: 把系统/效率贡献写成资源约束下的可部署性，而不是仅展示更快或更省。
- Borrowable move: 用于 cost/scalability attack、Tier 1 log reuse、limitation paragraph。
- Risk boundary: 没有 runtime、communication 或 resource schedule 时，不要写 negligible overhead。
- Best report sections: Option 5, Tier 1, Rebuttal Cost

English manuscript-facing snippet:

> The method targets the resource-constrained regime where communication, computation, or annotation cost is the limiting factor, not an incidental metric.

### anonymous-delta-case-008: scope-generalization-boundary-defense

- Examples: 10
- Domains: 联邦学习, 半监督学习
- Modes: transfer_or_light_adaptation, engineering_or_efficiency, evidence_or_benchmark, abc_combination, low_novelty_or_incremental
- Review attacks: novelty_incrementality, abc_or_mechanism, baseline_fairness, ablation_evidence, experiment_scope
- Reply moves: existing_evidence_resurfacing, setting_boundary_defense, claim_softening_or_clarification, new_experiment_or_result
- Route use: scope-boundary route
- Raw weakness pattern: claims 如果写得过满，审稿人会要求更多数据集、规模、拓扑或真实部署。
- Effective packaging pattern: 把当前证据覆盖的范围写清，把更大泛化放入 limitation 或 future work。
- Reframing: 把适用范围前置，主动限定 evaluated regime，避免被审稿人用更大场景攻击。
- Borrowable move: 用于 residual risk、discussion、scope rebuttal。
- Risk boundary: 不要写 universal claim；写 evaluated settings 或 initial evidence。
- Best report sections: Option 6, Rebuttal Scope, Residual Risk

English manuscript-facing snippet:

> We keep the claim focused on the evaluated regime and treat broader deployment conditions as an important direction for future validation.
