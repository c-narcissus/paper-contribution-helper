# Multi-Layer Revision Ladder

This playbook makes the helper capable of both low-level manuscript repair and high-level scientific elevation. Use it whenever the user asks for deep improvement, top-tier positioning, or stronger-than-local revision advice.

## Core Principle

Do not give only one tier of advice. Separate revision depth by how much the paper itself changes:

| Layer | Name | What changes | Typical user value | Evidence requirement |
|---|---|---|---|---|
| L0 | Surface repair | wording, paragraph order, contribution bullets | quick submission cleanup | target-paper text only |
| L1 | Argument repair | problem framing, related-work boundary, method overview, experiment narrative | makes the paper easier to defend | existing tables/figures/appendix/logs |
| L2 | Evidence repair | new ablations, diagnostics, baselines, cost/scope checks | closes reviewer-answerability gaps | feasible new or reused evidence |
| L3 | Scientific-question elevation | turns a solution into a general research question or broken assumption | gives the work a stronger intellectual reason | must be supported by problem structure and closest-prior gap |
| L4 | Frontier expansion | borrows latest adjacent progress and proposes boundary-touching extensions | creates top-scientist roadmap | requires external frontier sources and explicit uncertainty labels |

## Output Rule

A strong report should not collapse all advice into Tier 0 / Tier 1 / Tier 2. For ambitious requests, output a `L0-L4 revision ladder`:

- L0: what to rewrite today without changing results.
- L1: how to reorganize the paper so the method is necessity-driven, not module-driven.
- L2: which minimal evidence would most improve reviewer answerability.
- L3: what scientific question the work should be framed as addressing.
- L4: what frontier-adjacent extension could make the work more ambitious, and what evidence would be required before claiming it.

## Safety Boundary

L3/L4 suggestions are research-program advice, not manuscript claims, unless the target paper already contains evidence. Always mark each high-level proposal as:

- `paper-ready`: enough evidence to write now;
- `discussion-ready`: can be discussed as implication or limitation;
- `proposal-only`: needs new work;
- `unsafe-now`: would be hype or overclaim.

## For Incremental / A+B+C Papers

The goal is not to pretend a local solution is a grand theory. The goal is to ask whether the local solution reveals a more general broken assumption, missing interface, evaluation blind spot, or constraint regime that others have not named clearly.
