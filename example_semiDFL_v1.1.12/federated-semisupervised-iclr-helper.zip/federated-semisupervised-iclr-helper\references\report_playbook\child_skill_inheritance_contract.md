# Child Skill Inheritance Contract

Use this contract whenever the main skill generates, updates, audits, or packages a domain-specific child skill.

## Teacher-Level Rule

A child skill is not just a folder of anonymous cases. It must inherit the parent skill's working method. Otherwise the child skill will look professional but quietly fall back to old behavior: summarize related papers, give generic reviewer risks, and forget the execution loop.

## Must-Inherit Blocks

Every production-ready child skill must include these capability blocks:

1. startup menu with child zip-name prompt prefixes and no new-skill-generation route;
2. related-work intake gate before target-paper analysis;
3. submission-context and target-venue/journal gate;
4. L0-L4 revision ladder;
5. solution-to-scientific-question elevation;
6. claim-evidence-risk map;
7. reviewer-question answerability;
8. paper-logic completeness audit;
9. risk self-disclosure playbook;
10. web-safe dynamic meta-graph and literature evidence guard;
11. source-quality gate and venue-quality strategy;
12. local knowledge-base construction rules;
13. edit-ready patch generator;
14. minimal decisive experiment planner;
15. revision iteration loop;
16. figure/table evidence audit;
17. baseline fairness and reproducibility ledger;
18. citation role/support audit;
19. scientific-boundary and top-scientist advisor lens;
20. child-skill regression test.

## Packaging Rule

Before handoff, the child package must satisfy all three checks:

- file inheritance: required playbook files exist under `references/report_playbook/`;
- router inheritance: `SKILL.md` contains startup, related-work, submission-context, target-report, and no-hallucination routing rules;
- manifest inheritance: `references/knowledge_manifest.json` declares inherited methodology and the current parent methodology version.

If one of these checks fails, do not describe the child skill as ready. Say it is experimental/debug-only and name the missing inherited block.

## What Can Be Domain-Specific

The child skill can specialize these parts:

- domain profile;
- anonymous cases;
- common reviewer attacks in that field;
- field-specific baseline and evaluation norms;
- venue/journal quality profile;
- common story routes and broken assumptions;
- frontier/collision search paths.

But it must not remove the generic safety and execution contracts inherited from the parent.

## Non-Inheritance Boundary

A generated child skill inherits the parent skill's analysis, update, evidence, and regression methodology. It must not inherit the parent package's ability to generate another new child skill. New reusable-helper construction stays in the parent package; generated child skills may only analyze target papers or update/extend an existing child skill.

## Handoff Language

When handing off a generated child skill, say plainly:

> 这个子 skill 继承了主 skill 的相关工作 intake、投稿目标 gate、L0-L4、文献防幻觉、质量门槛、可替换文本、最小决定性实验和复查闭环；同时删除了继续生成新 skill 的入口。它的领域知识是专业化的，但底层分析和更新工作流没有降级。


## Child Startup Boundary

A production-ready child skill must keep explicit work-mode and A-D analysis-direction selection, but the child startup must omit the new-skill-generation route. Use the child-only mode namespace: 模式A1 for direct target-paper analysis and 模式A2 for updating/extending an existing child skill.


## v1.1.12 Corpus Intake Inheritance

A production-ready child skill must inherit the child-skill corpus intake gate and field-year balanced sampling for update/extension workflows. The child router/startup menu must make clear that updating/extending a child skill requires an existing child skill, research fields, years, per-year paper quantity, source venues/journals/official sites/databases, and local PDFs/project-run or uploaded sources. With multiple fields, the intended corpus should be balanced across field×year cells. Missing corpus-intake inheritance means the child skill is experimental/debug-only.


## v1.1.12 Disjunctive Corpus Intake Sync

Child skills must inherit the rule that multiple research fields, years, sources, and local materials are OR candidate pools by default. They must not treat them as an AND/intersection filter unless the user explicitly says so.
