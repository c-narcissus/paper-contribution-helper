# Source and Venue Quality Gate

Use this playbook whenever the skill builds a local knowledge base, selects reference papers, borrows high-level methodology, or gives L3/L4 scientific-elevation advice.

## Plain Idea

要做“顶级科学家视野”，不能什么文献都学。我们不是嫌弃普通论文，而是要分清它们的用途：

- 顶会顶刊 / 行业公认高质量论文：可以作为正面写法、科学问题升维、实验规范和 reviewer 防守的主要样本；
- 普通 accepted 论文：可以做补充参考，但不能单独决定高层方法论；
- arXiv、workshop、GitHub、博客、趋势榜：可以用来发现热点、撞车风险和检索方向，但不能直接当“顶级写法模板”；
- 低质量或证据薄弱论文：只能作为反例，提醒作者哪里会被 reviewer 打。

## Quality Roles

Assign every candidate source one role before using it:

| Role | What it means | Allowed use |
|---|---|---|
| `anchor_positive` | field-recognized top venue/journal, landmark paper, strong survey, or highly trusted benchmark paper; full text available | positive template for L1-L4 framing, evidence norms, and scientific-question elevation |
| `accepted_quality` | reputable peer-reviewed paper but not clearly top-tier, or good domain paper with solid evidence | supplementary pattern; should not dominate high-level advice |
| `review_rich_case` | has useful public reviews/replies/meta-review, even if venue tier is not the highest | reviewer-risk and rebuttal pattern learning |
| `negative_risk` | weak, rejected, or clearly attacked for novelty/A+B/C/evidence flaws | warning pattern only; never positive template |
| `trend_discovery` | arXiv preprint, workshop draft, GitHub trend, blog, leaderboard, news, or very recent unreviewed item | collision/trend/retrieval seed only |
| `evaluation_norm` | official benchmark, dataset, protocol, leaderboard, or field evaluation guideline | experiment completeness and baseline norm |
| `excluded_or_unverified` | unverifiable title/venue, predatory venue suspicion, missing full text, or only remembered by the model | do not use except as a search task |

## Field-Specific Quality Standard

Do not hardcode one universal list. First identify the field and then choose the field's normal quality signals.

### Computer Science

Computer science often treats top peer-reviewed conferences as first-class publication venues. For CS fields, the anchor corpus should usually prefer the field's recognized top conferences and journals, using community-recognized lists such as CORE/CCF-style rankings, society flagship venues, or user-provided lab/department venue lists when available. Use exact venue lists only when they are visible, user-provided, or verifiable in the current environment.

### Other fields

For fields where journals are the primary archival venue, prefer field-recognized top journals, society journals, major review journals, and high-quality proceedings only where the field values them. JCR, CiteScore, SJR, field quartiles, society recommendations, and expert-curated reading lists can help, but they are signals rather than proof of paper quality.

### Humanities, social sciences, and interdisciplinary fields

Some fields value books, monographs, edited volumes, field reports, or long-horizon citation impact. Do not force a CS-style top-conference model onto them. Ask for or infer the field's accepted quality standard and label uncertainty.

## Positive Template Gate

A source can become a positive reusable template only if all of these are true:

1. full text was read or a full-paper deep-read record exists;
2. venue/source quality role is `anchor_positive`, `accepted_quality`, or clearly justified `review_rich_case`;
3. it has a source ledger with title, year, venue/source, and access status;
4. it has an explicit reuse boundary: what can and cannot be borrowed;
5. it contributes a concrete pattern, not just a famous name.

If the source fails this gate, it may still be useful, but downgrade its role.

## L3/L4 High-Level Advice Gate

For solution-to-scientific-question elevation and frontier/boundary advice:

- Prefer at least two `anchor_positive` or one `anchor_positive` plus one `accepted_quality` source before saying “this is how the field frames the issue.”
- If only preprints/trends are available, label the advice `discussion-ready` or `proposal-only`, not `paper-ready`.
- If no verified external sources were checked, output graph-path retrieval tasks only.
- Never let a low-quality or unverified paper define the scientific boundary of the field.

## Quality Is Not Only Venue Prestige

A top venue helps, but it is not enough. Also check whether the paper actually has:

- a clear scientific problem, not just a system trick;
- a broken-assumption or failure-mode explanation;
- strong evidence alignment;
- fair baselines and resource comparisons;
- useful ablations or mechanism diagnostics;
- clear limitations and scope;
- reproducible enough details;
- influence or recognition appropriate to its age and field.

Conversely, a non-top venue paper can still be useful as a negative-risk case, niche domain reference, or evaluation-norm source, but do not let it become the main positive model for “top-tier paper style.”

## Source Quality Ledger

When building a KB or using external literature, record a compact ledger:

```json
{
  "title": "...",
  "year": "...",
  "field": "...",
  "venue_or_source": "...",
  "peer_review_status": "verified | likely | preprint | unknown",
  "quality_role": "anchor_positive | accepted_quality | review_rich_case | negative_risk | trend_discovery | evaluation_norm | excluded_or_unverified",
  "quality_evidence": "user-provided list | official venue page | open review | full PDF | ranking source | visible metadata | unknown",
  "read_status": "full_pdf_deep_read | abstract_only | metadata_only",
  "allowed_use": ["positive_template", "reviewer_risk", "trend", "collision", "evaluation_norm", "do_not_use"],
  "reuse_boundary": "..."
}
```

## Report Wording

Use plain wording:

> 这篇参考文献可以学它的 reviewer 防守方式，但它不是顶会顶刊样本，所以我不会把它当成高层贡献写法模板。

> 这个 arXiv 预印本可以提醒我们查撞车风险，但在没有同行评审和完整对比前，不能说它代表领域共识。

> 高层升维建议主要应该从目标领域公认的顶级论文里抽，而不是从普通相似论文里硬拔高。
