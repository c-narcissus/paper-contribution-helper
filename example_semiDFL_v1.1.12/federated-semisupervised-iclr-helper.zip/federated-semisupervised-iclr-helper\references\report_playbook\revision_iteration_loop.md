# Revision Iteration Loop

Use this playbook when the user comes back with a revised manuscript, added experiments, rewritten abstract, or rebuttal draft.

## Main Idea

A good advisor does not only diagnose v0. They re-check whether the fixes actually solved the reviewer risks.

## Iteration States

- `v0_initial_diagnosis`: first analysis of the draft.
- `v1_story_revision`: abstract/introduction/contribution/related work rewritten.
- `v2_evidence_revision`: new baseline/ablation/diagnostic/stress test added.
- `v3_submission_ready_check`: final claim, evidence, risk, and wording check.
- `rebuttal_round`: reviews supplied; answerability and response drafting.

## What To Re-check

For every revision, update:

| Item | Old state | New state | Still risky? | Next action |
|---|---|---|---|---|
| main claim | overbroad / bounded | ... | yes/no | rewrite / evidence / disclose |
| closest-prior boundary | unclear | ... | ... | ... |
| decisive experiment | missing | added/partial | ... | ... |
| reviewer question | evidence-gap | answerable | ... | ... |

## Style

Use teacher style:

> 这版比上一版强在 X，但 Y 还没真正解决。现在不要再大改方法，先把 related-work 边界和实验叙事补上。

## Do Not Reset Context Blindly

Use the current visible/re-uploaded files and the user's stated prior version. If old files are not visible in the current run, ask for the revised file or summarize assumptions instead of pretending to remember exact text.
