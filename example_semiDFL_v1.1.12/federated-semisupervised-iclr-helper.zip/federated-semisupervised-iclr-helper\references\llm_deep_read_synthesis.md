# LLM Deep-Read Corpus Synthesis

Scope: iclr-openreview corpus, focused on 联邦学习, 半监督学习, years 2023, 2024.

## Coverage Contract

- Paper count: 20
- Complete LLM deep reads: 20
- The generated skill packages only anonymous synthesis. Per-paper LLM reports, prompts, PDFs, and raw review material remain in the external project run.

## What The LLM-Read Corpus Adds Beyond Rule Matching

- Full-paper reading grounds delta reframing in method mechanics, assumptions, experiment design, figure/table evidence, and reproducibility gaps rather than keyword hits alone.
- Reviewer defense should preserve the evidence boundary: supported claims can be strengthened, weak broad claims should be narrowed, and missing details must stay marked as not reported.
- Story options should be selected from paper-level failure modes and claim-support structure, then checked against review/reply evidence when available.

## Anonymous Reuse Priorities

### delta-sized-accepted-paper-pattern

- Route use: fallback delta-packaging route
- Effective packaging pattern: 以问题压力、证据链和边界化 claims 组织贡献。
- Risk boundary: 不要夸大成 broad framework；防守 narrow but recurring failure case。
- Borrowable move: 用于 strong packaging diagnosis 和 report fallback。

### combination-method-needs-mechanism-claim

- Route use: surrogate / coupling / interface route
- Effective packaging pattern: 把每个组件映射到受约束场景中的一个压力，证明耦合是由场景需求驱动的。
- Risk boundary: 不要说每个 primitive 都全新；防守的是 constraint-driven coupling。
- Borrowable move: 用于 Story Option Board 的主线、method overview、Figure 1 caption、A+B/C rebuttal。

### incremental-gain-with-ablation-pressure

- Route use: failure-mode / mechanism-evidence route
- Effective packaging pattern: 先命名失败模式，再把模块写成 targeted intervention，并用 ablation 支撑必要性。
- Risk boundary: 不要把 ablation 写成完整机制证明；只能说 supports the mechanism 或 rules out simpler explanations。
- Borrowable move: 用于 strong packaging diagnosis、mechanism rebuttal、Tier 0 ablation discussion rewrite。

### light-transfer-with-scope-generalization-risk

- Route use: scope-boundary / transfer route
- Effective packaging pattern: 把贡献限制在共享结构瓶颈下的可验证适配，而不是泛化到所有场景。
- Risk boundary: 不要宣称 universal transfer；只说 evaluated regime 或 shared structural bottleneck。
- Borrowable move: 用于 related-work boundary、scope/generalization rebuttal、residual risk。

### baseline-contract-fairness-defense

- Route use: baseline-contract route
- Effective packaging pattern: 在实验前加入 comparison contract，把服务器、共享数据、共享验证集、标注预算、通信预算等条件显式化。
- Risk boundary: 不要简单说 baseline 不可比；要说明 resource mismatch 和 diagnostic value。
- Borrowable move: 用于 related work boundary、experiment setup、baseline fairness rebuttal。

### evidence-system-coverage-defense

- Route use: evidence-system route
- Effective packaging pattern: 把 performance、label scarcity、non-IID、topology、ablation、runtime 或 appendix 证据逐一映射到攻击点。
- Risk boundary: 证据系统只能支撑 evaluated regime，不能自动支撑 universal generalization。
- Borrowable move: 用于 Option 4、Tier 0 experiment-roadmap rewrite、appendix pointer。

### efficiency-system-claim-under-cost-scrutiny

- Route use: quality-cost / deployment-boundary route
- Effective packaging pattern: 主动定义 quality-cost tradeoff 和 resource contract，把成本边界放进 limitation 或 discussion。
- Risk boundary: 没有 runtime、communication 或 resource schedule 时，不要写 negligible overhead。
- Borrowable move: 用于 cost/scalability attack、Tier 1 log reuse、limitation paragraph。

### scope-generalization-boundary-defense

- Route use: scope-boundary route
- Effective packaging pattern: 把当前证据覆盖的范围写清，把更大泛化放入 limitation 或 future work。
- Risk boundary: 不要写 universal claim；写 evaluated settings 或 initial evidence。
- Borrowable move: 用于 residual risk、discussion、scope rebuttal。
