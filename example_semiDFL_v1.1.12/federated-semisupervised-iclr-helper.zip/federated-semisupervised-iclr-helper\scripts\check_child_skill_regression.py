#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

PARENT_METHODOLOGY_VERSION = "v1.1.12-disjunctive-corpus-intake"

REQUIRED_PLAYBOOKS = [
    "references/codex_chatgpt_dispatch_deep_read_workflow.md",
    "scripts/engine/codex_chatgpt_dispatch_deep_read.py",
    "references/report_playbook/startup_feature_menu.md",
    "references/report_playbook/mode_and_analysis_direction_workflow.md",
    "references/report_playbook/child_skill_corpus_intake_gate.md",
    "references/report_playbook/field_year_balanced_sampling.md",
    "references/report_playbook/related_work_intake_and_comparative_deep_read.md",
    "references/report_playbook/submission_context_gate.md",
    "references/report_playbook/target_venue_rubric_adapter.md",
    "references/report_playbook/edit_ready_patch_generator.md",
    "references/report_playbook/minimal_decisive_experiment_planner.md",
    "references/report_playbook/revision_iteration_loop.md",
    "references/report_playbook/figure_table_evidence_audit.md",
    "references/report_playbook/baseline_fairness_reproducibility_ledger.md",
    "references/report_playbook/citation_role_and_support_audit.md",
    "references/report_playbook/multi_layer_revision_ladder.md",
    "references/report_playbook/solution_to_scientific_question_elevation.md",
    "references/report_playbook/claim_evidence_risk_map.md",
    "references/report_playbook/reviewer_question_answerability.md",
    "references/report_playbook/paper_logic_completeness_audit.md",
    "references/report_playbook/risk_self_disclosure_playbook.md",
    "references/report_playbook/web_safe_dynamic_metagraph.md",
    "references/report_playbook/literature_evidence_guard.md",
    "references/report_playbook/source_quality_gate.md",
    "references/report_playbook/local_knowledge_base_construction.md",
    "references/report_playbook/scientific_boundary_breakthrough.md",
    "references/report_playbook/top_scientist_advisor_lens.md",
    "references/report_playbook/child_skill_generation_sync.md",
    "references/report_playbook/child_skill_inheritance_contract.md",
    "references/report_playbook/child_skill_regression_test.md",
]

STARTUP_NEEDLES = [
    "启动这一轮我只给你选择菜单",
    "直接使用",
    "里的skill",
    "分析方向",
    "模式A1",
    "模式A2",
    "子 skill 只保留",
    "不再生成新的子 skill",
    "A+B+C+D",
    "研究领域",
    "年份",
    "每年数量",
    "来源",
    "本地资料",
    "默认都是",
]

FORBIDDEN_STARTUP_MARKERS = [
    "模式" + "1",
    "模式" + "2",
    "模式" + "3",
    "构建新的专业子 " + "skill",
    "构建" + "子skill",
]

MOJIBAKE_MARKERS = [
    "\u93b4\u620d\uacec\u69f8",
    "\u9429\u5b58\u5e34",
    "\u59af\u2033\u7d21",
    "\u934a\u55d8\u6fac",
    "\u6d63\u8de8\u657c",
    "\u9286",
    "\u951b",
    "\u9225",
    "\u20ac",
    "\u8133",
    "\u4e67losest",
    "\u4e65aseline",
    "\u4e7bcientific",
    "\u4e7aevision",
    "\u6060kill",
    "\u5b8d",
    "\u5655enue",
    "\u78ba__",
    "\ufffd",
]

ROUTER_NEEDLES = [
    "Related-Work Intake Gate",
    "Submission-Context and Execution Gate",
    "Child-Skill Corpus Intake Gate",
    "workflow_target_paper_reframing.md",
    "literature_evidence_guard.md",
    "source-quality",
    "edit-ready patches",
    "minimal decisive experiment",
    "revision loop",
    "L0-L4",
    "solution-to-scientific-question",
]

MANIFEST_REQUIRED = [
    "L0-L4 revision ladder",
    "solution-to-scientific-question elevation",
    "web-safe dynamic meta-graph",
    "literature evidence guard",
    "source quality gate",
    "related-work intake gate",
    "submission-context gate",
    "edit-ready patch generation",
    "minimal decisive experiment planning",
    "revision iteration loop",
    "figure/table evidence audit",
    "baseline fairness and reproducibility ledger",
    "citation role and support audit",
    "child skill inheritance contract",
    "mode/direction startup menu",
    "child startup excludes new-skill generation mode",
    "child startup uses A1/A2 mode namespace",
    "explicit work-mode selection",
    "A-D analysis-direction selection",
    "child-skill corpus intake gate",
    "field-year balanced corpus sampling",
    "multi-value OR corpus semantics",
    "codex/chatgpt dispatch deep-reading workflow",
]


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except json.JSONDecodeError:
        return {"_json_error": True}
    return data if isinstance(data, dict) else {"_json_error": True}


def lower_join(value: Any) -> str:
    if isinstance(value, list):
        return "\n".join(str(x) for x in value).lower()
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False).lower()
    return str(value or "").lower()


def main() -> None:
    parser = argparse.ArgumentParser(description="Smoke-test a generated child skill for parent-methodology inheritance.")
    parser.add_argument("skill_dir", type=Path)
    args = parser.parse_args()
    root = args.skill_dir
    skill_md = root / "SKILL.md"
    text = skill_md.read_text(encoding="utf-8", errors="replace") if skill_md.exists() else ""
    manifest = read_json(root / "references" / "knowledge_manifest.json")
    inherited_blob = "\n".join(
        [
            lower_join(manifest.get("methodology_version")),
            lower_join(manifest.get("inherited_methodology")),
            lower_join(manifest.get("inheritance_contract")),
        ]
    )
    missing_files = [p for p in REQUIRED_PLAYBOOKS if not (root / p).exists()]
    missing_startup = [s for s in STARTUP_NEEDLES if s not in text]
    forbidden_startup = [s for s in FORBIDDEN_STARTUP_MARKERS if s in text]
    mojibake_findings = [s for s in MOJIBAKE_MARKERS if s in text]
    missing_router = [s for s in ROUTER_NEEDLES if s not in text]
    missing_manifest = [s for s in MANIFEST_REQUIRED if s.lower() not in inherited_blob]
    version_ok = PARENT_METHODOLOGY_VERSION.lower() in inherited_blob
    valid = (
        not missing_files
        and not missing_startup
        and not forbidden_startup
        and not mojibake_findings
        and not missing_router
        and not missing_manifest
        and version_ok
    )
    report = {
        "skill_dir": root.as_posix(),
        "expected_parent_methodology_version": PARENT_METHODOLOGY_VERSION,
        "valid": valid,
        "missing_files": missing_files,
        "missing_startup_markers": missing_startup,
        "forbidden_startup_markers": forbidden_startup,
        "mojibake_findings": mojibake_findings,
        "missing_router_markers": missing_router,
        "missing_manifest_methodology": missing_manifest,
        "manifest_version_ok": version_ok,
        "ready_status": "production-ready" if valid else "experimental-or-debug-only",
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report["valid"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
