# Baseline Fairness and Reproducibility Ledger

Use this playbook for papers with empirical comparisons, especially CS/AI/systems/engineering papers.

## Main Idea

Reviewer attacks often come from unfair comparisons, hidden resources, weak statistics, and missing implementation details.

## Resource-Parity Ledger

Create a compact ledger when baselines matter:

| Method | Data | Model/params | Training budget | Tuning budget | Extra resources | Seeds/statistics | Fair? |
|---|---|---|---|---|---|---|---|
| ours | ... | ... | ... | ... | ... | ... | yes/unclear/no |
| baseline A | ... | ... | ... | ... | ... | ... | ... |

## Checks

- same train/test split and data access;
- same labeled/unlabeled/extra data assumptions;
- same model size or justified difference;
- same compute/epochs/communication/annotation budget;
- comparable hyperparameter tuning;
- multiple seeds or uncertainty where expected;
- official implementation or faithful reimplementation;
- cost/latency/memory/communication reported when relevant;
- reproducibility details: code, parameters, preprocessing, hardware, prompts, random seeds.

## Revision Actions

- If unfair but necessary, separate same-resource baselines from extra-resource diagnostic baselines.
- If missing, ask for the minimal missing baseline or state a limitation.
- If cost is higher, frame the claim as gain-cost tradeoff rather than free improvement.
